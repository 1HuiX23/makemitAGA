using System;
using MakemitAGA.ActiveRagdollLab.Configuration;
using MakemitAGA.ActiveRagdollLab.Model;
using UnityEngine;

namespace MakemitAGA.ActiveRagdollLab.Physics
{
    /// <summary>
    /// v0.3.x bilateral coordinator. It owns two instances of the already frozen SingleLegShadowChain.
    /// No controller math is duplicated here. Both sides share the same immutable profile and Two-Body parent.
    /// </summary>
    internal sealed class BilateralLegCoordinator
    {
        private readonly ActiveRagdollLabProfile _profile;
        private readonly SingleLegTargetReport _primaryTarget;
        private readonly SingleLegTargetReport _secondaryTarget;
        private readonly Transform _targetRoot;
        private readonly TwoBodyShadowProxy _torso;
        private readonly bool _bilateralEnabled;
        private readonly BilateralLegReport _report = new BilateralLegReport();
        private readonly KneeSafetyContextReport _kneeSafetyReport = new KneeSafetyContextReport();
        private readonly BilateralLegCouplingDiagnostics _diagnostics = new BilateralLegCouplingDiagnostics();
        private readonly KneeSafetyContextRecorder _kneeSafety = new KneeSafetyContextRecorder();

        private SingleLegShadowChain _primary;
        private SingleLegShadowChain _secondary;
        private bool _traceEnabled;
        private bool _destroyed;
        private bool _distinctSourceChains;
        private bool _bilateralFailClosedLatched;

        public BilateralLegCoordinator(
            ActiveRagdollLabProfile profile,
            SingleLegTargetReport primaryTarget,
            SingleLegTargetReport secondaryTarget,
            Transform targetRoot,
            TwoBodyShadowProxy torso,
            bool bilateralEnabled)
        {
            _profile = profile ?? throw new ArgumentNullException(nameof(profile));
            _primaryTarget = primaryTarget ?? throw new ArgumentNullException(nameof(primaryTarget));
            _secondaryTarget = secondaryTarget;
            _targetRoot = targetRoot ?? throw new ArgumentNullException(nameof(targetRoot));
            _torso = torso ?? throw new ArgumentNullException(nameof(torso));
            _bilateralEnabled = bilateralEnabled;
        }

        public SingleLegChainReport Report => _primary != null ? _primary.Report : null;
        public SingleLegChainReport PrimaryReport => _primary != null ? _primary.Report : null;
        public SingleLegChainReport SecondaryReport => _secondary != null ? _secondary.Report : null;
        public BilateralLegReport BilateralReport => _report;
        public KneeSafetyContextReport KneeSafetyReport => _kneeSafetyReport;
        public bool IsBuilt => !_destroyed && _primary != null && _primary.IsBuilt && (!_bilateralEnabled || (_secondary != null && _secondary.IsBuilt));
        public bool DriveEnabled => _primary != null && _primary.DriveEnabled && (!_bilateralEnabled || (_secondary != null && _secondary.DriveEnabled));
        public bool KneeAxisCalibrationCollecting => (_primary != null && _primary.KneeAxisCalibrationCollecting) || (_secondary != null && _secondary.KneeAxisCalibrationCollecting);
        public bool BilateralEnabled => _bilateralEnabled;
        public string PrimarySide => _primaryTarget != null ? _primaryTarget.RequestedSide : null;
        public string SecondarySide => _secondaryTarget != null ? _secondaryTarget.RequestedSide : null;

        public string Build()
        {
            if (IsBuilt)
                return GetStatus();

            _distinctSourceChains = ValidateDistinctTargets(_primaryTarget, _secondaryTarget, _bilateralEnabled);
            if (!_distinctSourceChains)
                return "ARL bilateral build：source chain overlap / invalid target pairing；未创建物理对象。";

            try
            {
                // Historical closure logs are emitted by the primary only. The secondary still computes the exact same
                // reports/freeze certification but does not duplicate every immutable v0.2.x closure line at trace stop.
                _primary = new SingleLegShadowChain(_profile, _primaryTarget, _targetRoot, _torso);
                string primaryBuild = _primary.Build();
                if (!_primary.IsBuilt)
                {
                    RollbackInternal("primary-build-failed");
                    return primaryBuild;
                }

                string secondaryBuild = "secondary=disabled";
                if (_bilateralEnabled)
                {
                    _secondary = new SingleLegShadowChain(_profile, _secondaryTarget, _targetRoot, _torso);
                    secondaryBuild = _secondary.Build();
                    if (!_secondary.IsBuilt)
                    {
                        RollbackInternal("secondary-build-failed");
                        return primaryBuild + "\n" + secondaryBuild + "\nARL bilateral build：secondary chain失败，已整体回滚。";
                    }
                }

                _diagnostics.Reset(_report, _bilateralEnabled, _distinctSourceChains, PrimarySide, SecondarySide);
                _kneeSafety.Reset(_kneeSafetyReport);
                _report.Built = true;
                _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);

                return
                    "ARL bilateral build | success=True" +
                    " | enabled=" + _bilateralEnabled +
                    " | primary=" + (PrimarySide ?? "<none>") +
                    " | secondary=" + (SecondarySide ?? "<none>") +
                    " | distinct=" + _distinctSourceChains +
                    "\n" + primaryBuild +
                    (_bilateralEnabled ? "\n" + secondaryBuild : string.Empty);
            }
            catch (Exception e)
            {
                RollbackInternal("exception:" + e.GetType().Name);
                return "ARL bilateral build 失败：" + e.GetType().Name + " / " + e.Message;
            }
        }

        public void SampleSourcePose()
        {
            if (!IsBuilt) return;
            _primary.SampleSourcePose();
            _secondary?.SampleSourcePose();
        }

        public void FixedUpdate()
        {
            if (!IsBuilt) return;
            _primary.FixedUpdate();
            _secondary?.FixedUpdate();

            // Observe first so an asymmetric abort/drive transition is preserved in the read-only parity evidence.
            if (_traceEnabled && _bilateralEnabled && _secondary != null)
            {
                _diagnostics.Observe(_report, _primary.Report, _secondary.Report);
                // v0.3.12 minimal hard-safety context ring retained after the v0.3.10 timing study closed.
                _kneeSafety.ObserveFixedStep(_kneeSafetyReport, _primary, _secondary);
            }
            else
            {
                _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);
            }

            // v0.3.0 bilateral-only lifecycle safety: one per-side fail-fast must never leave the opposite side
            // dynamically active on subsequent physics steps. This does not alter controller math; it only propagates
            // the existing per-side shutdown after both chains have completed the current coordinator FixedUpdate.
            if (_bilateralEnabled && _secondary != null)
            {
                bool driveMismatch = _primary.DriveEnabled != _secondary.DriveEnabled;
                bool anyAbort = _primary.Report.DriveAborted || _secondary.Report.DriveAborted;
                if (driveMismatch || anyAbort)
                    FailCloseBothSides(driveMismatch, anyAbort);
            }
        }

        public string SetDrive(bool enabled)
        {
            if (!IsBuilt)
                return "ARL leg drive：bilateral foundation尚未创建。";

            if (!enabled)
            {
                string secondaryOff = _secondary != null ? _secondary.SetDrive(false) : "secondary=disabled";
                string primaryOff = _primary.SetDrive(false);
                _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);
                return "ARL bilateral leg drive | enabled=False\nprimary: " + primaryOff + (_bilateralEnabled ? "\nsecondary: " + secondaryOff : string.Empty);
            }

            // v0.3.0 only validates the certified frozen baseline. Do not allow a bilateral run to start if either
            // side skipped the existing post-PCA stack setup; this is a production-contract preflight, not a new gate.
            if (!_primary.FrozenProductionStackReady)
                return "ARL bilateral leg drive：primary frozen production stack未READY；请先 arl_hip_stack(on)。";
            if (_bilateralEnabled && !_secondary.FrozenProductionStackReady)
                return "ARL bilateral leg drive：secondary frozen production stack未READY；请先 arl_hip_stack(on)。";

            _bilateralFailClosedLatched = false;
            string primaryOn = _primary.SetDrive(true);
            if (!_primary.DriveEnabled)
                return "ARL bilateral leg drive：primary启动失败。\n" + primaryOn;

            if (_bilateralEnabled)
            {
                string secondaryOn = _secondary.SetDrive(true);
                if (!_secondary.DriveEnabled)
                {
                    _primary.SetDrive(false);
                    _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);
                    return "ARL bilateral leg drive：secondary启动失败；primary已立即回退为OFF。\n" + secondaryOn;
                }
                _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);
                return "ARL bilateral leg drive | enabled=True\nprimary: " + primaryOn + "\nsecondary: " + secondaryOn;
            }

            _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);
            return primaryOn;
        }

        public string SetHipExperimentStack(bool enabled)
        {
            if (!IsBuilt) return "ARL Hip experiment stack：bilateral foundation尚未创建。";

            if (!enabled)
            {
                string secondaryOff = _secondary != null ? _secondary.SetHipExperimentStack(false) : "secondary=disabled";
                string primaryOff = _primary.SetHipExperimentStack(false);
                return Combine("ARL bilateral frozen stack | enabled=False", primaryOff, secondaryOff);
            }

            // Bilateral v0.3.0 must not silently leave one side on a different frozen stack.
            // Bring primary up first, verify the existing post-PCA readiness contract, then do secondary.
            string primaryOn = _primary.SetHipExperimentStack(true);
            if (!_primary.FrozenProductionStackReady)
                return "ARL bilateral frozen stack：primary未达到 frozen production stack ready。\n" + primaryOn;

            if (_bilateralEnabled)
            {
                string secondaryOn = _secondary.SetHipExperimentStack(true);
                if (!_secondary.FrozenProductionStackReady)
                {
                    _primary.SetHipExperimentStack(false);
                    return "ARL bilateral frozen stack：secondary配置失败；primary已回退为OFF，避免半栈状态。\n" + secondaryOn;
                }
                return Combine("ARL bilateral frozen stack | enabled=True", primaryOn, secondaryOn);
            }

            return primaryOn;
        }

        public string GetHipExperimentStackStatus() => CombineStatus("ARL bilateral frozen stack", c => c.GetHipExperimentStackStatus());
        public string GetSingleLegFreezeStatus() => CombineStatus("ARL bilateral per-leg freeze", c => c.GetSingleLegFreezeStatus());

        public string SetKneeAxisCalibration(bool enabled)
        {
            if (!IsBuilt) return "ARL knee axis calibration：bilateral foundation尚未创建。";
            if (enabled)
            {
                string p = _primary.SetKneeAxisCalibration(true);
                if (!_primary.KneeAxisCalibrationCollecting)
                    return "ARL bilateral knee axis calibration：primary启动失败。\n" + p;
                if (_bilateralEnabled)
                {
                    string s = _secondary.SetKneeAxisCalibration(true);
                    if (!_secondary.KneeAxisCalibrationCollecting)
                    {
                        _primary.SetKneeAxisCalibration(false);
                        return "ARL bilateral knee axis calibration：secondary启动失败；primary收集已停止。\n" + s;
                    }
                    return Combine("ARL bilateral knee axis calibration | collecting=True", p, s);
                }
                return p;
            }

            string secondaryStop = _secondary != null ? _secondary.SetKneeAxisCalibration(false) : "secondary=disabled";
            string primaryStop = _primary.SetKneeAxisCalibration(false);
            return Combine("ARL bilateral knee axis calibration | collecting=False", primaryStop, secondaryStop);
        }

        public string ApplyCalibratedKneeAxis()
        {
            if (!IsBuilt) return "ARL knee axis apply：bilateral foundation尚未创建。";

            // Apply only when both independently collected PCA candidates have passed the existing readiness gate.
            // This keeps the bilateral foundation symmetric without inventing any new axis-quality threshold.
            if (!_primary.KneeAxisCalibrationReady)
                return "ARL bilateral knee axis apply：primary candidate尚未 READY；未修改任一侧。";
            if (_bilateralEnabled && !_secondary.KneeAxisCalibrationReady)
                return "ARL bilateral knee axis apply：secondary candidate尚未 READY；未修改任一侧。";

            string primaryApply = _primary.ApplyCalibratedKneeAxis();
            if (!_primary.KneeAxisCalibrationApplied)
                return "ARL bilateral knee axis apply：primary应用失败；secondary未修改。\n" + primaryApply;

            if (_bilateralEnabled)
            {
                string secondaryApply = _secondary.ApplyCalibratedKneeAxis();
                if (!_secondary.KneeAxisCalibrationApplied)
                {
                    // Applying an axis is configuration-only (drive/trace are off). If the second side fails, restore
                    // both to the initial CharacterJoint-right basis rather than continue with asymmetric calibration.
                    string secondaryRollback = _secondary.ResetKneeAxisToInitial();
                    string primaryRollback = _primary.ResetKneeAxisToInitial();
                    return "ARL bilateral knee axis apply：secondary应用失败；两侧均已回退到 initial axis。" +
                           "\nprimaryApply: " + primaryApply +
                           "\nsecondaryApply: " + secondaryApply +
                           "\nprimaryRollback: " + primaryRollback +
                           "\nsecondaryRollback: " + secondaryRollback;
                }
                return Combine("ARL bilateral knee axis apply | success=True", primaryApply, secondaryApply);
            }

            return primaryApply;
        }

        public string ResetKneeAxisToInitial()
        {
            if (!IsBuilt) return "ARL knee axis reset：bilateral foundation尚未创建。";
            string p = _primary.ResetKneeAxisToInitial();
            string s = _secondary != null ? _secondary.ResetKneeAxisToInitial() : "secondary=disabled";
            return Combine("ARL bilateral knee axis reset", p, s);
        }

        public string GetKneeAxisCalibrationStatus() => CombineStatus("ARL bilateral knee axis calibration", c => c.GetKneeAxisCalibrationStatus());

        public string SetGravity(bool enabled)
        {
            if (!IsBuilt) return "ARL leg gravity：bilateral foundation尚未创建。";
            return Combine("ARL bilateral leg gravity", _primary.SetGravity(enabled), _secondary != null ? _secondary.SetGravity(enabled) : "secondary=disabled");
        }

        public string SetColliders(bool enabled)
        {
            if (!IsBuilt) return "ARL leg colliders：bilateral foundation尚未创建。";
            return Combine("ARL bilateral leg colliders", _primary.SetColliders(enabled), _secondary != null ? _secondary.SetColliders(enabled) : "secondary=disabled");
        }

        public string SetVisual(bool enabled)
        {
            if (!IsBuilt) return "ARL leg visual：bilateral foundation尚未创建。";
            return Combine("ARL bilateral leg visual", _primary.SetVisual(enabled), _secondary != null ? _secondary.SetVisual(enabled) : "secondary=disabled");
        }

        public string SetTrace(bool enabled)
        {
            if (!IsBuilt) return "ARL leg trace：bilateral foundation尚未创建。";
            if (enabled)
            {
                // SingleLegShadowChain rejects trace start while PCA collection is active. Preflight both sides so
                // a rejected secondary cannot leave only the primary tracing.
                if (_primary.KneeAxisCalibrationCollecting || (_bilateralEnabled && _secondary.KneeAxisCalibrationCollecting))
                    return "ARL bilateral trace：拒绝启动。至少一侧 Knee axis calibration 正在收集。";

                string p = _primary.SetTrace(true);
                string s = _secondary != null ? _secondary.SetTrace(true) : "secondary=disabled";
                _traceEnabled = true;
                _diagnostics.Reset(_report, _bilateralEnabled, _distinctSourceChains, PrimarySide, SecondarySide);
                _kneeSafety.BeginTrace(_kneeSafetyReport);
                _report.Built = IsBuilt;
                _report.TraceEnabled = true;
                _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);
                return Combine("ARL bilateral trace | enabled=True", p, s);
            }

            string secondaryStop = _secondary != null ? _secondary.SetTrace(false) : "secondary=disabled";
            string primaryStop = _primary.SetTrace(false);
            _traceEnabled = false;
            _report.TraceEnabled = false;
            string kneeSafety = _kneeSafety.Finalize(_kneeSafetyReport);
            Plugin.Logger?.LogWarning("[ARL][KNEE_SAFETY_CONTEXT] " + kneeSafety);
            Plugin.Logger?.LogWarning("[ARL][KNEE_SAFETY_CONTEXT_KEY] " + (_kneeSafetyReport.Key ?? "<none>"));
            string bilateral = _bilateralEnabled
                ? _diagnostics.Finalize(_report, PrimaryReport, SecondaryReport, IsBuilt, _distinctSourceChains)
                : "ARL bilateral foundation | enabled=False";
            if (_bilateralEnabled)
            {
                Plugin.Logger?.LogWarning("[ARL][BILATERAL_FOUNDATION] " + bilateral);
                Plugin.Logger?.LogWarning("[ARL][BILATERAL_FOUNDATION_KEY] " + (_report.Key ?? "<none>"));
            }
            return Combine("ARL bilateral trace | enabled=False | " + bilateral, primaryStop, secondaryStop);
        }


        public string GetKneeSafetyContextStatus()
        {
            return _kneeSafety.GetStatus(_kneeSafetyReport);
        }

        public string ResetPose()
        {
            if (!IsBuilt) return "ARL reset：bilateral foundation尚未创建。";
            string secondaryReset = _secondary != null ? _secondary.ResetPose() : "secondary=disabled";
            string primaryReset = _primary.ResetPose();
            return Combine("ARL bilateral reset", primaryReset, secondaryReset);
        }

        public string GetStatus()
        {
            _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);
            _report.Built = IsBuilt;
            _report.TraceEnabled = _traceEnabled;
            return _report.GetConsoleSummary() +
                   "\nprimary: " + (_primary != null ? _primary.Report.GetConsoleSummary() : "<none>") +
                   (_bilateralEnabled ? "\nsecondary: " + (_secondary != null ? _secondary.Report.GetConsoleSummary() : "<none>") : string.Empty);
        }

        public string GetBilateralStatus()
        {
            _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);
            _report.Built = IsBuilt;
            _report.TraceEnabled = _traceEnabled;
            return _report.GetConsoleSummary() + " | key=" + (_report.Key ?? "<not-finalized>");
        }


        public string Rollback(string reason)
        {
            RollbackInternal(reason);
            _destroyed = true;
            _report.Built = false;
            _report.FoundationReady = false;
            _report.Reason = "ROLLED_BACK:" + reason;
            return "ARL bilateral rollback | success=True | reason=" + reason;
        }

        private void RollbackInternal(string reason)
        {
            try { _secondary?.Rollback(reason); } catch { }
            try { _primary?.Rollback(reason); } catch { }
            _secondary = null;
            _primary = null;
            _traceEnabled = false;
        }

        private void FailCloseBothSides(bool driveMismatch, bool anyAbort)
        {
            string reason =
                "driveMismatch=" + driveMismatch +
                "|abort=" + anyAbort +
                "|primaryAbort=" + _primary.Report.DriveAborted + "/" + (_primary.Report.DriveAbortReason ?? "<none>") +
                "|secondaryAbort=" + _secondary.Report.DriveAborted + "/" + (_secondary.Report.DriveAbortReason ?? "<none>");

            if (!_bilateralFailClosedLatched)
            {
                _bilateralFailClosedLatched = true;
                _report.FailClosedEvents++;
                _report.LastFailClosedReason = reason;
                Plugin.Logger?.LogError("[ARL][BILATERAL_FAIL_CLOSED] " + reason);
            }

            if (_primary.DriveEnabled) _primary.SetDrive(false);
            if (_secondary.DriveEnabled) _secondary.SetDrive(false);
            _diagnostics.CopyCurrent(_report, PrimaryReport, SecondaryReport);
        }

        private string CombineStatus(string header, Func<SingleLegShadowChain, string> get)
        {
            if (!IsBuilt) return header + " | built=False";
            string p = get(_primary);
            string s = _secondary != null ? get(_secondary) : "secondary=disabled";
            return Combine(header, p, s);
        }

        private string Combine(string header, string primary, string secondary)
        {
            return header +
                   "\nprimary(" + (PrimarySide ?? "<none>") + "): " + primary +
                   (_bilateralEnabled ? "\nsecondary(" + (SecondarySide ?? "<none>") + "): " + secondary : string.Empty);
        }

        private static bool ValidateDistinctTargets(SingleLegTargetReport primary, SingleLegTargetReport secondary, bool bilateralEnabled)
        {
            if (primary == null || !primary.Success || primary.UpperLeg == null || primary.LowerLeg == null || primary.Foot == null)
                return false;
            if (!bilateralEnabled)
                return true;
            if (secondary == null || !secondary.Success || secondary.UpperLeg == null || secondary.LowerLeg == null || secondary.Foot == null)
                return false;
            if (primary.UpperLeg == secondary.UpperLeg ||
                primary.LowerLeg == secondary.LowerLeg ||
                primary.Foot == secondary.Foot)
                return false;
            return !string.Equals(primary.RequestedSide, secondary.RequestedSide, StringComparison.OrdinalIgnoreCase);
        }
    }
}
