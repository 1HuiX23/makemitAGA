using System;
using System.Collections.Generic;
using UnityEngine;
using Object = UnityEngine.Object;

namespace MakemitAGA.ActiveRagdollLab.Physics
{
    /// <summary>
    /// v0.2.29 组件能力探针（production backend unchanged; recovery attribution is managed/read-only）。
    ///
    /// 清理冻结阶段已经不再需要的 ConfigurableJoint / FixedJoint / SpringJoint 探测分支。
    /// 现在只验证实际主线需要的组件：
    /// BoxCollider、Rigidbody、接触跟踪器与 CharacterJoint（torso / hip / production knee）。
    /// </summary>
    internal static class ComponentCapabilityProbe
    {
        private sealed class Result
        {
            public string Name;
            public bool Success;
            public string Detail;
        }

        public static string Run()
        {
            GameObject root = null;
            GameObject connectedRoot = null;
            List<Result> results = new List<Result>();
            bool cleanupRequested = false;

            try
            {
                root = new GameObject("ARL_ComponentCapabilityProbe");
                root.hideFlags = HideFlags.HideAndDontSave;
                root.transform.position = new Vector3(100000f, 100000f, 100000f);

                connectedRoot = new GameObject("ARL_ComponentCapabilityProbe_ConnectedBody");
                connectedRoot.hideFlags = HideFlags.HideAndDontSave;
                connectedRoot.transform.position = root.transform.position + Vector3.up * 0.2f;

                BoxCollider box = TryAdd(results, "BoxCollider", () =>
                    Il2CppComponentFactory.Add<BoxCollider>(root, "PROBE_BOX_COLLIDER"));
                if (box != null)
                {
                    box.enabled = false;
                    box.size = Vector3.one * 0.1f;
                }

                Rigidbody body = TryAdd(results, "Rigidbody", () =>
                    Il2CppComponentFactory.Add<Rigidbody>(root, "PROBE_RIGIDBODY"));
                if (body != null)
                {
                    body.useGravity = false;
                    body.isKinematic = true;
                    body.detectCollisions = false;
                }

                Rigidbody connectedBody = TryAdd(results, "ConnectedRigidbody", () =>
                    Il2CppComponentFactory.Add<Rigidbody>(connectedRoot, "PROBE_CONNECTED_RIGIDBODY"));
                if (connectedBody != null)
                {
                    connectedBody.useGravity = false;
                    connectedBody.isKinematic = true;
                    connectedBody.detectCollisions = false;
                }

                RagdollProxyContactTracker tracker = TryAdd(results, "RagdollProxyContactTracker", () =>
                    Il2CppComponentFactory.Add<RagdollProxyContactTracker>(root, "PROBE_CONTACT_TRACKER"));
                if (tracker != null)
                    tracker.Initialize("COMPONENT_PROBE");

                CharacterJoint characterJoint = TryAdd(results, "CharacterJoint", () =>
                    Il2CppComponentFactory.Add<CharacterJoint>(root, "PROBE_CHARACTER_JOINT"));
                if (characterJoint != null)
                {
                    try
                    {
                        characterJoint.connectedBody = connectedBody;
                        characterJoint.autoConfigureConnectedAnchor = false;
                        characterJoint.anchor = Vector3.zero;
                        characterJoint.connectedAnchor = Vector3.zero;
                        characterJoint.axis = Vector3.up;
                        characterJoint.swingAxis = Vector3.right;
                        SoftJointLimit low = characterJoint.lowTwistLimit; low.limit = -170f; characterJoint.lowTwistLimit = low;
                        SoftJointLimit high = characterJoint.highTwistLimit; high.limit = 170f; characterJoint.highTwistLimit = high;
                        SoftJointLimit s1 = characterJoint.swing1Limit; s1.limit = 170f; characterJoint.swing1Limit = s1;
                        SoftJointLimit s2 = characterJoint.swing2Limit; s2.limit = 170f; characterJoint.swing2Limit = s2;
                        characterJoint.enableCollision = false;
                    }
                    catch (Exception e)
                    {
                        MarkFailed(results, "CharacterJoint", "required-config-failed:" + Il2CppComponentFactory.DescribeException(e));
                    }
                }

            }
            catch (Exception e)
            {
                results.Add(new Result
                {
                    Name = "probe-root",
                    Success = false,
                    Detail = Il2CppComponentFactory.DescribeException(e)
                });
            }
            finally
            {
                try
                {
                    if (root != null) Object.Destroy(root);
                    if (connectedRoot != null) Object.Destroy(connectedRoot);
                    cleanupRequested = true;
                }
                catch (Exception e)
                {
                    cleanupRequested = false;
                    results.Add(new Result
                    {
                        Name = "cleanup",
                        Success = false,
                        Detail = Il2CppComponentFactory.DescribeException(e)
                    });
                }
            }

            bool passed = cleanupRequested;
            for (int i = 0; i < results.Count; i++)
            {
                if (!results[i].Success)
                {
                    passed = false;
                    break;
                }
            }

            System.Text.StringBuilder sb = new System.Text.StringBuilder(900);
            sb.Append("ARL component probe | success=");
            sb.Append(passed);
            sb.Append(" | requiredPath=FROZEN_TORSO_PLUS_PRODUCTION_KNEE_CHARACTER_JOINT");
            for (int i = 0; i < results.Count; i++)
            {
                Result result = results[i];
                sb.Append(" | ");
                sb.Append(result.Name);
                sb.Append('=');
                sb.Append(result.Success ? "PASS" : "FAIL");
                if (!string.IsNullOrWhiteSpace(result.Detail))
                {
                    sb.Append('(');
                    sb.Append(result.Detail);
                    sb.Append(')');
                }
            }
            sb.Append(" | cleanupRequested=");
            sb.Append(cleanupRequested);
            sb.Append(" | physicsSimulationEntered=False");
            return sb.ToString();
        }

        private static T TryAdd<T>(List<Result> results, string name, Func<T> factory) where T : Component
        {
            try
            {
                T component = factory();
                results.Add(new Result
                {
                    Name = name,
                    Success = component != null,
                    Detail = component != null ? "non-generic-add+TryCast" : "null"
                });
                return component;
            }
            catch (Exception e)
            {
                results.Add(new Result
                {
                    Name = name,
                    Success = false,
                    Detail = Il2CppComponentFactory.DescribeException(e)
                });
                return null;
            }
        }

        private static void MarkFailed(List<Result> results, string name, string detail)
        {
            for (int i = results.Count - 1; i >= 0; i--)
            {
                if (results[i].Name == name)
                {
                    results[i].Success = false;
                    results[i].Detail = detail;
                    return;
                }
            }
        }
    }
}
