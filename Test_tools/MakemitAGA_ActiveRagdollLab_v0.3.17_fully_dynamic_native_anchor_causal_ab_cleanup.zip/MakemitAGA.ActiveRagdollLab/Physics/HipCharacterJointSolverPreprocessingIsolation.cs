using MakemitAGA.ActiveRagdollLab.Model;
using UnityEngine;

namespace MakemitAGA.ActiveRagdollLab.Physics
{
    /// <summary>
    /// ARL v0.2.58 controlled causal A/B for the Hip CharacterJoint solver backend.
    ///
    /// The ONLY experimental variable is CharacterJoint.enablePreprocessing:
    ///   A / production = ON
    ///   B / experimental = OFF
    ///
    /// Anchor geometry, connectedBody, axis/swingAxis, +/- wide limits, Hip/Knee PD, strict control frame,
    /// mechanical-parent transport and Linear20 remain untouched. This class never calls AddForce/AddTorque,
    /// MovePosition/MoveRotation, or writes any source Transform.
    ///
    /// This does NOT claim that enablePreprocessing represents the entire CharacterJoint angular solver. It is a
    /// deliberately narrow probe of one internal PhysX joint-solver path. A positive result therefore implicates
    /// preprocessing/stabilization specifically; a negative result does not exonerate the rest of CharacterJoint.
    /// </summary>
    internal sealed class HipCharacterJointSolverPreprocessingIsolation
    {
        internal const string Mode = "HIP_CHARACTER_JOINT_SOLVER_PREPROCESSING_CAUSAL_AB";
        internal const string ProductionArm = "A_PREPROCESSING_ON_PRODUCTION";
        internal const string ExperimentalArm = "B_PREPROCESSING_OFF_EXPERIMENTAL";

        private bool _enabled = true;

        internal bool Enabled => _enabled;
        internal string Arm => _enabled ? ProductionArm : ExperimentalArm;

        internal void Apply(CharacterJoint joint)
        {
            if (joint != null)
                joint.enablePreprocessing = _enabled;
        }

        internal bool SetEnabled(bool enabled, CharacterJoint joint)
        {
            if (joint == null)
                return false;
            _enabled = enabled;
            Apply(joint);
            bool ok = joint.enablePreprocessing == enabled;
            if (!ok)
            {
                // Fail closed to the production arm if IL2CPP readback does not honor the requested experimental state.
                _enabled = true;
                joint.enablePreprocessing = true;
            }
            return ok;
        }

        internal void CopyToReport(SingleLegChainReport report, CharacterJoint joint)
        {
            if (report == null) return;
            report.HipSolverCausalIsolationMode = Mode;
            report.HipSolverCausalIsolationArm = Arm;
            report.HipSolverPreprocessingRequested = _enabled;
            report.HipSolverPreprocessingReadback = joint != null && joint.enablePreprocessing;
        }

        internal string GetStatus(CharacterJoint joint)
        {
            return "ARL Hip CharacterJoint solver A/B | mode=" + Mode +
                   " | arm=" + Arm +
                   " | preprocessing(requested/readback)=" + _enabled + "/" + (joint != null && joint.enablePreprocessing) +
                   " | anchor/connectedAnchor=" + V(joint != null ? joint.anchor : Vector3.zero) + "/" + V(joint != null ? joint.connectedAnchor : Vector3.zero) +
                   " | limits(low/high/s1/s2)=" + F(joint != null ? joint.lowTwistLimit.limit : 0f) + "/" + F(joint != null ? joint.highTwistLimit.limit : 0f) + "/" + F(joint != null ? joint.swing1Limit.limit : 0f) + "/" + F(joint != null ? joint.swing2Limit.limit : 0f);
        }

        internal string GetKey(SingleLegChainReport report, CharacterJoint joint)
        {
            if (report == null)
                return "mode=" + Mode + " | arm=" + Arm + " | report=<null>";

            string integrity = joint == null
                ? "joint=<null>"
                : "preprocess=" + joint.enablePreprocessing +
                  "/connected=" + report.HipConnectedBodyMatch +
                  "/limits=" + F(joint.lowTwistLimit.limit) + "/" + F(joint.highTwistLimit.limit) + "/" + F(joint.swing1Limit.limit) + "/" + F(joint.swing2Limit.limit);

            return "mode=" + Mode +
                   " | arm=" + Arm +
                   " | integrity(" + integrity + ")" +
                   " | response(hipPeak)=" + F(report.PeakHipRotationErrorDegrees) +
                   " | anchor(peakHip/currentHip)=" + F(report.PeakHipAnchorErrorMeters) + "/" + F(report.HipAnchorErrorMeters) +
                   " | note=LEGACY_RESPONSE_OBSERVERS_RETIRED_V0317" +
                   " | abort=" + report.DriveAborted + "/" + (report.DriveAbortReason ?? "<none>");
        }

        private static string F(float value) => value.ToString("0.######", System.Globalization.CultureInfo.InvariantCulture);
        private static string V(Vector3 v) => "(" + F(v.x) + "," + F(v.y) + "," + F(v.z) + ")";
    }
}
