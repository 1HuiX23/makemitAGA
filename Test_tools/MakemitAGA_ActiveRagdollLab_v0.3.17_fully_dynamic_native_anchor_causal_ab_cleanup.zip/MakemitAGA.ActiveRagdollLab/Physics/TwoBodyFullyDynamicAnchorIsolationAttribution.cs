using System;
using System.Globalization;
using MakemitAGA.ActiveRagdollLab.Configuration;
using MakemitAGA.ActiveRagdollLab.Model;
using UnityEngine;
using Object = UnityEngine.Object;

namespace MakemitAGA.ActiveRagdollLab.Physics
{
    /// <summary>
    /// ARL v0.3.17 fully-dynamic rotational-receiver native CharacterJoint anchor causal A/B.
    ///
    /// F0 and F1 are independent Pelvis/Chest Rigidbody pairs. Both Pelvis and Chest bodies are
    /// non-kinematic only while the trace-scoped sandbox experiment is active. Pelvis translation is frozen,
    /// so this experiment remains a rotational-receiver foundation; Chest translation is solver-constrained.
    ///
    /// v0.3.16.5 closed the common Rigidbody/Transform state-domain defect and produced the first complete
    /// scorable fully-dynamic receiver dataset. v0.3.17 therefore returns to the unresolved v0.3.15 question:
    /// F0 keeps the calibrated source/spine CharacterJoint anchor, while F1 moves only the Chest-side native
    /// anchor to the explicit Chest COM and recomputes the Pelvis connectedAnchor for exact world coincidence.
    /// Both lanes keep preprocessing ON and retain the v0.3.16.5 Rigidbody-domain reset/rebind/safety foundation.
    /// Production TwoBodyShadowProxy and the bilateral Single-Leg chain receive no feedback from this sandbox.
    /// </summary>
    internal sealed class TwoBodyFullyDynamicAnchorIsolationAttribution
    {
        internal const string Mode =
            "TWOBODY_FULLY_DYNAMIC_ROTATIONAL_RECEIVER_CHARACTERJOINT_ANCHOR_CAUSAL_AB_V0317";

        internal const string Scope =
            "ISOLATED_NO_PRODUCTION_FEEDBACK;F0_CALIBRATED_SOURCE_JOINT;F1_CHEST_COM_NATIVE_ANCHOR;PREPROCESSING_ON_BOTH;" +
            "BOTH_PELVIS_AND_CHEST_DYNAMIC_ONLY_DURING_TRACE;DRIVE_ON_ARMS_KINEMATIC_SANDBOX;RUN_START_RIGIDBODY_TRANSFORM_POSE_SYNC_HARD_GATE;PHYSICAL_GEOMETRY_RIGIDBODY_DOMAIN_ONLY;RUN_START_NATIVE_ANCHOR_REBIND;TWO_PASSIVE_DYNAMIC_PHYSICS_SOLVES_BEFORE_CONTROL;PELVIS_TRANSLATION_FROZEN;CHEST_TRANSLATION_SOLVER_CONSTRAINED;" +
            "EXPLICIT_BOX_COM_AND_INERTIA;PELVIS_SOURCE_AUTHORITY=V035_V036_INERTIA_GYRO_PD;" +
            "NO_TARGET_A_FEEDFORWARD;NO_HIP_REACTION_INJECTION;NO_REACTION_CANCELLATION;" +
            "CHEST_RELATIVE_PD_IS_CHILD_ONLY_FORCE_MODE_ACCELERATION_IN_BOTH_LANES;" +
            "NO_COLLIDERS;NO_GRAVITY;PRODUCTION_TORSO_AND_SINGLE_LEG_FROZEN";

        internal const string PriorClosure =
            "V03165_STATE_DOMAIN_SYNC_STRONG_PASS;FULLY_DYNAMIC_RECEIVER_5352_SCORABLE_SAMPLES_NO_SANDBOX_FAULT;" +
            "PREPROCESSING_ON_OFF_NO_MATERIAL_DIFFERENCE;KEEP_PREPROCESSING_ON_FOR_MINIMUM_VARIABLE_CHANGE;" +
            "RESTORE_NATIVE_ANCHOR_CAUSAL_AB_TO_RESOLVE_V0315_LEVER_TRANSFER_QUESTION";

        private const int MinDecisionSamples = 128;
        // Pre-registered v0.3.17 decision thresholds. These are deliberately broad material-effect gates,
        // not controller tuning targets: F1 must collapse the Chest lever/moment while avoiding >10%
        // dynamic-parent or child-tracking regression. The 1mm anchor P99 bound is far below the existing
        // 150mm runtime fail-close and only defines a high-quality scorable topology result.
        private const float MaterialRegressionRatio = 1.10f;
        private const float ChestCollapseRatio = 0.25f;
        private const float MaxScorableAnchorP99Meters = 0.001f;
        private const float MinF0ChestMomentExcitationP99 = 0.02f;
        private const int PassiveDynamicFixedSteps = 2;
        private const int WarmupFixedSteps = 2;
        private const int ActivationTelemetryFixedSteps = 6;
        // This is a run-start invariant check after exact anchor rebinding, not a replacement
        // for the existing JointAnchorSafetyDistance runtime safety contract.
        private const float RunStartAnchorClosureTolerance = 0.001f; // 1 mm
        private const float RunStartStateDomainPositionTolerance = 0.001f; // 1 mm
        private const float RunStartStateDomainRotationToleranceDegrees = 0.1f;
        private const float Epsilon = 1e-6f;

        private enum ActivationStage
        {
            Inactive = 0,
            DynamicPassive = 1,
            ControlActive = 2
        }

        private readonly ActiveRagdollLabProfile _profile;
        private readonly BoneAuditReport _audit;

        private GameObject _root;
        private Lane _f0;
        private Lane _f1;

        private Quaternion _pelvisBoneToProxy = Quaternion.identity;
        private Quaternion _chestBoneToProxy = Quaternion.identity;
        private Vector3 _sampledPelvisPosition;
        private Quaternion _sampledPelvisRotation = Quaternion.identity;
        private Vector3 _sampledChestPosition;
        private Quaternion _sampledChestRotation = Quaternion.identity;
        private Vector3 _sampledPelvisAngularVelocity;
        private Vector3 _sampledChestAngularVelocity;
        private Vector3 _sampledTargetRelativeAngularVelocityLocal;
        private Quaternion _previousPelvisRotation = Quaternion.identity;
        private Quaternion _previousChestRotation = Quaternion.identity;
        private Quaternion _previousTargetRelativeRotation = Quaternion.identity;
        private bool _hasPreviousSourceSample;
        private bool _sampleValid;

        private bool _built;
        // _driveEnabled means the sandbox is armed by arl_drive(on); it stays kinematic until trace begins.
        private bool _driveEnabled;
        private bool _traceEnabled;
        private bool _physicalActive;
        private bool _faulted;
        private int _faultCount;
        private string _faultReason = "NONE";
        private string _faultContext = "NONE";
        private int _warmupStepsRemaining;
        private int _fixedStepsSinceActivation;
        private int _activationCount;
        private ActivationStage _activationStage = ActivationStage.Inactive;
        private int _passiveStepsRemaining;
        private int _controllerFixedSteps;
        private bool _controlEverApplied;
        private float _runStartF0AnchorClosure;
        private float _runStartF1AnchorClosure;
        private float _runStartF0BodySeparation;
        private float _runStartF1BodySeparation;
        private float _runStartF0SourceAnchorError;
        private float _runStartF1ChestComLocalError;
        private float _runStartF0PelvisRbTfPositionDelta;
        private float _runStartF0ChestRbTfPositionDelta;
        private float _runStartF1PelvisRbTfPositionDelta;
        private float _runStartF1ChestRbTfPositionDelta;
        private float _runStartF0PelvisRbTfRotationDelta;
        private float _runStartF0ChestRbTfRotationDelta;
        private float _runStartF1PelvisRbTfRotationDelta;
        private float _runStartF1ChestRbTfRotationDelta;
        private float _runStartF0AnchorVelocityMismatch;
        private float _runStartF1AnchorVelocityMismatch;

        private int _samples;
        private int _normalSamples;
        private int _normalSteadySamples;
        private int _normalTransitionSamples;
        private int _sourceSamples;
        private int _recoverySamples;
        private int _idleSamples;
        private int _validNormalSamples;
        private int _invalidNormalSamples;

        internal TwoBodyFullyDynamicAnchorIsolationAttribution(
            ActiveRagdollLabProfile profile,
            BoneAuditReport audit)
        {
            _profile = profile ?? throw new ArgumentNullException(nameof(profile));
            _audit = audit ?? throw new ArgumentNullException(nameof(audit));
        }

        internal bool Built =>
            _built &&
            _root != null &&
            _f0 != null && _f0.Ready &&
            _f1 != null && _f1.Ready;

        internal string Build(TwoBodyShadowProxy production)
        {
            if (production == null || !production.IsBuilt ||
                production.PelvisBody == null || production.ChestBody == null)
                return "ARL v0.3.17 fully-dynamic anchor causal A/B build | success=False | reason=PRODUCTION_TWOBODY_NOT_READY";

            if (_audit.Pelvis == null || _audit.Chest == null)
                return "ARL v0.3.17 fully-dynamic anchor causal A/B build | success=False | reason=SOURCE_TORSO_NOT_READY";

            if (Built)
                return GetStatus(production);

            Vector3 pelvisSize = production.PelvisProxyBoxSize;
            Vector3 chestSize = production.ChestProxyBoxSize;
            Vector3 pelvisCom = production.PelvisProxyBoxCenter;
            Vector3 chestCom = production.ChestProxyBoxCenter;
            Vector3 pelvisInertia = AnalyticalUniformBoxInertia(_profile.PelvisMass, pelvisSize);
            Vector3 chestInertia = AnalyticalUniformBoxInertia(_profile.ChestMass, chestSize);

            if (!PositiveSize(pelvisSize) || !PositiveSize(chestSize) ||
                !Finite(pelvisCom) || !Finite(chestCom) ||
                !PositiveTensor(pelvisInertia) || !PositiveTensor(chestInertia))
                return "ARL v0.3.17 fully-dynamic anchor causal A/B build | success=False | reason=INVALID_EXPLICIT_BOX_MASS_PROPERTIES";

            try
            {
                Quaternion frameRotation = BuildCharacterFrameRotation();
                _pelvisBoneToProxy = Normalize(Quaternion.Inverse(_audit.Pelvis.rotation) * frameRotation);
                _chestBoneToProxy = Normalize(Quaternion.Inverse(_audit.Chest.rotation) * frameRotation);
                SampleSourcePoseInternal(false);
                if (!_sampleValid)
                    throw new InvalidOperationException("INITIAL_SOURCE_SAMPLE_INVALID");

                _root = new GameObject("ARL_TwoBodyFullyDynamicAnchorIsolation_V0317");
                _root.hideFlags = HideFlags.DontSave;
                _root.layer = _audit.TargetRoot != null ? _audit.TargetRoot.gameObject.layer : 0;

                _f0 = CreateLane(
                    "F0_CALIBRATED",
                    false,
                    pelvisSize,
                    pelvisCom,
                    pelvisInertia,
                    chestSize,
                    chestCom,
                    chestInertia);

                _f1 = CreateLane(
                    "F1_CHEST_COM",
                    true,
                    pelvisSize,
                    pelvisCom,
                    pelvisInertia,
                    chestSize,
                    chestCom,
                    chestInertia);

                _built = true;
                if (!FoundationParityValidated())
                    throw new InvalidOperationException("FULLY_DYNAMIC_AB_FOUNDATION_PARITY_READBACK_MISMATCH");

                SafeResetBodies();
                ResetStatistics();

                return
                    "ARL v0.3.17 fully-dynamic anchor causal A/B build" +
                    " | success=True" +
                    " | mode=" + Mode +
                    " | productionPelvisKinematic=" + production.PelvisBody.isKinematic +
                    " | receiverBodiesDynamicDuringTrace=True" +
                    " | pelvisTranslationFrozen=True" +
                    " | F0/F1 preprocessing=ON/ON" +
                    " | F0/F1 anchor=CALIBRATED_SOURCE_JOINT/CHEST_COM" +
                    " | boxP/C=" + V(pelvisSize) + "/" + V(chestSize) +
                    " | COM_P/C=" + V(pelvisCom) + "/" + V(chestCom) +
                    " | inertiaP/C=" + V(pelvisInertia) + "/" + V(chestInertia) +
                    " | foundationParity=True" +
                    " | productionFeedback=False";
            }
            catch (Exception e)
            {
                Destroy();
                return
                    "ARL v0.3.17 fully-dynamic anchor causal A/B build" +
                    " | success=False" +
                    " | reason=" + e.GetType().Name + ":" + (e.Message ?? "<none>");
            }
        }

        internal void SampleSourcePose()
        {
            if (!Built)
                return;

            SampleSourcePoseInternal(true);
            // While merely armed (drive on, trace off) the sandbox remains a kinematic preview that
            // follows the latest source pose. It must not accumulate hidden physics debt during PCA/setup.
            if (_sampleValid && !_physicalActive)
                SafeResetBodies();
        }

        internal void FixedUpdate(TwoBodyShadowProxy production)
        {
            if (!Built || !_driveEnabled || !_traceEnabled || !_physicalActive || _faulted)
                return;

            try
            {
                _fixedStepsSinceActivation++;

                if (production == null || !production.IsBuilt || !production.DriveEnabled)
                {
                    FailClose("PRODUCTION_TORSO_DRIVE_NOT_ACTIVE");
                    return;
                }
                if (production.Report == null)
                {
                    FailClose("PRODUCTION_TORSO_REPORT_NOT_AVAILABLE");
                    return;
                }

                if (!_sampleValid || !LaneFinite(_f0) || !LaneFinite(_f1))
                {
                    FailClose("NON_FINITE_OR_INVALID_SOURCE_STATE");
                    return;
                }
                if (_activationStage == ActivationStage.Inactive)
                {
                    FailClose("PHYSICAL_ACTIVE_WITH_INACTIVE_ACTIVATION_STAGE");
                    return;
                }

                bool f0GeometryOk = TryGetGeometry(_f0, out float f0Closure, out float f0Separation, out float f0SeparationLimit);
                bool f1GeometryOk = TryGetGeometry(_f1, out float f1Closure, out float f1Separation, out float f1SeparationLimit);
                if (!f0GeometryOk || !f1GeometryOk)
                {
                    EmitActivationStepTelemetry(
                        false,
                        f0Closure, f0Separation, f0SeparationLimit,
                        f1Closure, f1Separation, f1SeparationLimit);
                    string lane = !f0GeometryOk && !f1GeometryOk ? "BOTH" : (!f0GeometryOk ? "F0" : "F1");
                    FailClose(
                        "DYNAMIC_RECEIVER_GEOMETRY_SAFETY_GATE",
                        BuildGeometryContext(
                            lane,
                            f0Closure, f0Separation, f0SeparationLimit,
                            f1Closure, f1Separation, f1SeparationLimit));
                    return;
                }

                // v0.3.17 retained state-domain hardening: the first two complete physics solves are passive.
                // No controller command is even constructed in this stage. Geometry observed at the
                // next FixedUpdate therefore reflects native Rigidbody + CharacterJoint behavior only.
                if (_activationStage == ActivationStage.DynamicPassive)
                {
                    EmitActivationStepTelemetry(
                        false,
                        f0Closure, f0Separation, f0SeparationLimit,
                        f1Closure, f1Separation, f1SeparationLimit);

                    if (_passiveStepsRemaining > 0)
                    {
                        _passiveStepsRemaining--;
                        return;
                    }

                    _activationStage = ActivationStage.ControlActive;
                    _warmupStepsRemaining = WarmupFixedSteps;
                    Plugin.Logger?.LogWarning(
                        "[ARL][V0317_FULLY_DYNAMIC_CONTROL_STAGE_BEGIN]" +
                        " activation=" + _activationCount +
                        " | fixedSinceActivation=" + _fixedStepsSinceActivation +
                        " | passivePhysicsSolvesSurvived=" + PassiveDynamicFixedSteps +
                        " | F0 anchorMm/bodyMm=" + F(1000f * f0Closure) + "/" + F(1000f * f0Separation) +
                        " | F1 anchorMm/bodyMm=" + F(1000f * f1Closure) + "/" + F(1000f * f1Separation) +
                        " | controllerAppliedPreviously=False" +
                        " | controlWarmupSteps=" + WarmupFixedSteps);
                }

                Quaternion targetPelvisRotation = production.CurrentPelvisCommandRotation;
                Vector3 targetPelvisW = production.Report.PoseBridgeCommandAngularVelocity;
                Quaternion targetRelativeRotation = Normalize(
                    Quaternion.Inverse(_sampledPelvisRotation) * _sampledChestRotation);

                if (!Finite(targetPelvisRotation) || !Finite(targetPelvisW) ||
                    !Finite(targetRelativeRotation) || !Finite(_sampledTargetRelativeAngularVelocityLocal))
                {
                    FailClose("NON_FINITE_CONTROL_TARGET");
                    return;
                }

                if (_warmupStepsRemaining > 0)
                    _warmupStepsRemaining--;
                else
                    ObserveSettled(production);

                ApplyLaneControl(
                    _f0,
                    targetPelvisRotation,
                    targetPelvisW,
                    targetRelativeRotation,
                    _sampledTargetRelativeAngularVelocityLocal);

                ApplyLaneControl(
                    _f1,
                    targetPelvisRotation,
                    targetPelvisW,
                    targetRelativeRotation,
                    _sampledTargetRelativeAngularVelocityLocal);

                _controlEverApplied = true;
                _controllerFixedSteps++;
                EmitActivationStepTelemetry(
                    true,
                    f0Closure, f0Separation, f0SeparationLimit,
                    f1Closure, f1Separation, f1SeparationLimit);
            }
            catch (Exception e)
            {
                FailClose("FIXEDUPDATE:" + e.GetType().Name + ":" + (e.Message ?? "<none>"));
            }
        }

        internal string SetDrive(bool enabled, TwoBodyShadowProxy production)
        {
            if (!Built)
                return "ARL v0.3.17 fully-dynamic anchor causal A/B drive | built=False";

            if (enabled)
            {
                if (_faulted)
                    return "ARL v0.3.17 fully-dynamic anchor causal A/B drive | armed=False | reason=FAULT_LATCHED_REBUILD_REQUIRED";
                if (production == null || !production.IsBuilt || !production.DriveEnabled)
                    return "ARL v0.3.17 fully-dynamic anchor causal A/B drive | armed=False | reason=PRODUCTION_TORSO_DRIVE_REQUIRED";
                if (!_sampleValid)
                    return "ARL v0.3.17 fully-dynamic anchor causal A/B drive | armed=False | reason=SOURCE_SAMPLE_INVALID";

                // v0.3.16.5 hotfix: drive ON only arms the experiment. Keep all four receiver
                // bodies kinematic through PCA/stack preparation so no unobserved constraint debt
                // can accumulate before the actual trace-scoped causal window.
                _driveEnabled = true;
                _traceEnabled = false;
                _physicalActive = false;
                SetLaneDynamic(_f0, false);
                SetLaneDynamic(_f1, false);
                SafeResetBodies();
                _activationStage = ActivationStage.Inactive;
                _passiveStepsRemaining = 0;
                _warmupStepsRemaining = WarmupFixedSteps;
                _fixedStepsSinceActivation = 0;
                _controllerFixedSteps = 0;
                _controlEverApplied = false;
            }
            else
            {
                _traceEnabled = false;
                _physicalActive = false;
                _driveEnabled = false;
                SetLaneDynamic(_f0, false);
                SetLaneDynamic(_f1, false);
                SafeResetBodies();
                _activationStage = ActivationStage.Inactive;
                _passiveStepsRemaining = 0;
                _warmupStepsRemaining = WarmupFixedSteps;
                _fixedStepsSinceActivation = 0;
                _controllerFixedSteps = 0;
                _controlEverApplied = false;
            }

            return
                "ARL v0.3.17 fully-dynamic anchor causal A/B drive" +
                " | armed=" + _driveEnabled +
                " | physicalActive=" + _physicalActive +
                " | activationPolicy=TRACE_ONLY_THEN_TWO_PASSIVE_DYNAMIC_SOLVES" +
                " | F0 dynamic(P/C)=" + IsDynamic(_f0.PelvisBody) + "/" + IsDynamic(_f0.ChestBody) +
                " | F1 dynamic(P/C)=" + IsDynamic(_f1.PelvisBody) + "/" + IsDynamic(_f1.ChestBody) +
                " | productionPelvisKinematic=" +
                (production != null && production.PelvisBody != null && production.PelvisBody.isKinematic) +
                " | productionFeedback=False";
        }

        internal void BeginTrace(TwoBodyShadowProxy production)
        {
            if (!Built || _faulted)
                return;

            try
            {
                ResetStatistics();

                if (!_driveEnabled)
                {
                    FailClose("TRACE_BEGIN_SANDBOX_NOT_ARMED");
                    return;
                }
                if (production == null || !production.IsBuilt || !production.DriveEnabled)
                {
                    FailClose("TRACE_BEGIN_PRODUCTION_TORSO_DRIVE_NOT_ACTIVE");
                    return;
                }
                if (production.PelvisBody == null || !production.PelvisBody.isKinematic)
                {
                    FailClose("TRACE_BEGIN_PRODUCTION_PELVIS_NOT_KINEMATIC");
                    return;
                }

                // Pull a fresh run-start source sample, force a kinematic reset, then rebuild each
                // lane's native CharacterJoint anchor pair at the CURRENT source pose. This removes
                // the build-time connectedAnchor debt exposed by the first v0.3.16 run.
                SampleSourcePoseInternal(false);
                if (!_sampleValid)
                {
                    FailClose("TRACE_BEGIN_SOURCE_SAMPLE_INVALID");
                    return;
                }

                _physicalActive = false;
                _traceEnabled = false;
                SetLaneDynamic(_f0, false);
                SetLaneDynamic(_f1, false);
                SafeResetBodies();

                if (!ValidateRunStartStateDomainSync())
                {
                    FailClose(
                        "TRACE_BEGIN_STATE_DOMAIN_SYNC_FAILED",
                        BuildRunStartStateDomainContext());
                    return;
                }

                if (!RebindRunStartNativeAnchors())
                {
                    FailClose("TRACE_BEGIN_NATIVE_ANCHOR_REBIND_FAILED");
                    return;
                }

                if (!ValidateRunStartAnchorSemantics(
                        out _runStartF0SourceAnchorError,
                        out _runStartF1ChestComLocalError))
                {
                    FailClose(
                        "TRACE_BEGIN_ANCHOR_SEMANTICS_PREFLIGHT_FAILED",
                        BuildRunStartSemanticContext());
                    return;
                }

                if (!FoundationParityValidated())
                {
                    FailClose("TRACE_BEGIN_FOUNDATION_PARITY_FAILED_AFTER_REBIND");
                    return;
                }

                bool f0GeometryOk = TryGetGeometry(_f0, out _runStartF0AnchorClosure, out _runStartF0BodySeparation, out float f0SeparationLimit);
                bool f1GeometryOk = TryGetGeometry(_f1, out _runStartF1AnchorClosure, out _runStartF1BodySeparation, out float f1SeparationLimit);

                bool runStartClosureOk =
                    Finite(_runStartF0AnchorClosure) && _runStartF0AnchorClosure <= RunStartAnchorClosureTolerance &&
                    Finite(_runStartF1AnchorClosure) && _runStartF1AnchorClosure <= RunStartAnchorClosureTolerance;

                if (!f0GeometryOk || !f1GeometryOk || !runStartClosureOk)
                {
                    string lane =
                        (!f0GeometryOk || _runStartF0AnchorClosure > RunStartAnchorClosureTolerance) &&
                        (!f1GeometryOk || _runStartF1AnchorClosure > RunStartAnchorClosureTolerance)
                            ? "BOTH"
                            : ((!f0GeometryOk || _runStartF0AnchorClosure > RunStartAnchorClosureTolerance) ? "F0" : "F1");
                    FailClose(
                        "TRACE_BEGIN_GEOMETRY_PREFLIGHT_FAILED",
                        BuildGeometryContext(
                            lane,
                            _runStartF0AnchorClosure, _runStartF0BodySeparation, f0SeparationLimit,
                            _runStartF1AnchorClosure, _runStartF1BodySeparation, f1SeparationLimit));
                    return;
                }

                _runStartF0AnchorVelocityMismatch = ComputeAnchorVelocityMismatch(_f0);
                _runStartF1AnchorVelocityMismatch = ComputeAnchorVelocityMismatch(_f1);
                if (!Finite(_runStartF0AnchorVelocityMismatch) || !Finite(_runStartF1AnchorVelocityMismatch))
                {
                    FailClose(
                        "TRACE_BEGIN_ANCHOR_VELOCITY_PREFLIGHT_NON_FINITE",
                        "F0AnchorVelMismatch=" + F(_runStartF0AnchorVelocityMismatch) +
                        ";F1AnchorVelMismatch=" + F(_runStartF1AnchorVelocityMismatch));
                    return;
                }

                _traceEnabled = true;
                SetLaneDynamic(_f0, true);
                SetLaneDynamic(_f1, true);

                // Kinematic -> dynamic must not reopen the state-domain split. Fail before the first
                // physics solve if toggling authority changes either Rigidbody/Transform pose pair.
                if (!ValidateRunStartStateDomainSync())
                {
                    FailClose(
                        "TRACE_BEGIN_STATE_DOMAIN_SYNC_LOST_AFTER_DYNAMIC_TOGGLE",
                        BuildRunStartStateDomainContext());
                    return;
                }

                bool dynamicReadbackNow =
                    IsDynamic(_f0.PelvisBody) && IsDynamic(_f0.ChestBody) &&
                    IsDynamic(_f1.PelvisBody) && IsDynamic(_f1.ChestBody);
                if (!dynamicReadbackNow)
                {
                    FailClose(
                        "TRACE_BEGIN_DYNAMIC_READBACK_FAILED",
                        "F0(P/C)=" + IsDynamic(_f0.PelvisBody) + "/" + IsDynamic(_f0.ChestBody) +
                        ";F1(P/C)=" + IsDynamic(_f1.PelvisBody) + "/" + IsDynamic(_f1.ChestBody));
                    return;
                }

                _physicalActive = true;
                _activationStage = ActivationStage.DynamicPassive;
                _passiveStepsRemaining = PassiveDynamicFixedSteps;
                _warmupStepsRemaining = WarmupFixedSteps;
                _fixedStepsSinceActivation = 0;
                _controllerFixedSteps = 0;
                _controlEverApplied = false;
                _activationCount++;

                Plugin.Logger?.LogWarning(
                    "[ARL][V0317_FULLY_DYNAMIC_TRACE_ACTIVATION]" +
                    " activation=" + _activationCount +
                    " | F0 anchorMm/bodyMm=" + F(1000f * _runStartF0AnchorClosure) + "/" + F(1000f * _runStartF0BodySeparation) +
                    " | F1 anchorMm/bodyMm=" + F(1000f * _runStartF1AnchorClosure) + "/" + F(1000f * _runStartF1BodySeparation) +
                    " | anchorSemanticErrMm(F0Source/F1ComLocal)=" + F(1000f * _runStartF0SourceAnchorError) + "/" + F(1000f * _runStartF1ChestComLocalError) +
                    " | preprocessing(F0/F1)=" + _f0.Joint.enablePreprocessing + "/" + _f1.Joint.enablePreprocessing +
                    " | runStartRbTfPosMm(F0P/F0C/F1P/F1C)=" +
                    F(1000f * _runStartF0PelvisRbTfPositionDelta) + "/" + F(1000f * _runStartF0ChestRbTfPositionDelta) + "/" +
                    F(1000f * _runStartF1PelvisRbTfPositionDelta) + "/" + F(1000f * _runStartF1ChestRbTfPositionDelta) +
                    " | runStartRbTfRotDeg(F0P/F0C/F1P/F1C)=" +
                    F(_runStartF0PelvisRbTfRotationDelta) + "/" + F(_runStartF0ChestRbTfRotationDelta) + "/" +
                    F(_runStartF1PelvisRbTfRotationDelta) + "/" + F(_runStartF1ChestRbTfRotationDelta) +
                    " | runStartAnchorVelMismatch(F0/F1)=" + F(_runStartF0AnchorVelocityMismatch) + "/" + F(_runStartF1AnchorVelocityMismatch) +
                    " | runStartAnchorToleranceMm=" + F(1000f * RunStartAnchorClosureTolerance) +
                    " | runtimeAnchorSafetyMm=" + F(1000f * _profile.JointAnchorSafetyDistance) +
                    " | dynamicReadback=True/True/True/True" +
                    " | stage=DYNAMIC_PASSIVE" +
                    " | passivePhysicsSolves=" + PassiveDynamicFixedSteps +
                    " | controllerApplied=False" +
                    " | physicalActive=True | productionFeedback=False");
            }
            catch (Exception e)
            {
                FailClose("TRACE_BEGIN:" + e.GetType().Name + ":" + (e.Message ?? "<none>"));
            }
        }

        internal string Finalize(TwoBodyShadowProxy production)
        {
            _traceEnabled = false;
            _physicalActive = false;
            _activationStage = ActivationStage.Inactive;
            _passiveStepsRemaining = 0;
            try { SetLaneDynamic(_f0, false); } catch { }
            try { SetLaneDynamic(_f1, false); } catch { }
            SafeResetBodies();
            return GetStatus(production);
        }

        internal string ResetPose()
        {
            if (!Built)
                return "ARL v0.3.17 fully-dynamic anchor causal A/B reset | built=False";
            if (_faulted)
                return "ARL v0.3.17 fully-dynamic anchor causal A/B reset | reset=False | reason=FAULT_LATCHED_REBUILD_REQUIRED";

            // Production TwoBodyShadowProxy.ResetPose() disables its drive. The isolated receiver
            // must therefore reset to the same safe kinematic preview state and require a fresh
            // arl_drive(on); otherwise it would remain dynamically active without its source authority.
            _traceEnabled = false;
            _physicalActive = false;
            _driveEnabled = false;
            SetLaneDynamic(_f0, false);
            SetLaneDynamic(_f1, false);
            SafeResetBodies();
            _activationStage = ActivationStage.Inactive;
            _passiveStepsRemaining = 0;
            _warmupStepsRemaining = WarmupFixedSteps;
            _fixedStepsSinceActivation = 0;
            _controllerFixedSteps = 0;
            _controlEverApplied = false;
            return "ARL v0.3.17 fully-dynamic anchor causal A/B reset | reset=True | armed=False | physicalActive=False | freshDriveRequired=True";
        }

        internal void MarkExternalFault(string phase, Exception e)
        {
            string detail = e == null
                ? "unknown"
                : e.GetType().Name + ":" + (e.Message ?? "<none>");
            FailClose((phase ?? "UNKNOWN_PHASE") + ":" + detail);
        }

        internal string GetStatus(TwoBodyShadowProxy production)
        {
            bool foundationParity = Built && FoundationParityValidated();
            bool productionPelvisKinematic =
                production != null &&
                production.PelvisBody != null &&
                production.PelvisBody.isKinematic;
            bool dynamicReadback =
                _f0 != null && _f1 != null &&
                _f0.PelvisDynamicObserved && _f0.ChestDynamicObserved &&
                _f1.PelvisDynamicObserved && _f1.ChestDynamicObserved;
            bool scorable =
                !_faulted &&
                foundationParity &&
                productionPelvisKinematic &&
                dynamicReadback &&
                _validNormalSamples >= MinDecisionSamples &&
                _invalidNormalSamples == 0 &&
                _f0.ReactionValidSamples >= MinDecisionSamples &&
                _f1.ReactionValidSamples >= MinDecisionSamples;

            string reason;
            if (_faulted) reason = "SANDBOX_FAULT_FAIL_CLOSED";
            else if (!foundationParity) reason = "FOUNDATION_PARITY_FAILED";
            else if (!productionPelvisKinematic) reason = "PRODUCTION_PELVIS_NOT_KINEMATIC";
            else if (!dynamicReadback) reason = "FULLY_DYNAMIC_READBACK_NOT_OBSERVED";
            else if (_invalidNormalSamples > 0) reason = "INVALID_NORMAL_SAMPLE_PRESENT";
            else if (_validNormalSamples < MinDecisionSamples) reason = "INSUFFICIENT_NORMAL_SAMPLES";
            else if (_f0.ReactionValidSamples < MinDecisionSamples && _f1.ReactionValidSamples < MinDecisionSamples) reason = "INSUFFICIENT_REACTION_SAMPLES_BOTH";
            else if (_f0.ReactionValidSamples < MinDecisionSamples) reason = "INSUFFICIENT_REACTION_SAMPLES_F0";
            else if (_f1.ReactionValidSamples < MinDecisionSamples) reason = "INSUFFICIENT_REACTION_SAMPLES_F1";
            else reason = "FULLY_DYNAMIC_ANCHOR_DATASET_SCORABLE";

            string decision = BuildDecision(scorable);

            return
                "ARL v0.3.17 fully-dynamic Pelvis/Chest native anchor causal A/B" +
                " | mode=" + Mode +
                " | built=" + Built +
                "/armed=" + _driveEnabled +
                "/physical=" + _physicalActive +
                "/trace=" + _traceEnabled +
                "/productionFeedback=False" +
                " | samples=" + _samples +
                "/normal=" + _normalSamples +
                "(st/tr=" + _normalSteadySamples + "/" + _normalTransitionSamples + ")" +
                "/valid=" + _validNormalSamples +
                "/invalid=" + _invalidNormalSamples +
                " | phase(src/rec/idle)=" + _sourceSamples + "/" + _recoverySamples + "/" + _idleSamples +
                " | reactionValid(F0/F1)=" + _f0.ReactionValidSamples + "/" + _f1.ReactionValidSamples +
                " | pelvisRotP99(F0/F1)=" + F(_f0.PelvisRotationError.P99) + "/" + F(_f1.PelvisRotationError.P99) +
                "/ratio=" + F(Ratio(_f1.PelvisRotationError.P99, _f0.PelvisRotationError.P99)) +
                " | chestRelRotP99(F0/F1)=" + F(_f0.ChestRelativeRotationError.P99) + "/" + F(_f1.ChestRelativeRotationError.P99) +
                "/ratio=" + F(Ratio(_f1.ChestRelativeRotationError.P99, _f0.ChestRelativeRotationError.P99)) +
                " | chestComPosMmP99(F0/F1)=" + F(1000f * _f0.ChestComPositionError.P99) + "/" + F(1000f * _f1.ChestComPositionError.P99) +
                " | anchorMmP99(F0/F1)=" + F(1000f * _f0.AnchorClosure.P99) + "/" + F(1000f * _f1.AnchorClosure.P99) +
                " | jointForceP99(F0/F1)=" + F(_f0.JointForce.P99) + "/" + F(_f1.JointForce.P99) +
                " | jointTorqueP99(F0/F1)=" + F(_f0.JointTorque.P99) + "/" + F(_f1.JointTorque.P99) +
                " | chestLeverMmP99(F0/F1)=" + F(1000f * _f0.ChestLever.P99) + "/" + F(1000f * _f1.ChestLever.P99) +
                "/ratio=" + F(Ratio(_f1.ChestLever.P99, _f0.ChestLever.P99)) +
                " | chestMomentP99(F0/F1)=" + F(_f0.ChestForceMoment.P99) + "/" + F(_f1.ChestForceMoment.P99) +
                "/ratio=" + F(Ratio(_f1.ChestForceMoment.P99, _f0.ChestForceMoment.P99)) +
                " | pelvisLeverMmP99(F0/F1)=" + F(1000f * _f0.PelvisLever.P99) + "/" + F(1000f * _f1.PelvisLever.P99) +
                " | pelvisMomentP99(F0/F1)=" + F(_f0.PelvisForceMoment.P99) + "/" + F(_f1.PelvisForceMoment.P99) +
                "/ratio=" + F(Ratio(_f1.PelvisForceMoment.P99, _f0.PelvisForceMoment.P99)) +
                " | pelvisAuthorityTorqueP99(F0/F1)=" + F(_f0.PelvisAuthorityTorque.P99) + "/" + F(_f1.PelvisAuthorityTorque.P99) +
                " | authorityClamp(F0/F1)=" + _f0.PelvisAuthorityClampSamples + "/" + _f1.PelvisAuthorityClampSamples +
                " | dynamicObserved(F0P/F0C/F1P/F1C)=" +
                _f0.PelvisDynamicObserved + "/" + _f0.ChestDynamicObserved + "/" +
                _f1.PelvisDynamicObserved + "/" + _f1.ChestDynamicObserved +
                " | runStartAnchorMm(F0/F1)=" + F(1000f * _runStartF0AnchorClosure) + "/" + F(1000f * _runStartF1AnchorClosure) +
                " | runStartBodyMm(F0/F1)=" + F(1000f * _runStartF0BodySeparation) + "/" + F(1000f * _runStartF1BodySeparation) +
                " | runStartAnchorSemanticErrMm(F0Source/F1ComLocal)=" +
                F(1000f * _runStartF0SourceAnchorError) + "/" + F(1000f * _runStartF1ChestComLocalError) +
                " | preprocessing(F0/F1)=" + _f0.Joint.enablePreprocessing + "/" + _f1.Joint.enablePreprocessing +
                " | runStartRbTfPosMm(F0P/F0C/F1P/F1C)=" +
                F(1000f * _runStartF0PelvisRbTfPositionDelta) + "/" + F(1000f * _runStartF0ChestRbTfPositionDelta) + "/" +
                F(1000f * _runStartF1PelvisRbTfPositionDelta) + "/" + F(1000f * _runStartF1ChestRbTfPositionDelta) +
                " | runStartRbTfRotDeg(F0P/F0C/F1P/F1C)=" +
                F(_runStartF0PelvisRbTfRotationDelta) + "/" + F(_runStartF0ChestRbTfRotationDelta) + "/" +
                F(_runStartF1PelvisRbTfRotationDelta) + "/" + F(_runStartF1ChestRbTfRotationDelta) +
                " | runStartAnchorVelMismatch(F0/F1)=" +
                F(_runStartF0AnchorVelocityMismatch) + "/" + F(_runStartF1AnchorVelocityMismatch) +
                " | activation=" + _activationCount + "/fixedSinceActivation=" + _fixedStepsSinceActivation +
                "/stage=" + ActivationStageName(_activationStage) +
                "/passiveRemaining=" + _passiveStepsRemaining +
                "/controllerFixed=" + _controllerFixedSteps +
                "/controlEver=" + _controlEverApplied +
                " | foundationParity=" + foundationParity +
                " | productionPelvisKinematic=" + productionPelvisKinematic +
                " | fault=" + _faulted + "/" + _faultCount + "/" + (_faultReason ?? "NONE") +
                " | faultContext=" + (_faultContext ?? "NONE") +
                " | scorable=" + scorable +
                " | reason=" + reason +
                " | decision=" + decision;
        }

        internal string GetFullText(TwoBodyShadowProxy production)
        {
            return
                GetStatus(production) + Environment.NewLine +
                "Scope=" + Scope + Environment.NewLine +
                "PriorClosure=" + PriorClosure + Environment.NewLine +
                "OnlyABVariable=both lanes keep identical Rigidbody mass/inertia, controller, activation, preprocessing=ON and solver limits; F0 uses the calibrated source/spine CharacterJoint anchor, F1 moves only the Chest-side native anchor to the explicit Chest COM and recomputes connectedAnchor for exact world coincidence." + Environment.NewLine +
                "PelvisAuthority=exact production Pose-Bridge command rotation and command angular velocity feed the recovered v0.3.5/v0.3.6 P+D angular-acceleration controller; final MaxA clamp; physical torque is I*alpha + omega x (I*omega), ForceMode.Force." + Environment.NewLine +
                "ChestAuthority=frozen child-only relative P+D semantics in both lanes, ForceMode.Acceleration; no equal/opposite control torque is added in v0.3.17, so this is a receiver-foundation experiment rather than a production-ready full-body actuator." + Environment.NewLine +
                "ActivationIsolation=after exact run-start rebind and dynamic readback, both lanes undergo two complete passive physics solves with zero controller torque; only if geometry survives does CONTROL_ACTIVE begin, followed by the unchanged two-step measurement warmup." + Environment.NewLine +
                "Excluded=target-angular-acceleration feedforward; full Hip reaction injection; reaction cancellation; tether; Knee/contact input; gravity; colliders; production feedback." + Environment.NewLine +
                "DecisionRule1=score only when foundationParity, all four dynamicObserved flags, productionPelvisKinematic, zero invalid Normal samples and at least 128 paired Normal/reaction-valid samples are true." + Environment.NewLine +
                "DecisionRule2=pre-registered material gates: require F0 Chest-moment P99 >= 0.02Nm excitation; F1/F0 Chest lever and Chest force-moment ratios <=0.25; F1 anchor P99 <=1mm; F1/F0 Chest-relative rotation, dynamic Pelvis rotation and Pelvis-side force-moment ratios each <=1.10 for SUPPORT." + Environment.NewLine +
                "DecisionRule3=if Chest moment collapses but Pelvis rotation or Pelvis-side moment exceeds 1.10x F0, reject Chest-COM for dynamic-parent burden transfer; if child tracking/anchor bound fails, reject for constraint/child regression. No v0.3.17 result directly authorizes production migration because Pelvis translation remains frozen and the Chest controller is still child-only." + Environment.NewLine +
                "Key=" + BuildKey(production);
        }

        private string BuildDecision(bool scorable)
        {
            if (!scorable)
                return "UNSCORED";

            float f0ChestMoment = _f0.ChestForceMoment.P99;
            if (!Finite(f0ChestMoment) || f0ChestMoment < MinF0ChestMomentExcitationP99)
                return "INCONCLUSIVE_INSUFFICIENT_F0_CHEST_MOMENT_EXCITATION";

            float chestLeverRatio = DecisionRatio(_f1.ChestLever.P99, _f0.ChestLever.P99);
            float chestMomentRatio = DecisionRatio(_f1.ChestForceMoment.P99, f0ChestMoment);
            float chestRelativeRotationRatio = DecisionRatio(_f1.ChestRelativeRotationError.P99, _f0.ChestRelativeRotationError.P99);
            float pelvisRotationRatio = DecisionRatio(_f1.PelvisRotationError.P99, _f0.PelvisRotationError.P99);
            float pelvisMomentRatio = DecisionRatio(_f1.PelvisForceMoment.P99, _f0.PelvisForceMoment.P99);

            bool chestCollapsed =
                Finite(chestLeverRatio) && chestLeverRatio <= ChestCollapseRatio &&
                Finite(chestMomentRatio) && chestMomentRatio <= ChestCollapseRatio;
            bool childBounded =
                Finite(_f1.AnchorClosure.P99) && _f1.AnchorClosure.P99 <= MaxScorableAnchorP99Meters &&
                Finite(chestRelativeRotationRatio) && chestRelativeRotationRatio <= MaterialRegressionRatio;
            bool pelvisBounded =
                Finite(pelvisRotationRatio) && pelvisRotationRatio <= MaterialRegressionRatio &&
                Finite(pelvisMomentRatio) && pelvisMomentRatio <= MaterialRegressionRatio;

            if (chestCollapsed && childBounded && pelvisBounded)
                return "F1_SUPPORTED_CHEST_MOMENT_COLLAPSE_WITH_BOUNDED_DYNAMIC_TRANSFER";
            if (chestCollapsed && childBounded && !pelvisBounded)
                return "F1_REJECTED_DYNAMIC_PELVIS_BURDEN_TRANSFER_REGRESSION";
            if (chestCollapsed && !childBounded)
                return "F1_REJECTED_CHILD_OR_CONSTRAINT_REGRESSION";
            return "F1_NOT_SUPPORTED_NO_MATERIAL_CHEST_LEVER_MOMENT_COLLAPSE";
        }

        internal void Destroy()
        {
            _traceEnabled = false;
            _physicalActive = false;
            _driveEnabled = false;
            _activationStage = ActivationStage.Inactive;
            _passiveStepsRemaining = 0;
            _controllerFixedSteps = 0;
            _controlEverApplied = false;
            _built = false;

            try { SetLaneDynamic(_f0, false); } catch { }
            try { SetLaneDynamic(_f1, false); } catch { }
            try { if (_root != null) Object.Destroy(_root); } catch { }

            _root = null;
            _f0 = null;
            _f1 = null;
        }

        private Lane CreateLane(
            string tag,
            bool chestComAnchor,
            Vector3 pelvisSize,
            Vector3 pelvisCom,
            Vector3 pelvisInertia,
            Vector3 chestSize,
            Vector3 chestCom,
            Vector3 chestInertia)
        {
            Lane lane = new Lane(tag, true, chestComAnchor, tag == "F0_CALIBRATED" ? 0x317F000u : 0x317F100u);

            lane.PelvisObject = new GameObject("ARL_V0317_" + tag + "_Pelvis");
            lane.PelvisObject.hideFlags = HideFlags.DontSave;
            lane.PelvisObject.layer = _root.layer;
            lane.PelvisObject.transform.SetParent(_root.transform, true);
            lane.PelvisObject.transform.position = _sampledPelvisPosition;
            lane.PelvisObject.transform.rotation = _sampledPelvisRotation;
            lane.PelvisBody = CreateBody(
                lane.PelvisObject,
                _profile.PelvisMass,
                pelvisCom,
                pelvisInertia,
                true,
                "V0317_CREATE_" + tag + "_DYNAMIC_PELVIS");

            lane.ChestObject = new GameObject("ARL_V0317_" + tag + "_Chest");
            lane.ChestObject.hideFlags = HideFlags.DontSave;
            lane.ChestObject.layer = _root.layer;
            lane.ChestObject.transform.SetParent(_root.transform, true);
            lane.ChestObject.transform.position = _sampledChestPosition;
            lane.ChestObject.transform.rotation = _sampledChestRotation;
            lane.ChestBody = CreateBody(
                lane.ChestObject,
                _profile.ChestMass,
                chestCom,
                chestInertia,
                false,
                "V0317_CREATE_" + tag + "_DYNAMIC_CHEST");

            Vector3 jointWorld = _audit.Spine != null
                ? _audit.Spine.position
                : Vector3.Lerp(_audit.Pelvis.position, _audit.Chest.position, 0.42f);

            // v0.3.17: both anchor arms are constructed strictly in the Rigidbody pose domain.
            // F0 keeps the calibrated source/spine world point. F1 makes the Chest local anchor
            // exactly equal to the explicit Chest COM, then derives the Pelvis connectedAnchor
            // from that same world point so the native joint starts with zero closure.
            if (chestComAnchor)
            {
                lane.ChestAnchorLocal = lane.ChestBody.centerOfMass;
                Vector3 chestComWorld = BodyTransformPoint(lane.ChestBody, lane.ChestAnchorLocal);
                lane.PelvisAnchorLocal = BodyInverseTransformPoint(lane.PelvisBody, chestComWorld);
            }
            else
            {
                lane.ChestAnchorLocal = BodyInverseTransformPoint(lane.ChestBody, jointWorld);
                lane.PelvisAnchorLocal = BodyInverseTransformPoint(lane.PelvisBody, jointWorld);
            }

            lane.Joint = Il2CppComponentFactory.Add<CharacterJoint>(
                lane.ChestObject,
                "V0317_ADD_" + tag + "_CHARACTER_JOINT");
            ConfigureJoint(lane);

            lane.PelvisSize = pelvisSize;
            lane.ChestSize = chestSize;
            lane.PelvisExpectedCom = pelvisCom;
            lane.ChestExpectedCom = chestCom;
            lane.PelvisExpectedInertia = pelvisInertia;
            lane.ChestExpectedInertia = chestInertia;

            if (!LaneFoundationValidated(lane))
                throw new InvalidOperationException(tag + "_FOUNDATION_READBACK_MISMATCH");

            return lane;
        }

        private Rigidbody CreateBody(
            GameObject gameObject,
            float mass,
            Vector3 centerOfMass,
            Vector3 inertia,
            bool freezePosition,
            string phase)
        {
            Rigidbody body = Il2CppComponentFactory.Add<Rigidbody>(gameObject, phase);
            body.isKinematic = true;
            body.mass = mass;
            body.useGravity = false;
            body.detectCollisions = false;
            body.drag = 0f;
            body.angularDrag = _profile.AngularDrag;
            body.maxAngularVelocity = _profile.MaxAngularVelocity;
            body.interpolation = RigidbodyInterpolation.None;
            body.collisionDetectionMode = CollisionDetectionMode.Discrete;
            body.constraints = freezePosition
                ? RigidbodyConstraints.FreezePosition
                : RigidbodyConstraints.None;
            body.centerOfMass = centerOfMass;
            body.inertiaTensorRotation = Quaternion.identity;
            body.inertiaTensor = inertia;
            body.velocity = Vector3.zero;
            body.angularVelocity = Vector3.zero;
            return body;
        }

        private void ConfigureJoint(Lane lane)
        {
            if (lane == null || lane.Joint == null)
                throw new InvalidOperationException("CHARACTER_JOINT_CREATE_RETURNED_NULL");

            lane.Joint.connectedBody = lane.PelvisBody;
            lane.Joint.autoConfigureConnectedAnchor = false;
            lane.Joint.anchor = lane.ChestAnchorLocal;
            lane.Joint.connectedAnchor = lane.PelvisAnchorLocal;
            lane.Joint.axis = Vector3.up;
            lane.Joint.swingAxis = Vector3.right;
            lane.Joint.enableCollision = false;
            lane.Joint.enablePreprocessing = true;

            float wide = _profile.WideJointLimitDegrees;
            float lowValue = _profile.WideJointLimitIsolation ? -wide : _profile.ChestLowTwistLimitDegrees;
            float highValue = _profile.WideJointLimitIsolation ? wide : _profile.ChestHighTwistLimitDegrees;
            float swing1Value = _profile.WideJointLimitIsolation ? wide : _profile.ChestSwing1LimitDegrees;
            float swing2Value = _profile.WideJointLimitIsolation ? wide : _profile.ChestSwing2LimitDegrees;

            SoftJointLimit low = lane.Joint.lowTwistLimit;
            low.limit = lowValue;
            low.bounciness = 0f;
            lane.Joint.lowTwistLimit = low;

            SoftJointLimit high = lane.Joint.highTwistLimit;
            high.limit = highValue;
            high.bounciness = 0f;
            lane.Joint.highTwistLimit = high;

            SoftJointLimit swing1 = lane.Joint.swing1Limit;
            swing1.limit = swing1Value;
            swing1.bounciness = 0f;
            lane.Joint.swing1Limit = swing1;

            SoftJointLimit swing2 = lane.Joint.swing2Limit;
            swing2.limit = swing2Value;
            swing2.bounciness = 0f;
            lane.Joint.swing2Limit = swing2;
        }

        private void SampleSourcePoseInternal(bool updateVelocity)
        {
            if (_audit.Pelvis == null || _audit.Chest == null)
            {
                _sampleValid = false;
                return;
            }

            Vector3 pelvisPosition = _audit.Pelvis.position;
            Quaternion pelvisRotation = Normalize(_audit.Pelvis.rotation * _pelvisBoneToProxy);
            Vector3 chestPosition = _audit.Chest.position;
            Quaternion chestRotation = Normalize(_audit.Chest.rotation * _chestBoneToProxy);
            Quaternion targetRelative = Normalize(Quaternion.Inverse(pelvisRotation) * chestRotation);

            if (updateVelocity)
            {
                float dt = Time.unscaledDeltaTime;
                if (_hasPreviousSourceSample && Finite(dt) && dt >= 0.001f && dt <= 0.20f)
                {
                    Vector3 pelvisRawW = ComputeAngularVelocity(_previousPelvisRotation, pelvisRotation, dt);
                    Vector3 chestRawW = ComputeAngularVelocity(_previousChestRotation, chestRotation, dt);
                    Vector3 relativeRawWLocal = ComputeAngularVelocity(_previousTargetRelativeRotation, targetRelative, dt);

                    pelvisRawW = ClampMagnitude(pelvisRawW, _profile.MaxAngularVelocity);
                    chestRawW = ClampMagnitude(chestRawW, _profile.MaxAngularVelocity);
                    relativeRawWLocal = ClampMagnitude(relativeRawWLocal, _profile.MaxAngularVelocity);

                    float blend = _profile.TargetVelocityBlend;
                    _sampledPelvisAngularVelocity = Vector3.Lerp(_sampledPelvisAngularVelocity, pelvisRawW, blend);
                    _sampledChestAngularVelocity = Vector3.Lerp(_sampledChestAngularVelocity, chestRawW, blend);
                    _sampledTargetRelativeAngularVelocityLocal = Vector3.Lerp(
                        _sampledTargetRelativeAngularVelocityLocal,
                        relativeRawWLocal,
                        blend);
                }
                else
                {
                    _sampledPelvisAngularVelocity = Vector3.zero;
                    _sampledChestAngularVelocity = Vector3.zero;
                    _sampledTargetRelativeAngularVelocityLocal = Vector3.zero;
                }
            }

            _sampledPelvisPosition = pelvisPosition;
            _sampledPelvisRotation = pelvisRotation;
            _sampledChestPosition = chestPosition;
            _sampledChestRotation = chestRotation;
            _previousPelvisRotation = pelvisRotation;
            _previousChestRotation = chestRotation;
            _previousTargetRelativeRotation = targetRelative;
            _hasPreviousSourceSample = true;

            _sampleValid =
                Finite(_sampledPelvisPosition) && Finite(_sampledPelvisRotation) &&
                Finite(_sampledChestPosition) && Finite(_sampledChestRotation) &&
                Finite(_sampledPelvisAngularVelocity) && Finite(_sampledChestAngularVelocity) &&
                Finite(_sampledTargetRelativeAngularVelocityLocal);
        }

        private void ObserveSettled(TwoBodyShadowProxy production)
        {
            _samples++;

            TwoBodyProxyReport p = production.Report;
            bool source = p != null && p.SourceTurnEventActive;
            bool recovery = !source && p != null && p.FreezeRecoveryActive;
            bool idle = !source && !recovery && p != null &&
                        string.Equals(p.MotionPhase, "IDLE", StringComparison.OrdinalIgnoreCase);
            bool normal = !source && !recovery && !idle;
            bool transition = normal && p != null && p.MotionTransition;

            if (source) _sourceSamples++;
            else if (recovery) _recoverySamples++;
            else if (idle) _idleSamples++;
            else
            {
                _normalSamples++;
                if (transition) _normalTransitionSamples++;
                else _normalSteadySamples++;
            }

            if (!normal)
                return;

            bool f0Valid = TryObserveLane(_f0, production);
            bool f1Valid = TryObserveLane(_f1, production);
            if (f0Valid && f1Valid) _validNormalSamples++;
            else _invalidNormalSamples++;
        }

        private bool TryObserveLane(Lane lane, TwoBodyShadowProxy production)
        {
            if (lane == null || !lane.Ready || production == null || production.Report == null)
                return false;

            Quaternion targetPelvisRotation = production.CurrentPelvisCommandRotation;
            Quaternion targetRelativeRotation = Normalize(
                Quaternion.Inverse(_sampledPelvisRotation) * _sampledChestRotation);
            Quaternion currentRelativeRotation = Normalize(
                Quaternion.Inverse(lane.PelvisBody.rotation) * lane.ChestBody.rotation);

            Vector3 chestAnchorWorld = BodyTransformPoint(lane.ChestBody, lane.ChestAnchorLocal);
            Vector3 pelvisAnchorWorld = BodyTransformPoint(lane.PelvisBody, lane.PelvisAnchorLocal);
            Vector3 chestComWorld = BodyTransformPoint(lane.ChestBody, lane.ChestBody.centerOfMass);
            Vector3 pelvisComWorld = BodyTransformPoint(lane.PelvisBody, lane.PelvisBody.centerOfMass);
            Vector3 forceOnChest = lane.Joint.currentForce;
            Vector3 torqueOnChest = lane.Joint.currentTorque;
            Vector3 chestLever = chestAnchorWorld - chestComWorld;
            Vector3 pelvisLever = pelvisAnchorWorld - pelvisComWorld;
            Vector3 chestMoment = Vector3.Cross(chestLever, forceOnChest);
            Vector3 pelvisMoment = Vector3.Cross(pelvisLever, -forceOnChest);
            Vector3 targetChestCom = _sampledChestPosition + _sampledChestRotation * lane.ChestBody.centerOfMass;

            float pelvisRotError = RotationErrorDegrees(targetPelvisRotation, lane.PelvisBody.rotation);
            float chestRelativeRotError = RotationErrorDegrees(targetRelativeRotation, currentRelativeRotation);
            float chestComPositionError = Vector3.Distance(targetChestCom, chestComWorld);
            float anchorClosure = Vector3.Distance(chestAnchorWorld, pelvisAnchorWorld);

            if (!Finite(pelvisRotError) || !Finite(chestRelativeRotError) ||
                !Finite(chestComPositionError) || !Finite(anchorClosure) ||
                !Finite(forceOnChest) || !Finite(torqueOnChest) ||
                !Finite(chestLever) || !Finite(pelvisLever) ||
                !Finite(chestMoment) || !Finite(pelvisMoment) ||
                !Finite(lane.LastPelvisAuthorityTorque))
                return false;

            lane.ReactionValidSamples++;
            lane.PelvisRotationError.Observe(pelvisRotError);
            lane.ChestRelativeRotationError.Observe(chestRelativeRotError);
            lane.ChestComPositionError.Observe(chestComPositionError);
            lane.AnchorClosure.Observe(anchorClosure);
            lane.JointForce.Observe(forceOnChest.magnitude);
            lane.JointTorque.Observe(torqueOnChest.magnitude);
            lane.ChestLever.Observe(chestLever.magnitude);
            lane.PelvisLever.Observe(pelvisLever.magnitude);
            lane.ChestForceMoment.Observe(chestMoment.magnitude);
            lane.PelvisForceMoment.Observe(pelvisMoment.magnitude);
            lane.PelvisAuthorityTorque.Observe(lane.LastPelvisAuthorityTorque.magnitude);
            lane.PelvisAngularSpeed.Observe(lane.PelvisBody.angularVelocity.magnitude);
            lane.ChestAngularSpeed.Observe(lane.ChestBody.angularVelocity.magnitude);
            return true;
        }

        private void ApplyLaneControl(
            Lane lane,
            Quaternion targetPelvisRotation,
            Vector3 targetPelvisW,
            Quaternion targetRelativeRotation,
            Vector3 targetRelativeWLocal)
        {
            Vector3 pelvisError = RotationErrorVector(targetPelvisRotation, lane.PelvisBody.rotation);
            Vector3 pelvisRawA =
                pelvisError * _profile.AngularSpring +
                (targetPelvisW - lane.PelvisBody.angularVelocity) * _profile.AngularDamper;
            Vector3 pelvisDesiredA = ClampMagnitude(pelvisRawA, _profile.MaxAngularAcceleration);
            Vector3 pelvisTorque = ComposePhysicalTorque(lane.PelvisBody, pelvisDesiredA);

            Quaternion currentRelative = Normalize(
                Quaternion.Inverse(lane.PelvisBody.rotation) * lane.ChestBody.rotation);
            Vector3 chestRelativeErrorLocal = RotationErrorVector(targetRelativeRotation, currentRelative);
            Vector3 chestRelativeErrorWorld = lane.PelvisBody.rotation * chestRelativeErrorLocal;
            Vector3 targetRelativeWWorld = targetPelvisRotation * targetRelativeWLocal;
            Vector3 actualRelativeWWorld = lane.ChestBody.angularVelocity - lane.PelvisBody.angularVelocity;
            Vector3 chestRawA =
                chestRelativeErrorWorld * _profile.AngularSpring +
                (targetRelativeWWorld - actualRelativeWWorld) * _profile.AngularDamper;
            Vector3 chestDesiredA = ClampMagnitude(chestRawA, _profile.MaxAngularAcceleration);

            if (!Finite(pelvisRawA) || !Finite(pelvisDesiredA) || !Finite(pelvisTorque) ||
                !Finite(chestRawA) || !Finite(chestDesiredA))
                throw new InvalidOperationException(lane.Tag + "_NON_FINITE_CONTROL_COMMAND");

            if (pelvisRawA.magnitude > _profile.MaxAngularAcceleration + 0.0001f)
                lane.PelvisAuthorityClampSamples++;
            if (chestRawA.magnitude > _profile.MaxAngularAcceleration + 0.0001f)
                lane.ChestAuthorityClampSamples++;

            lane.LastPelvisAuthorityTorque = pelvisTorque;
            lane.LastPelvisDesiredA = pelvisDesiredA;
            lane.LastChestDesiredA = chestDesiredA;

            lane.PelvisBody.AddTorque(pelvisTorque, ForceMode.Force);
            lane.ChestBody.AddTorque(chestDesiredA, ForceMode.Acceleration);

            lane.PelvisDynamicObserved |= IsDynamic(lane.PelvisBody);
            lane.ChestDynamicObserved |= IsDynamic(lane.ChestBody);
        }

        private bool RebindRunStartNativeAnchors()
        {
            if (_f0 == null || _f1 == null || !_sampleValid)
                return false;

            RebindLaneNativeAnchors(_f0);
            RebindLaneNativeAnchors(_f1);
            return LaneFoundationValidated(_f0) && LaneFoundationValidated(_f1);
        }

        private void RebindLaneNativeAnchors(Lane lane)
        {
            if (lane == null || !lane.Ready)
                throw new InvalidOperationException("RUN_START_REBIND_LANE_NOT_READY");

            Vector3 sourceJointWorld = _audit.Spine != null
                ? _audit.Spine.position
                : Vector3.Lerp(_sampledPelvisPosition, _sampledChestPosition, 0.42f);
            if (!Finite(sourceJointWorld))
                throw new InvalidOperationException(lane.Tag + "_RUN_START_SOURCE_JOINT_NON_FINITE");

            if (lane.ChestComAnchor)
            {
                lane.ChestAnchorLocal = lane.ChestBody.centerOfMass;
                Vector3 chestComWorld = BodyTransformPoint(lane.ChestBody, lane.ChestAnchorLocal);
                lane.PelvisAnchorLocal = BodyInverseTransformPoint(lane.PelvisBody, chestComWorld);
            }
            else
            {
                lane.ChestAnchorLocal = BodyInverseTransformPoint(lane.ChestBody, sourceJointWorld);
                Vector3 chestAnchorWorld = BodyTransformPoint(lane.ChestBody, lane.ChestAnchorLocal);
                lane.PelvisAnchorLocal = BodyInverseTransformPoint(lane.PelvisBody, chestAnchorWorld);
            }
            lane.Joint.anchor = lane.ChestAnchorLocal;
            lane.Joint.connectedAnchor = lane.PelvisAnchorLocal;

            if (!Near(lane.Joint.anchor, lane.ChestAnchorLocal, 0.00001f) ||
                !Near(lane.Joint.connectedAnchor, lane.PelvisAnchorLocal, 0.00001f))
                throw new InvalidOperationException(lane.Tag + "_RUN_START_NATIVE_ANCHOR_READBACK_MISMATCH");
            if (!lane.Joint.enablePreprocessing || !lane.ExpectedPreprocessing)
                throw new InvalidOperationException(lane.Tag + "_RUN_START_PREPROCESSING_READBACK_MISMATCH");
        }

        private bool ValidateRunStartStateDomainSync()
        {
            if (_f0 == null || !_f0.Ready || _f1 == null || !_f1.Ready)
                return false;

            _runStartF0PelvisRbTfPositionDelta = Vector3.Distance(_f0.PelvisBody.position, _f0.PelvisObject.transform.position);
            _runStartF0ChestRbTfPositionDelta = Vector3.Distance(_f0.ChestBody.position, _f0.ChestObject.transform.position);
            _runStartF1PelvisRbTfPositionDelta = Vector3.Distance(_f1.PelvisBody.position, _f1.PelvisObject.transform.position);
            _runStartF1ChestRbTfPositionDelta = Vector3.Distance(_f1.ChestBody.position, _f1.ChestObject.transform.position);

            _runStartF0PelvisRbTfRotationDelta = Quaternion.Angle(_f0.PelvisBody.rotation, _f0.PelvisObject.transform.rotation);
            _runStartF0ChestRbTfRotationDelta = Quaternion.Angle(_f0.ChestBody.rotation, _f0.ChestObject.transform.rotation);
            _runStartF1PelvisRbTfRotationDelta = Quaternion.Angle(_f1.PelvisBody.rotation, _f1.PelvisObject.transform.rotation);
            _runStartF1ChestRbTfRotationDelta = Quaternion.Angle(_f1.ChestBody.rotation, _f1.ChestObject.transform.rotation);

            return
                Finite(_runStartF0PelvisRbTfPositionDelta) && _runStartF0PelvisRbTfPositionDelta <= RunStartStateDomainPositionTolerance &&
                Finite(_runStartF0ChestRbTfPositionDelta) && _runStartF0ChestRbTfPositionDelta <= RunStartStateDomainPositionTolerance &&
                Finite(_runStartF1PelvisRbTfPositionDelta) && _runStartF1PelvisRbTfPositionDelta <= RunStartStateDomainPositionTolerance &&
                Finite(_runStartF1ChestRbTfPositionDelta) && _runStartF1ChestRbTfPositionDelta <= RunStartStateDomainPositionTolerance &&
                Finite(_runStartF0PelvisRbTfRotationDelta) && _runStartF0PelvisRbTfRotationDelta <= RunStartStateDomainRotationToleranceDegrees &&
                Finite(_runStartF0ChestRbTfRotationDelta) && _runStartF0ChestRbTfRotationDelta <= RunStartStateDomainRotationToleranceDegrees &&
                Finite(_runStartF1PelvisRbTfRotationDelta) && _runStartF1PelvisRbTfRotationDelta <= RunStartStateDomainRotationToleranceDegrees &&
                Finite(_runStartF1ChestRbTfRotationDelta) && _runStartF1ChestRbTfRotationDelta <= RunStartStateDomainRotationToleranceDegrees;
        }

        private string BuildRunStartStateDomainContext()
        {
            return
                "rbTfPosMm(F0P/F0C/F1P/F1C)=" +
                F(1000f * _runStartF0PelvisRbTfPositionDelta) + "/" + F(1000f * _runStartF0ChestRbTfPositionDelta) + "/" +
                F(1000f * _runStartF1PelvisRbTfPositionDelta) + "/" + F(1000f * _runStartF1ChestRbTfPositionDelta) +
                ";rbTfRotDeg(F0P/F0C/F1P/F1C)=" +
                F(_runStartF0PelvisRbTfRotationDelta) + "/" + F(_runStartF0ChestRbTfRotationDelta) + "/" +
                F(_runStartF1PelvisRbTfRotationDelta) + "/" + F(_runStartF1ChestRbTfRotationDelta) +
                ";positionToleranceMm=" + F(1000f * RunStartStateDomainPositionTolerance) +
                ";rotationToleranceDeg=" + F(RunStartStateDomainRotationToleranceDegrees);
        }

        private bool ValidateRunStartAnchorSemantics(
            out float f0SourceAnchorError,
            out float f1ChestComLocalError)
        {
            f0SourceAnchorError = float.NaN;
            f1ChestComLocalError = float.NaN;

            if (_f0 == null || !_f0.Ready || _f1 == null || !_f1.Ready || !_sampleValid)
                return false;

            Vector3 expectedWorld = _audit.Spine != null
                ? _audit.Spine.position
                : Vector3.Lerp(_sampledPelvisPosition, _sampledChestPosition, 0.42f);
            Vector3 actualF0World = BodyTransformPoint(_f0.ChestBody, _f0.ChestAnchorLocal);
            f0SourceAnchorError = Vector3.Distance(actualF0World, expectedWorld);
            f1ChestComLocalError = Vector3.Distance(_f1.ChestAnchorLocal, _f1.ChestBody.centerOfMass);

            return
                Finite(f0SourceAnchorError) && f0SourceAnchorError <= RunStartAnchorClosureTolerance &&
                Finite(f1ChestComLocalError) && f1ChestComLocalError <= RunStartAnchorClosureTolerance &&
                !_f0.ChestComAnchor && _f1.ChestComAnchor &&
                _f0.Joint.enablePreprocessing && _f1.Joint.enablePreprocessing;
        }

        private string BuildRunStartSemanticContext()
        {
            return
                "F0SourceAnchorErrMm=" + F(1000f * _runStartF0SourceAnchorError) +
                ";F1ChestComLocalErrMm=" + F(1000f * _runStartF1ChestComLocalError) +
                ";" + BuildRunStartStateDomainContext() +
                ";preprocessing(F0/F1)=" + _f0.Joint.enablePreprocessing + "/" + _f1.Joint.enablePreprocessing +
                ";runStartToleranceMm=" + F(1000f * RunStartAnchorClosureTolerance);
        }

        private bool TryGetGeometry(
            Lane lane,
            out float closure,
            out float bodySeparation,
            out float separationLimit)
        {
            closure = float.NaN;
            bodySeparation = float.NaN;
            separationLimit = float.NaN;
            if (lane == null || !lane.Ready)
                return false;

            Vector3 chestAnchorWorld = BodyTransformPoint(lane.ChestBody, lane.ChestAnchorLocal);
            Vector3 pelvisAnchorWorld = BodyTransformPoint(lane.PelvisBody, lane.PelvisAnchorLocal);
            closure = Vector3.Distance(chestAnchorWorld, pelvisAnchorWorld);
            bodySeparation = Vector3.Distance(lane.PelvisBody.position, lane.ChestBody.position);
            separationLimit = Mathf.Max(_profile.DriveDisableDistance, _audit.PelvisToChestDistance * 3f);

            return
                Finite(closure) && closure <= _profile.JointAnchorSafetyDistance &&
                Finite(bodySeparation) && Finite(separationLimit) && bodySeparation <= separationLimit;
        }

        private float ComputeAnchorVelocityMismatch(Lane lane)
        {
            if (lane == null || !lane.Ready)
                return float.NaN;

            Vector3 chestAnchorWorld = BodyTransformPoint(lane.ChestBody, lane.ChestAnchorLocal);
            Vector3 pelvisAnchorWorld = BodyTransformPoint(lane.PelvisBody, lane.PelvisAnchorLocal);
            Vector3 chestComWorld = BodyTransformPoint(lane.ChestBody, lane.ChestBody.centerOfMass);
            Vector3 pelvisComWorld = BodyTransformPoint(lane.PelvisBody, lane.PelvisBody.centerOfMass);

            Vector3 chestAnchorVelocity =
                lane.ChestBody.velocity + Vector3.Cross(lane.ChestBody.angularVelocity, chestAnchorWorld - chestComWorld);
            Vector3 pelvisAnchorVelocity =
                lane.PelvisBody.velocity + Vector3.Cross(lane.PelvisBody.angularVelocity, pelvisAnchorWorld - pelvisComWorld);
            Vector3 mismatch = chestAnchorVelocity - pelvisAnchorVelocity;

            return Finite(chestAnchorVelocity) && Finite(pelvisAnchorVelocity) && Finite(mismatch)
                ? mismatch.magnitude
                : float.NaN;
        }

        private void EmitActivationStepTelemetry(
            bool controllerAppliedThisFixed,
            float f0Closure,
            float f0Separation,
            float f0SeparationLimit,
            float f1Closure,
            float f1Separation,
            float f1SeparationLimit)
        {
            if (_fixedStepsSinceActivation <= 0 || _fixedStepsSinceActivation > ActivationTelemetryFixedSteps)
                return;

            try
            {
                Plugin.Logger?.LogWarning(
                    "[ARL][V0317_ACTIVATION_STEP]" +
                    " activation=" + _activationCount +
                    " | fixed=" + _fixedStepsSinceActivation +
                    " | stage=" + ActivationStageName(_activationStage) +
                    " | passiveRemaining=" + _passiveStepsRemaining +
                    " | warmupRemaining=" + _warmupStepsRemaining +
                    " | controllerAppliedThisFixed=" + controllerAppliedThisFixed +
                    " | controllerEverApplied=" + _controlEverApplied +
                    " | controllerFixedSteps=" + _controllerFixedSteps +
                    " | F0 " + BuildLaneActivationTelemetry(_f0, f0Closure, f0Separation, f0SeparationLimit) +
                    " | F1 " + BuildLaneActivationTelemetry(_f1, f1Closure, f1Separation, f1SeparationLimit));
            }
            catch
            {
                // Activation telemetry is evidence only and must never become a new sandbox failure owner.
            }
        }

        private string BuildLaneActivationTelemetry(
            Lane lane,
            float closure,
            float separation,
            float separationLimit)
        {
            if (lane == null || !lane.Ready)
                return "laneNotReady=True";

            Vector3 pelvisComWorld = BodyTransformPoint(lane.PelvisBody, lane.PelvisBody.centerOfMass);
            Vector3 chestComWorld = BodyTransformPoint(lane.ChestBody, lane.ChestBody.centerOfMass);
            Vector3 pelvisRbPosition = lane.PelvisBody.position;
            Vector3 chestRbPosition = lane.ChestBody.position;
            Vector3 pelvisTransformPosition = lane.PelvisObject.transform.position;
            Vector3 chestTransformPosition = lane.ChestObject.transform.position;
            Vector3 chestAnchorWorld = BodyTransformPoint(lane.ChestBody, lane.ChestAnchorLocal);
            Vector3 pelvisAnchorWorld = BodyTransformPoint(lane.PelvisBody, lane.PelvisAnchorLocal);
            float anchorVelocityMismatch = ComputeAnchorVelocityMismatch(lane);
            float pelvisPositionDelta = Vector3.Distance(pelvisRbPosition, _sampledPelvisPosition);
            float chestPositionDelta = Vector3.Distance(chestRbPosition, _sampledChestPosition);
            float pelvisRbTransformDelta = Vector3.Distance(pelvisRbPosition, pelvisTransformPosition);
            float chestRbTransformDelta = Vector3.Distance(chestRbPosition, chestTransformPosition);
            float pelvisRbTransformRotationDelta = Quaternion.Angle(lane.PelvisBody.rotation, lane.PelvisObject.transform.rotation);
            float chestRbTransformRotationDelta = Quaternion.Angle(lane.ChestBody.rotation, lane.ChestObject.transform.rotation);

            return
                "preprocess=" + lane.Joint.enablePreprocessing +
                ";anchor/body/limitMm=" + F(1000f * closure) + "/" + F(1000f * separation) + "/" + F(1000f * separationLimit) +
                ";posDeltaMm(P/C)=" + F(1000f * pelvisPositionDelta) + "/" + F(1000f * chestPositionDelta) +
                ";rbTfDeltaMm(P/C)=" + F(1000f * pelvisRbTransformDelta) + "/" + F(1000f * chestRbTransformDelta) +
                ";rbTfRotDeltaDeg(P/C)=" + F(pelvisRbTransformRotationDelta) + "/" + F(chestRbTransformRotationDelta) +
                ";kinematic(P/C)=" + lane.PelvisBody.isKinematic + "/" + lane.ChestBody.isKinematic +
                ";constraints(P/C)=" + lane.PelvisBody.constraints + "/" + lane.ChestBody.constraints +
                ";rbPosP=" + V(pelvisRbPosition) + ";tfPosP=" + V(pelvisTransformPosition) +
                ";rbPosC=" + V(chestRbPosition) + ";tfPosC=" + V(chestTransformPosition) +
                ";rbAnchorWorld(C/P)=" + V(chestAnchorWorld) + "/" + V(pelvisAnchorWorld) +
                ";vP=" + V(lane.PelvisBody.velocity) + "/" + F(lane.PelvisBody.velocity.magnitude) +
                ";vC=" + V(lane.ChestBody.velocity) + "/" + F(lane.ChestBody.velocity.magnitude) +
                ";wP=" + V(lane.PelvisBody.angularVelocity) + "/" + F(lane.PelvisBody.angularVelocity.magnitude) +
                ";wC=" + V(lane.ChestBody.angularVelocity) + "/" + F(lane.ChestBody.angularVelocity.magnitude) +
                ";anchorVelMismatch=" + F(anchorVelocityMismatch) +
                ";jointF/T=" + F(lane.Joint.currentForce.magnitude) + "/" + F(lane.Joint.currentTorque.magnitude) +
                ";comP=" + V(pelvisComWorld) +
                ";comC=" + V(chestComWorld) +
                ";cmdPelvisTorque=" + F(lane.LastPelvisAuthorityTorque.magnitude) +
                ";cmdPelvisA=" + F(lane.LastPelvisDesiredA.magnitude) +
                ";cmdChestA=" + F(lane.LastChestDesiredA.magnitude);
        }

        private static Vector3 BodyTransformPoint(Rigidbody body, Vector3 localPoint)
        {
            return body.position + body.rotation * localPoint;
        }

        private static Vector3 BodyInverseTransformPoint(Rigidbody body, Vector3 worldPoint)
        {
            return Quaternion.Inverse(body.rotation) * (worldPoint - body.position);
        }

        private static string ActivationStageName(ActivationStage stage)
        {
            switch (stage)
            {
                case ActivationStage.DynamicPassive: return "DYNAMIC_PASSIVE";
                case ActivationStage.ControlActive: return "CONTROL_ACTIVE";
                default: return "INACTIVE";
            }
        }

        private string BuildGeometryContext(
            string lane,
            float f0Closure,
            float f0Separation,
            float f0SeparationLimit,
            float f1Closure,
            float f1Separation,
            float f1SeparationLimit)
        {
            return
                "lane=" + (lane ?? "UNKNOWN") +
                ";fixedSinceActivation=" + _fixedStepsSinceActivation +
                ";stage=" + ActivationStageName(_activationStage) +
                ";passiveRemaining=" + _passiveStepsRemaining +
                ";warmupRemaining=" + _warmupStepsRemaining +
                ";controllerEverApplied=" + _controlEverApplied +
                ";controllerFixedSteps=" + _controllerFixedSteps +
                ";preprocessing(F0/F1)=" + _f0.Joint.enablePreprocessing + "/" + _f1.Joint.enablePreprocessing +
                ";F0(anchorMm/bodyMm/bodyLimitMm)=" + F(1000f * f0Closure) + "/" + F(1000f * f0Separation) + "/" + F(1000f * f0SeparationLimit) +
                ";F1(anchorMm/bodyMm/bodyLimitMm)=" + F(1000f * f1Closure) + "/" + F(1000f * f1Separation) + "/" + F(1000f * f1SeparationLimit) +
                ";anchorSafetyMm=" + F(1000f * _profile.JointAnchorSafetyDistance) +
                ";runStartToleranceMm=" + F(1000f * RunStartAnchorClosureTolerance);
        }

        private void SafeResetBodies()
        {
            if (_f0 == null || _f1 == null || !_sampleValid)
                return;

            ResetLane(_f0);
            ResetLane(_f1);
        }

        private void ResetLane(Lane lane)
        {
            if (lane == null || !lane.Ready)
                return;

            lane.PelvisBody.isKinematic = true;
            lane.ChestBody.isKinematic = true;

            // v0.3.17 retained common-foundation fix: while kinematic, write BOTH state domains to the
            // exact same source pose before any anchor construction or geometry preflight.
            // Rigidbody is written after Transform so its physics pose is the final authority.
            lane.PelvisObject.transform.position = _sampledPelvisPosition;
            lane.PelvisObject.transform.rotation = _sampledPelvisRotation;
            lane.PelvisBody.position = _sampledPelvisPosition;
            lane.PelvisBody.rotation = _sampledPelvisRotation;
            lane.PelvisBody.velocity = Vector3.zero;
            lane.PelvisBody.angularVelocity = _sampledPelvisAngularVelocity;

            lane.ChestObject.transform.position = _sampledChestPosition;
            lane.ChestObject.transform.rotation = _sampledChestRotation;
            lane.ChestBody.position = _sampledChestPosition;
            lane.ChestBody.rotation = _sampledChestRotation;
            lane.ChestBody.velocity = Vector3.zero;
            lane.ChestBody.angularVelocity = _sampledChestAngularVelocity;

            lane.LastPelvisAuthorityTorque = Vector3.zero;
            lane.LastPelvisDesiredA = Vector3.zero;
            lane.LastChestDesiredA = Vector3.zero;
        }

        private static void SetLaneDynamic(Lane lane, bool dynamic)
        {
            if (lane == null || !lane.Ready)
                return;

            lane.PelvisBody.isKinematic = !dynamic;
            lane.ChestBody.isKinematic = !dynamic;
            if (dynamic)
            {
                lane.PelvisBody.WakeUp();
                lane.ChestBody.WakeUp();
                lane.PelvisDynamicObserved = !lane.PelvisBody.isKinematic;
                lane.ChestDynamicObserved = !lane.ChestBody.isKinematic;
            }
        }

        private void FailClose(string reason)
        {
            FailClose(reason, null);
        }

        private void FailClose(string reason, string context)
        {
            _faulted = true;
            _faultCount++;
            if (string.Equals(_faultReason, "NONE", StringComparison.Ordinal))
                _faultReason = string.IsNullOrWhiteSpace(reason) ? "UNKNOWN" : reason;
            if (string.Equals(_faultContext, "NONE", StringComparison.Ordinal) && !string.IsNullOrWhiteSpace(context))
                _faultContext = context;
            _traceEnabled = false;
            _physicalActive = false;
            _driveEnabled = false;

            try { SetLaneDynamic(_f0, false); } catch { }
            try { SetLaneDynamic(_f1, false); } catch { }
            try { SafeResetBodies(); } catch { }
            Plugin.Logger?.LogWarning(
                "[ARL][V0317_FULLY_DYNAMIC_SANDBOX_FAIL_CLOSED] productionContinues=True" +
                " | reason=" + (_faultReason ?? "UNKNOWN") +
                " | context=" + (_faultContext ?? "NONE"));
        }

        private void ResetStatistics()
        {
            _samples = 0;
            _normalSamples = 0;
            _normalSteadySamples = 0;
            _normalTransitionSamples = 0;
            _sourceSamples = 0;
            _recoverySamples = 0;
            _idleSamples = 0;
            _validNormalSamples = 0;
            _invalidNormalSamples = 0;
            _runStartF0AnchorClosure = 0f;
            _runStartF1AnchorClosure = 0f;
            _runStartF0BodySeparation = 0f;
            _runStartF1BodySeparation = 0f;
            _runStartF0SourceAnchorError = 0f;
            _runStartF1ChestComLocalError = 0f;
            _runStartF0PelvisRbTfPositionDelta = 0f;
            _runStartF0ChestRbTfPositionDelta = 0f;
            _runStartF1PelvisRbTfPositionDelta = 0f;
            _runStartF1ChestRbTfPositionDelta = 0f;
            _runStartF0PelvisRbTfRotationDelta = 0f;
            _runStartF0ChestRbTfRotationDelta = 0f;
            _runStartF1PelvisRbTfRotationDelta = 0f;
            _runStartF1ChestRbTfRotationDelta = 0f;
            _runStartF0AnchorVelocityMismatch = 0f;
            _runStartF1AnchorVelocityMismatch = 0f;
            _activationStage = ActivationStage.Inactive;
            _passiveStepsRemaining = 0;
            _fixedStepsSinceActivation = 0;
            _controllerFixedSteps = 0;
            _controlEverApplied = false;
            _f0?.ResetStatistics();
            _f1?.ResetStatistics();
        }

        private bool FoundationParityValidated()
        {
            if (!LaneFoundationValidated(_f0) || !LaneFoundationValidated(_f1))
                return false;

            bool bodyParity =
                SameBodyFoundation(_f0.PelvisBody, _f1.PelvisBody) &&
                SameBodyFoundation(_f0.ChestBody, _f1.ChestBody) &&
                Near(_f0.PelvisSize, _f1.PelvisSize, 0.00001f) &&
                Near(_f0.ChestSize, _f1.ChestSize, 0.00001f) &&
                SameJointFoundationExceptAnchors(_f0.Joint, _f1.Joint);

            bool intendedAnchorAB =
                !_f0.ChestComAnchor && _f1.ChestComAnchor &&
                !Near(_f0.ChestAnchorLocal, _f0.ChestBody.centerOfMass, 0.00005f) &&
                Near(_f1.ChestAnchorLocal, _f1.ChestBody.centerOfMass, 0.00005f);

            bool preprocessingParity =
                _f0.ExpectedPreprocessing && _f1.ExpectedPreprocessing &&
                _f0.Joint.enablePreprocessing && _f1.Joint.enablePreprocessing;

            return bodyParity && intendedAnchorAB && preprocessingParity;
        }

        private static bool LaneFoundationValidated(Lane lane)
        {
            if (lane == null || !lane.Ready)
                return false;

            bool pelvis =
                Near(lane.PelvisBody.centerOfMass, lane.PelvisExpectedCom, 0.00001f) &&
                Near(lane.PelvisBody.inertiaTensor, lane.PelvisExpectedInertia, 0.00001f) &&
                Quaternion.Angle(lane.PelvisBody.inertiaTensorRotation, Quaternion.identity) <= 0.001f &&
                lane.PelvisBody.constraints == RigidbodyConstraints.FreezePosition &&
                !lane.PelvisBody.useGravity && !lane.PelvisBody.detectCollisions;

            bool chest =
                Near(lane.ChestBody.centerOfMass, lane.ChestExpectedCom, 0.00001f) &&
                Near(lane.ChestBody.inertiaTensor, lane.ChestExpectedInertia, 0.00001f) &&
                Quaternion.Angle(lane.ChestBody.inertiaTensorRotation, Quaternion.identity) <= 0.001f &&
                lane.ChestBody.constraints == RigidbodyConstraints.None &&
                !lane.ChestBody.useGravity && !lane.ChestBody.detectCollisions;

            bool joint =
                lane.Joint.connectedBody == lane.PelvisBody &&
                !lane.Joint.autoConfigureConnectedAnchor &&
                Near(lane.Joint.anchor, lane.ChestAnchorLocal, 0.00001f) &&
                Near(lane.Joint.connectedAnchor, lane.PelvisAnchorLocal, 0.00001f) &&
                lane.Joint.enablePreprocessing == lane.ExpectedPreprocessing;

            return pelvis && chest && joint;
        }

        private static bool SameBodyFoundation(Rigidbody a, Rigidbody b)
        {
            return
                a != null && b != null &&
                Mathf.Abs(a.mass - b.mass) <= 0.00001f &&
                Near(a.centerOfMass, b.centerOfMass, 0.00001f) &&
                Near(a.inertiaTensor, b.inertiaTensor, 0.00001f) &&
                Quaternion.Angle(a.inertiaTensorRotation, b.inertiaTensorRotation) <= 0.001f &&
                Mathf.Abs(a.drag - b.drag) <= 0.00001f &&
                Mathf.Abs(a.angularDrag - b.angularDrag) <= 0.00001f &&
                Mathf.Abs(a.maxAngularVelocity - b.maxAngularVelocity) <= 0.00001f &&
                a.constraints == b.constraints &&
                a.useGravity == b.useGravity &&
                a.detectCollisions == b.detectCollisions &&
                a.interpolation == b.interpolation &&
                a.collisionDetectionMode == b.collisionDetectionMode &&
                a.isKinematic == b.isKinematic;
        }

        private static bool SameJointFoundationExceptAnchors(CharacterJoint a, CharacterJoint b)
        {
            return
                a != null && b != null &&
                Near(a.axis, b.axis, 0.00001f) &&
                Near(a.swingAxis, b.swingAxis, 0.00001f) &&
                a.enableCollision == b.enableCollision &&
                Mathf.Abs(a.lowTwistLimit.limit - b.lowTwistLimit.limit) <= 0.00001f &&
                Mathf.Abs(a.highTwistLimit.limit - b.highTwistLimit.limit) <= 0.00001f &&
                Mathf.Abs(a.swing1Limit.limit - b.swing1Limit.limit) <= 0.00001f &&
                Mathf.Abs(a.swing2Limit.limit - b.swing2Limit.limit) <= 0.00001f;
        }

        private Quaternion BuildCharacterFrameRotation()
        {
            Vector3 up = SafeNormalize(_audit.CharacterUp, Vector3.up);
            Vector3 forward = SafeNormalize(_audit.CharacterForward, Vector3.forward);
            Vector3 right = Vector3.Cross(up, forward).normalized;
            if (right.sqrMagnitude < 0.0001f)
                right = Vector3.right;
            forward = SafeNormalize(Vector3.Cross(right, up), Vector3.forward);
            return Normalize(Quaternion.LookRotation(forward, up));
        }

        private string BuildKey(TwoBodyShadowProxy production)
        {
            return
                "VALID=" + _validNormalSamples +
                "|INVALID=" + _invalidNormalSamples +
                "|DYNAMIC=" +
                _f0.PelvisDynamicObserved + "/" + _f0.ChestDynamicObserved + "/" +
                _f1.PelvisDynamicObserved + "/" + _f1.ChestDynamicObserved +
                "|FOUNDATION=" + FoundationParityValidated() +
                "|PRODUCTION_PELVIS_KINEMATIC=" +
                (production != null && production.PelvisBody != null && production.PelvisBody.isKinematic) +
                "|P_ROT_P99_F0_F1=" + F(_f0.PelvisRotationError.P99) + "/" + F(_f1.PelvisRotationError.P99) +
                "|C_REL_P99_F0_F1=" + F(_f0.ChestRelativeRotationError.P99) + "/" + F(_f1.ChestRelativeRotationError.P99) +
                "|P_MOMENT_P99_F0_F1=" + F(_f0.PelvisForceMoment.P99) + "/" + F(_f1.PelvisForceMoment.P99) +
                "|ANCHOR_MM_P99_F0_F1=" + F(1000f * _f0.AnchorClosure.P99) + "/" + F(1000f * _f1.AnchorClosure.P99) +
                "|RUNSTART_ANCHOR_MM_F0_F1=" + F(1000f * _runStartF0AnchorClosure) + "/" + F(1000f * _runStartF1AnchorClosure) +
                "|RUNSTART_ANCHOR_SEMANTIC_ERR_MM_F0SOURCE_F1COMLOCAL=" +
                F(1000f * _runStartF0SourceAnchorError) + "/" + F(1000f * _runStartF1ChestComLocalError) +
                "|PREPROCESSING_F0_F1=" + _f0.Joint.enablePreprocessing + "/" + _f1.Joint.enablePreprocessing +
                "|RUNSTART_RB_TF_POS_MM_F0P_F0C_F1P_F1C=" +
                F(1000f * _runStartF0PelvisRbTfPositionDelta) + "/" + F(1000f * _runStartF0ChestRbTfPositionDelta) + "/" +
                F(1000f * _runStartF1PelvisRbTfPositionDelta) + "/" + F(1000f * _runStartF1ChestRbTfPositionDelta) +
                "|RUNSTART_RB_TF_ROT_DEG_F0P_F0C_F1P_F1C=" +
                F(_runStartF0PelvisRbTfRotationDelta) + "/" + F(_runStartF0ChestRbTfRotationDelta) + "/" +
                F(_runStartF1PelvisRbTfRotationDelta) + "/" + F(_runStartF1ChestRbTfRotationDelta) +
                "|RUNSTART_ANCHOR_VEL_MISMATCH_F0_F1=" + F(_runStartF0AnchorVelocityMismatch) + "/" + F(_runStartF1AnchorVelocityMismatch) +
                "|ACTIVATION_STAGE=" + ActivationStageName(_activationStage) +
                "|PASSIVE_REMAINING=" + _passiveStepsRemaining +
                "|CONTROLLER_FIXED=" + _controllerFixedSteps +
                "|CONTROL_EVER=" + _controlEverApplied +
                "|PHYSICAL_ACTIVE=" + _physicalActive +
                "|FAULT=" + _faulted +
                "|FAULT_CONTEXT=" + (_faultContext ?? "NONE");
        }

        private static Vector3 AnalyticalUniformBoxInertia(float mass, Vector3 size)
        {
            float x = Mathf.Abs(size.x);
            float y = Mathf.Abs(size.y);
            float z = Mathf.Abs(size.z);
            float k = mass / 12f;
            return new Vector3(
                k * (y * y + z * z),
                k * (x * x + z * z),
                k * (x * x + y * y));
        }

        private static Vector3 ComposePhysicalTorque(Rigidbody body, Vector3 desiredA)
        {
            Quaternion principalWorld = Normalize(body.rotation * body.inertiaTensorRotation);
            Vector3 inertiaAlpha = MultiplyWorldInertia(principalWorld, body.inertiaTensor, desiredA);
            Vector3 angularMomentum = MultiplyWorldInertia(
                principalWorld,
                body.inertiaTensor,
                body.angularVelocity);
            return inertiaAlpha + Vector3.Cross(body.angularVelocity, angularMomentum);
        }

        private static Vector3 MultiplyWorldInertia(
            Quaternion principalWorld,
            Vector3 inertia,
            Vector3 worldVector)
        {
            Vector3 local = Quaternion.Inverse(principalWorld) * worldVector;
            return principalWorld * new Vector3(
                local.x * inertia.x,
                local.y * inertia.y,
                local.z * inertia.z);
        }

        private static Vector3 RotationErrorVector(Quaternion target, Quaternion current)
        {
            Quaternion q = Normalize(target * Quaternion.Inverse(current));
            if (q.w < 0f)
                q = new Quaternion(-q.x, -q.y, -q.z, -q.w);

            float w = Mathf.Clamp(q.w, -1f, 1f);
            float angle = 2f * Mathf.Acos(w);
            float sinHalf = Mathf.Sqrt(Mathf.Max(0f, 1f - w * w));
            if (sinHalf <= Epsilon || angle <= Epsilon)
                return Vector3.zero;

            return new Vector3(q.x / sinHalf, q.y / sinHalf, q.z / sinHalf) * angle;
        }

        private static float RotationErrorDegrees(Quaternion target, Quaternion current)
        {
            return RotationErrorVector(target, current).magnitude * Mathf.Rad2Deg;
        }

        private static Vector3 ComputeAngularVelocity(Quaternion previous, Quaternion current, float dt)
        {
            if (dt <= Epsilon)
                return Vector3.zero;
            return RotationErrorVector(current, previous) / dt;
        }

        private static Vector3 ClampMagnitude(Vector3 value, float maxMagnitude)
        {
            if (!Finite(value))
                return Vector3.zero;
            float magnitude = value.magnitude;
            if (magnitude <= maxMagnitude || magnitude <= Epsilon)
                return value;
            return value * (maxMagnitude / magnitude);
        }

        private static Quaternion Normalize(Quaternion q)
        {
            float magnitude = Mathf.Sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
            if (!Finite(magnitude) || magnitude <= Epsilon)
                return Quaternion.identity;
            float inv = 1f / magnitude;
            return new Quaternion(q.x * inv, q.y * inv, q.z * inv, q.w * inv);
        }

        private static Vector3 SafeNormalize(Vector3 value, Vector3 fallback)
        {
            return Finite(value) && value.sqrMagnitude > Epsilon
                ? value.normalized
                : fallback;
        }

        private static bool PositiveSize(Vector3 value)
        {
            return Finite(value) && value.x > Epsilon && value.y > Epsilon && value.z > Epsilon;
        }

        private static bool PositiveTensor(Vector3 value)
        {
            return PositiveSize(value);
        }

        private static bool LaneFinite(Lane lane)
        {
            return
                lane != null && lane.Ready &&
                Finite(lane.PelvisBody.position) && Finite(lane.PelvisBody.rotation) &&
                Finite(lane.PelvisBody.velocity) && Finite(lane.PelvisBody.angularVelocity) &&
                Finite(lane.ChestBody.position) && Finite(lane.ChestBody.rotation) &&
                Finite(lane.ChestBody.velocity) && Finite(lane.ChestBody.angularVelocity) &&
                Finite(lane.PelvisBody.centerOfMass) && Finite(lane.ChestBody.centerOfMass) &&
                Finite(lane.PelvisBody.inertiaTensorRotation) && Finite(lane.ChestBody.inertiaTensorRotation) &&
                Finite(lane.PelvisBody.mass) && lane.PelvisBody.mass > Epsilon &&
                Finite(lane.ChestBody.mass) && lane.ChestBody.mass > Epsilon &&
                PositiveTensor(lane.PelvisBody.inertiaTensor) &&
                PositiveTensor(lane.ChestBody.inertiaTensor);
        }

        private static bool IsDynamic(Rigidbody body)
        {
            return body != null && !body.isKinematic;
        }

        private static bool Near(Vector3 a, Vector3 b, float tolerance)
        {
            return (a - b).magnitude <= tolerance;
        }

        private static float DecisionRatio(float numerator, float denominator)
        {
            if (!Finite(numerator) || !Finite(denominator))
                return float.PositiveInfinity;
            if (denominator > Epsilon)
                return numerator / denominator;
            return numerator <= Epsilon ? 1f : float.PositiveInfinity;
        }

        private static float Ratio(float numerator, float denominator)
        {
            return denominator > Epsilon ? numerator / denominator : 0f;
        }

        private static bool Finite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private static bool Finite(Vector3 value)
        {
            return Finite(value.x) && Finite(value.y) && Finite(value.z);
        }

        private static bool Finite(Quaternion value)
        {
            return Finite(value.x) && Finite(value.y) && Finite(value.z) && Finite(value.w);
        }

        private static string F(float value)
        {
            return value.ToString("0.######", CultureInfo.InvariantCulture);
        }

        private static string V(Vector3 value)
        {
            return "(" + F(value.x) + "," + F(value.y) + "," + F(value.z) + ")";
        }

        private sealed class Lane
        {
            internal readonly string Tag;
            internal readonly bool ExpectedPreprocessing;
            internal readonly bool ChestComAnchor;
            internal GameObject PelvisObject;
            internal GameObject ChestObject;
            internal Rigidbody PelvisBody;
            internal Rigidbody ChestBody;
            internal CharacterJoint Joint;
            internal Vector3 PelvisAnchorLocal;
            internal Vector3 ChestAnchorLocal;
            internal Vector3 PelvisSize;
            internal Vector3 ChestSize;
            internal Vector3 PelvisExpectedCom;
            internal Vector3 ChestExpectedCom;
            internal Vector3 PelvisExpectedInertia;
            internal Vector3 ChestExpectedInertia;
            internal bool PelvisDynamicObserved;
            internal bool ChestDynamicObserved;
            internal int ReactionValidSamples;
            internal int PelvisAuthorityClampSamples;
            internal int ChestAuthorityClampSamples;
            internal Vector3 LastPelvisAuthorityTorque;
            internal Vector3 LastPelvisDesiredA;
            internal Vector3 LastChestDesiredA;

            internal readonly ScalarStats PelvisRotationError;
            internal readonly ScalarStats ChestRelativeRotationError;
            internal readonly ScalarStats ChestComPositionError;
            internal readonly ScalarStats AnchorClosure;
            internal readonly ScalarStats JointForce;
            internal readonly ScalarStats JointTorque;
            internal readonly ScalarStats ChestLever;
            internal readonly ScalarStats PelvisLever;
            internal readonly ScalarStats ChestForceMoment;
            internal readonly ScalarStats PelvisForceMoment;
            internal readonly ScalarStats PelvisAuthorityTorque;
            internal readonly ScalarStats PelvisAngularSpeed;
            internal readonly ScalarStats ChestAngularSpeed;

            internal Lane(string tag, bool expectedPreprocessing, bool chestComAnchor, uint seed)
            {
                Tag = tag;
                ExpectedPreprocessing = expectedPreprocessing;
                ChestComAnchor = chestComAnchor;
                PelvisRotationError = new ScalarStats(4096, seed + 1u);
                ChestRelativeRotationError = new ScalarStats(4096, seed + 2u);
                ChestComPositionError = new ScalarStats(4096, seed + 3u);
                AnchorClosure = new ScalarStats(4096, seed + 4u);
                JointForce = new ScalarStats(4096, seed + 5u);
                JointTorque = new ScalarStats(4096, seed + 6u);
                ChestLever = new ScalarStats(4096, seed + 7u);
                PelvisLever = new ScalarStats(4096, seed + 8u);
                ChestForceMoment = new ScalarStats(4096, seed + 9u);
                PelvisForceMoment = new ScalarStats(4096, seed + 10u);
                PelvisAuthorityTorque = new ScalarStats(4096, seed + 11u);
                PelvisAngularSpeed = new ScalarStats(4096, seed + 12u);
                ChestAngularSpeed = new ScalarStats(4096, seed + 13u);
            }

            internal bool Ready =>
                PelvisObject != null && ChestObject != null &&
                PelvisBody != null && ChestBody != null && Joint != null;

            internal void ResetStatistics()
            {
                // Per-trace readback evidence must never leak across repeated runs within one build.
                PelvisDynamicObserved = false;
                ChestDynamicObserved = false;
                ReactionValidSamples = 0;
                PelvisAuthorityClampSamples = 0;
                ChestAuthorityClampSamples = 0;
                PelvisRotationError.Reset();
                ChestRelativeRotationError.Reset();
                ChestComPositionError.Reset();
                AnchorClosure.Reset();
                JointForce.Reset();
                JointTorque.Reset();
                ChestLever.Reset();
                PelvisLever.Reset();
                ChestForceMoment.Reset();
                PelvisForceMoment.Reset();
                PelvisAuthorityTorque.Reset();
                PelvisAngularSpeed.Reset();
                ChestAngularSpeed.Reset();
            }
        }

        // Fixed-capacity deterministic reservoir; no per-FixedUpdate allocation.
        // A copy/sort is made only on explicit status/finalize/report requests.
        private sealed class ScalarStats
        {
            private readonly float[] _reservoir;
            private readonly uint _seed;
            private int _count;
            private int _seen;
            private uint _rng;

            internal ScalarStats(int capacity, uint seed)
            {
                _reservoir = new float[Math.Max(32, capacity)];
                _seed = seed != 0u ? seed : 0x9E3779B9u;
                _rng = _seed;
            }

            internal void Observe(float value)
            {
                if (!Finite(value) || value < 0f)
                    return;

                _seen++;
                if (_count < _reservoir.Length)
                {
                    _reservoir[_count++] = value;
                    return;
                }

                _rng ^= _rng << 13;
                _rng ^= _rng >> 17;
                _rng ^= _rng << 5;
                int index = (int)(_rng % (uint)Math.Max(1, _seen));
                if (index < _reservoir.Length)
                    _reservoir[index] = value;
            }

            internal float P99 => Percentile(0.99f);

            private float Percentile(float q)
            {
                if (_count <= 0)
                    return 0f;

                float[] copy = new float[_count];
                Array.Copy(_reservoir, copy, _count);
                Array.Sort(copy);
                float index = Mathf.Clamp01(q) * (_count - 1);
                int low = Mathf.FloorToInt(index);
                int high = Mathf.CeilToInt(index);
                return low == high
                    ? copy[low]
                    : Mathf.Lerp(copy[low], copy[high], index - low);
            }

            internal void Reset()
            {
                _count = 0;
                _seen = 0;
                _rng = _seed;
            }
        }
    }
}
