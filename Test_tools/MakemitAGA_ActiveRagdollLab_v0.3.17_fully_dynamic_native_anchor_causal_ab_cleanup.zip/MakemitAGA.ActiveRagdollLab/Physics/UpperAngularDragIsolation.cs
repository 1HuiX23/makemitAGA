using MakemitAGA.ActiveRagdollLab.Model;
using UnityEngine;

namespace MakemitAGA.ActiveRagdollLab.Physics
{
    /// <summary>
    /// ARL v0.2.82 Upper angular-drag isolation causal A/B.
    ///
    /// A keeps the complete v0.2.81 B backend with the profile-configured Upper Rigidbody.angularDrag.
    /// B changes ONE physical variable only: Upper angularDrag becomes 0 while Lower drag, inertia-space Hip torque,
    /// all controller/reference/authority/transport/positional state and the source character remain unchanged.
    ///
    /// This module never applies force or torque. It only owns dependency-safe drag mutation/readback and per-step
    /// validation. If either Upper or Lower drag readback leaves the intended A/B contract, the caller fails closed.
    /// </summary>
    internal sealed class UpperAngularDragIsolation
    {
        internal const string Mode = "UPPER_ANGULAR_DRAG_ISOLATION_CAUSAL_AB";
        internal const string ArmA = "A_V081_UPPER_ANGULAR_DRAG_PROFILE";
        internal const string ArmB = "B_V082_UPPER_ANGULAR_DRAG_ZERO";

        private const float ReadbackTolerance = 0.0001f;

        private bool _enabled;
        private bool _baselineCaptured;
        private float _baselineUpperDrag;
        private int _steps;
        private int _activeSteps;
        private int _invalidSteps;
        private int _switchCount;
        private float _currentUpperDrag;
        private float _currentLowerDrag;
        private float _currentUpperReadbackError;
        private float _currentLowerReadbackError;
        private float _peakUpperReadbackError;
        private float _peakLowerReadbackError;
        private string _lastEvidence = "<none>";

        internal bool Enabled => _enabled;
        internal string Arm => _enabled ? ArmB : ArmA;
        internal bool CurrentValid { get; private set; } = true;

        internal bool SetEnabled(
            bool enabled,
            Rigidbody upper,
            Rigidbody lower,
            float expectedProfileDrag,
            SingleLegChainReport report)
        {
            CurrentValid = true;
            if (upper == null || lower == null || !IsFinite(expectedProfileDrag) || expectedProfileDrag < 0f ||
                !IsFinite(upper.angularDrag) || !IsFinite(lower.angularDrag))
            {
                _invalidSteps++;
                CurrentValid = false;
                _lastEvidence = "switchInvalid=missingBodyOrNonFiniteDrag";
                CopyToReport(report, upper, lower, expectedProfileDrag);
                return false;
            }

            if (enabled)
            {
                if (_enabled)
                {
                    CopyToReport(report, upper, lower, expectedProfileDrag);
                    return true;
                }

                // Causal contract: A must really be the profile drag before B is entered.
                if (Mathf.Abs(upper.angularDrag - expectedProfileDrag) > ReadbackTolerance ||
                    Mathf.Abs(lower.angularDrag - expectedProfileDrag) > ReadbackTolerance)
                {
                    _invalidSteps++;
                    CurrentValid = false;
                    _lastEvidence =
                        "switchInvalid=baselineReadbackMismatch" +
                        "/upper=" + F(upper.angularDrag) +
                        "/lower=" + F(lower.angularDrag) +
                        "/expected=" + F(expectedProfileDrag);
                    CopyToReport(report, upper, lower, expectedProfileDrag);
                    return false;
                }

                _baselineUpperDrag = upper.angularDrag;
                _baselineCaptured = true;
                upper.angularDrag = 0f;
                if (!IsFinite(upper.angularDrag) || Mathf.Abs(upper.angularDrag) > ReadbackTolerance)
                {
                    upper.angularDrag = _baselineUpperDrag;
                    _invalidSteps++;
                    CurrentValid = false;
                    _lastEvidence = "switchInvalid=upperZeroReadbackFailed/readback=" + F(upper.angularDrag);
                    CopyToReport(report, upper, lower, expectedProfileDrag);
                    return false;
                }

                _enabled = true;
                _switchCount++;
                _lastEvidence =
                    "switch=ON" +
                    "/upper=" + F(upper.angularDrag) +
                    "/lower=" + F(lower.angularDrag) +
                    "/baselineUpper=" + F(_baselineUpperDrag);
            }
            else
            {
                if (_enabled)
                {
                    float restore = _baselineCaptured ? _baselineUpperDrag : expectedProfileDrag;
                    upper.angularDrag = restore;
                    if (!IsFinite(upper.angularDrag) || Mathf.Abs(upper.angularDrag - restore) > ReadbackTolerance)
                    {
                        _invalidSteps++;
                        CurrentValid = false;
                        _lastEvidence = "switchInvalid=upperRestoreReadbackFailed/readback=" + F(upper.angularDrag) + "/restore=" + F(restore);
                        CopyToReport(report, upper, lower, expectedProfileDrag);
                        return false;
                    }
                    _switchCount++;
                }
                _enabled = false;
                _lastEvidence =
                    "switch=OFF" +
                    "/upper=" + F(upper.angularDrag) +
                    "/lower=" + F(lower.angularDrag);
            }

            ResetRunDiagnosticsKeepArm(report, upper, lower, expectedProfileDrag);
            return true;
        }

        internal bool ValidateStep(
            Rigidbody upper,
            Rigidbody lower,
            float expectedProfileDrag,
            SingleLegChainReport report)
        {
            _steps++;
            if (_enabled) _activeSteps++;
            CurrentValid = true;

            if (upper == null || lower == null || !IsFinite(expectedProfileDrag) ||
                !IsFinite(upper.angularDrag) || !IsFinite(lower.angularDrag))
            {
                _invalidSteps++;
                CurrentValid = false;
                _lastEvidence = "step=" + _steps + "/invalid=missingBodyOrNonFiniteDrag";
                CopyToReport(report, upper, lower, expectedProfileDrag);
                return false;
            }

            float expectedUpper = _enabled ? 0f : expectedProfileDrag;
            float expectedLower = expectedProfileDrag;
            _currentUpperDrag = upper.angularDrag;
            _currentLowerDrag = lower.angularDrag;
            _currentUpperReadbackError = Mathf.Abs(_currentUpperDrag - expectedUpper);
            _currentLowerReadbackError = Mathf.Abs(_currentLowerDrag - expectedLower);
            _peakUpperReadbackError = Mathf.Max(_peakUpperReadbackError, _currentUpperReadbackError);
            _peakLowerReadbackError = Mathf.Max(_peakLowerReadbackError, _currentLowerReadbackError);

            if (_currentUpperReadbackError > ReadbackTolerance || _currentLowerReadbackError > ReadbackTolerance)
            {
                _invalidSteps++;
                CurrentValid = false;
                _lastEvidence =
                    "step=" + _steps +
                    "/invalid=dragReadbackMismatch" +
                    "/upper=" + F(_currentUpperDrag) + "/expectedUpper=" + F(expectedUpper) +
                    "/lower=" + F(_currentLowerDrag) + "/expectedLower=" + F(expectedLower);
                CopyToReport(report, upper, lower, expectedProfileDrag);
                return false;
            }

            _lastEvidence =
                "step=" + _steps +
                "/arm=" + Arm +
                "/upper=" + F(_currentUpperDrag) +
                "/lower=" + F(_currentLowerDrag);
            CopyToReport(report, upper, lower, expectedProfileDrag);
            return true;
        }

        internal void ResetRunDiagnosticsKeepArm(
            SingleLegChainReport report,
            Rigidbody upper,
            Rigidbody lower,
            float expectedProfileDrag)
        {
            _steps = 0;
            _activeSteps = 0;
            _invalidSteps = 0;
            _currentUpperReadbackError = 0f;
            _currentLowerReadbackError = 0f;
            _peakUpperReadbackError = 0f;
            _peakLowerReadbackError = 0f;
            CurrentValid = true;
            CopyToReport(report, upper, lower, expectedProfileDrag);
        }

        internal void CopyToReport(
            SingleLegChainReport report,
            Rigidbody upper,
            Rigidbody lower,
            float expectedProfileDrag)
        {
            if (report == null) return;
            if (upper != null && IsFinite(upper.angularDrag)) _currentUpperDrag = upper.angularDrag;
            if (lower != null && IsFinite(lower.angularDrag)) _currentLowerDrag = lower.angularDrag;

            report.HipUpperAngularDragIsolationMode = Mode;
            report.HipUpperAngularDragIsolationArm = Arm;
            report.HipUpperAngularDragIsolationEnabled = _enabled;
            report.HipUpperAngularDragIsolationSteps = _steps;
            report.HipUpperAngularDragIsolationActiveSteps = _activeSteps;
            report.HipUpperAngularDragIsolationInvalidSteps = _invalidSteps;
            report.HipUpperAngularDragIsolationSwitchCount = _switchCount;
            report.HipUpperAngularDragIsolationBaselineUpperDrag = _baselineCaptured ? _baselineUpperDrag : expectedProfileDrag;
            report.HipUpperAngularDragIsolationExpectedUpperDrag = _enabled ? 0f : expectedProfileDrag;
            report.HipUpperAngularDragIsolationExpectedLowerDrag = expectedProfileDrag;
            report.HipUpperAngularDragIsolationCurrentUpperDrag = _currentUpperDrag;
            report.HipUpperAngularDragIsolationCurrentLowerDrag = _currentLowerDrag;
            report.HipUpperAngularDragIsolationCurrentUpperReadbackError = _currentUpperReadbackError;
            report.HipUpperAngularDragIsolationCurrentLowerReadbackError = _currentLowerReadbackError;
            report.HipUpperAngularDragIsolationPeakUpperReadbackError = _peakUpperReadbackError;
            report.HipUpperAngularDragIsolationPeakLowerReadbackError = _peakLowerReadbackError;
            report.HipUpperAngularDragIsolationLastEvidence = _lastEvidence;
            report.HipUpperAngularDragIsolationKey = GetKey(report);
        }

        internal string GetStatus(
            SingleLegChainReport report,
            Rigidbody upper,
            Rigidbody lower,
            float expectedProfileDrag)
        {
            CopyToReport(report, upper, lower, expectedProfileDrag);
            return "ARL Upper angular-drag isolation A/B | mode=" + Mode +
                   " | arm=" + Arm +
                   " | enabled=" + _enabled +
                   " | steps(active/total/invalid)=" + _activeSteps + "/" + _steps + "/" + _invalidSteps +
                   " | drag(upper/expected/lower/expected)=" +
                   F(_currentUpperDrag) + "/" + F(_enabled ? 0f : expectedProfileDrag) + "/" +
                   F(_currentLowerDrag) + "/" + F(expectedProfileDrag) +
                   " | readbackErr(upper/lower/peakU/peakL)=" +
                   F(_currentUpperReadbackError) + "/" + F(_currentLowerReadbackError) + "/" +
                   F(_peakUpperReadbackError) + "/" + F(_peakLowerReadbackError) +
                   " | key=" + GetKey(report);
        }

        internal string GetKey(SingleLegChainReport report)
        {
            string primary;
            if (_invalidSteps > 0 || !CurrentValid)
                primary = "B_INVALID_ANGULAR_DRAG_READBACK";
            else if (!_enabled)
                primary = "A_V081_PROFILE_ANGULAR_DRAG_BASELINE";
            else if (_activeSteps == 0)
                primary = "B_NO_ZERO_DRAG_EXPOSURE";
            else
                primary = "B_ZERO_UPPER_DRAG_ACTIVE_VALID";

            return "primary=" + primary +
                   " | mode=" + Mode +
                   " | arm=" + Arm +
                   " | steps(active/total/invalid)=" + _activeSteps + "/" + _steps + "/" + _invalidSteps +
                   " | drag(upper/lower/baselineUpper)=" + F(_currentUpperDrag) + "/" + F(_currentLowerDrag) + "/" + F(_baselineUpperDrag) +
                   " | readbackPeak(upper/lower)=" + F(_peakUpperReadbackError) + "/" + F(_peakLowerReadbackError) +
                   " | historicalResponseObserver=RETIRED_V0317" +
                   " | abort=" + (report != null && report.DriveAborted ? (report.DriveAbortReason ?? "<none>") : "<none>");
        }

        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private static string F(float value)
        {
            return value.ToString("0.######", System.Globalization.CultureInfo.InvariantCulture);
        }
    }
}
