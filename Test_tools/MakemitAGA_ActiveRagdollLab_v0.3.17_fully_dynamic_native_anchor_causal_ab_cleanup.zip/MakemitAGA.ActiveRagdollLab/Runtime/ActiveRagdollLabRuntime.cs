using System;
using System.IO;
using BepInEx;
using BepInEx.Logging;
using MakemitAGA.ActiveRagdollLab.Acquisition;
using MakemitAGA.ActiveRagdollLab.Configuration;
using MakemitAGA.ActiveRagdollLab.Model;
using MakemitAGA.ActiveRagdollLab.Physics;
using UnityEngine;

namespace MakemitAGA.ActiveRagdollLab.Runtime
{
    internal static class ActiveRagdollLabRuntime
    {
        private static ManualLogSource _logger;
        private static ActiveRagdollLabProfile _profile;
        private static BoneAuditReport _audit;
        private static TwoBodyShadowProxy _proxy;
        private static BilateralLegCoordinator _legChain;
        private static TwoBodyFullyDynamicAnchorIsolationAttribution _fullyDynamicAnchorIsolationAttribution;
        private static SingleLegTargetReport _legTarget;
        private static SingleLegTargetReport _secondaryLegTarget;
        private static string _sceneName;
        private static int _sceneHandle;
        private static bool _shutdown;

        private static string BoneAuditPath => Path.Combine(Paths.ConfigPath, "MakemitAGA.ActiveRagdollLab.BoneAudit.txt");
        private static string ProxyReportPath => Path.Combine(Paths.ConfigPath, "MakemitAGA.ActiveRagdollLab.TwoBodyReport.txt");
        private static string SingleLegReportPath => Path.Combine(Paths.ConfigPath, "MakemitAGA.ActiveRagdollLab.SingleLegReport.txt");
        private static string SecondaryLegReportPath => Path.Combine(Paths.ConfigPath, "MakemitAGA.ActiveRagdollLab.SecondaryLegReport.txt");
        private static string BilateralLegReportPath => Path.Combine(Paths.ConfigPath, "MakemitAGA.ActiveRagdollLab.BilateralLegReport.txt");
        private static string KneeSafetyContextReportPath => Path.Combine(Paths.ConfigPath, "MakemitAGA.ActiveRagdollLab.KneeSafetyContextReport.txt");

        public static void Initialize(ManualLogSource logger)
        {
            _logger = logger;
            _profile = ActiveRagdollLabProfile.Load(logger);
            _shutdown = false;
        }

        public static void OnSceneChanged(string sceneName, int sceneHandle)
        {
            RollbackInternal("scene-change:" + sceneName + "#" + sceneHandle);
            _audit = null;
            _legTarget = null;
            _secondaryLegTarget = null;
            _sceneName = sceneName;
            _sceneHandle = sceneHandle;
            _logger?.LogInfo("[ARL] Cleared | reason=scene-change:" + sceneName + "#" + sceneHandle);
        }

        public static void SampleSourcePoseLateUpdate()
        {
            if (_shutdown)
                return;

            // Production source sampling remains first. The v0.3.17 sandbox then takes its own
            // read-only LateUpdate sample and never writes to the production torso or legs.
            try
            {
                _proxy?.SampleSourcePose();
            }
            catch (Exception e)
            {
                _logger?.LogWarning("[ARL][PRODUCTION_TORSO] LateUpdate sample failed: " + e);
                return;
            }

            try
            {
                _fullyDynamicAnchorIsolationAttribution?.SampleSourcePose();
            }
            catch (Exception e)
            {
                FailCloseFullyDynamicSandbox("LATEUPDATE_SAMPLE", e);
            }

            try
            {
                _legChain?.SampleSourcePose();
            }
            catch (Exception e)
            {
                _logger?.LogWarning("[ARL][PRODUCTION_BILATERAL_LEG] LateUpdate sample failed: " + e);
            }
        }

        public static void FixedUpdate()
        {
            if (_shutdown)
                return;

            try
            {
                _proxy?.FixedUpdate();
            }
            catch (Exception e)
            {
                _logger?.LogWarning("[ARL][PRODUCTION_TORSO] FixedUpdate failed: " + e);
                return;
            }

            try
            {
                _fullyDynamicAnchorIsolationAttribution?.FixedUpdate(_proxy);
            }
            catch (Exception e)
            {
                FailCloseFullyDynamicSandbox("FIXEDUPDATE", e);
            }

            try
            {
                _legChain?.FixedUpdate();
            }
            catch (Exception e)
            {
                _logger?.LogWarning("[ARL][PRODUCTION_BILATERAL_LEG] FixedUpdate failed: " + e);
            }
        }

        public static string EnsureProfileTemplate()
        {
            return ActiveRagdollLabProfile.EnsureTemplate(_logger);
        }

        public static string ReloadProfile()
        {
            if (_proxy != null && _proxy.IsBuilt)
                return "ARL profile reload 被拒绝：请先执行 arl_rollback，避免运行中改变刚体、关节或 production soft-Knee 参数。";
            _profile = ActiveRagdollLabProfile.Load(_logger);
            _audit = null;
            _legTarget = null;
            _secondaryLegTarget = null;
            return _profile.GetStatusText() + " | auditInvalidated=True";
        }

        public static string GetProfileStatus()
        {
            if (_profile == null)
                _profile = ActiveRagdollLabProfile.Load(_logger);
            return _profile.GetStatusText();
        }

        public static string Audit(string optionalTargetName)
        {
            if (_profile == null)
                _profile = ActiveRagdollLabProfile.Load(_logger);

            string targetName = string.IsNullOrWhiteSpace(optionalTargetName)
                ? _profile.TargetName
                : optionalTargetName.Trim();

            if (_proxy != null && _proxy.IsBuilt)
                RollbackInternal("new-audit");

            _audit = BoneHierarchyAuditor.Audit(targetName, _profile);
            _legTarget = null;
            _secondaryLegTarget = null;
            if (_audit.Success && _profile.SingleLegEnabled)
            {
                _legTarget = SingleLegTargetResolver.Resolve(_audit.TargetRoot, _profile.SingleLegSide, _profile.SingleLegUpperBonePath, _profile.SingleLegLowerBonePath, _profile.SingleLegFootBonePath);
                AppendLegTargetAuditLine(_audit, "PRIMARY", _legTarget);

                if (_profile.BilateralLegEnabled)
                {
                    string secondarySide = OppositeLegSide(_legTarget.RequestedSide);
                    // The legacy explicit path triplet belongs only to the configured primary side. The opposite side
                    // deliberately uses the already validated Humanoid/MiSide-canonical/structural resolver.
                    _secondaryLegTarget = SingleLegTargetResolver.Resolve(_audit.TargetRoot, secondarySide, string.Empty, string.Empty, string.Empty);
                    AppendLegTargetAuditLine(_audit, "SECONDARY", _secondaryLegTarget);
                }
            }
            WriteTextFile(BoneAuditPath, _audit.GetFullText());

            string summary = _audit.GetConsoleSummary() + " | fullReport=" + BoneAuditPath;
            if (_profile.SingleLegEnabled)
            {
                summary += " | primaryLeg=" + (_legTarget != null && _legTarget.Success) +
                           "/" + (_legTarget != null ? _legTarget.RequestedSide : "<none>") +
                           "/" + (_legTarget != null ? _legTarget.ResolutionMode : "<none>") +
                           "/chain=" + (_legTarget != null ? (_legTarget.ChainValidation ?? "<none>") : "<none>") +
                           " | bilateral=" + _profile.BilateralLegEnabled +
                           "/secondary=" + (!_profile.BilateralLegEnabled || (_secondaryLegTarget != null && _secondaryLegTarget.Success)) +
                           "/" + (_secondaryLegTarget != null ? _secondaryLegTarget.RequestedSide : "<disabled>");
            }
            if (_audit.Success)
                _logger?.LogWarning("[ARL][BONE_AUDIT] " + summary);
            else
                _logger?.LogWarning("[ARL][BONE_AUDIT] failed | " + summary);
            return summary;
        }

        public static string WriteAuditReportAndGetSummary()
        {
            if (_audit == null)
                return "ARL bone audit：尚无报告。先执行 arl_audit。";
            WriteTextFile(BoneAuditPath, _audit.GetFullText());
            return _audit.GetConsoleSummary() + " | fullReport=" + BoneAuditPath;
        }

        public static string ProbeComponentCreation()
        {
            if (_proxy != null && _proxy.IsBuilt)
                return "ARL component probe 被拒绝：请先执行 arl_rollback，避免与活动 production 代理混用。";

            string result = ComponentCapabilityProbe.Run();
            _logger?.LogWarning("[ARL][COMPONENT_PROBE] " + result);
            return result;
        }

        public static string Build(string optionalTargetName)
        {
            if (_profile == null)
                _profile = ActiveRagdollLabProfile.Load(_logger);

            if (_proxy != null && _proxy.IsBuilt)
                return "ARL build：代理已经存在。请先执行 arl_rollback。";

            if (!string.IsNullOrWhiteSpace(optionalTargetName) || _audit == null || !_audit.Success)
            {
                string auditResult = Audit(optionalTargetName);
                if (_audit == null || !_audit.Success)
                    return auditResult + "\nARL build：骨骼审计未通过，未创建任何物理对象。";
            }

            if (_profile.SingleLegEnabled && (_legTarget == null || !_legTarget.Success))
            {
                _legTarget = SingleLegTargetResolver.Resolve(_audit.TargetRoot, _profile.SingleLegSide, _profile.SingleLegUpperBonePath, _profile.SingleLegLowerBonePath, _profile.SingleLegFootBonePath);
                if (!_legTarget.Success)
                    return "ARL build：primary leg目标解析失败，未创建物理对象。" + (_legTarget.Error ?? string.Empty);
            }
            if (_profile.SingleLegEnabled && _profile.BilateralLegEnabled && (_secondaryLegTarget == null || !_secondaryLegTarget.Success))
            {
                _secondaryLegTarget = SingleLegTargetResolver.Resolve(_audit.TargetRoot, OppositeLegSide(_legTarget.RequestedSide), string.Empty, string.Empty, string.Empty);
                if (!_secondaryLegTarget.Success)
                    return "ARL build：secondary leg目标解析失败，未创建物理对象。" + (_secondaryLegTarget.Error ?? string.Empty);
            }

            _proxy = new TwoBodyShadowProxy(_profile, _audit);
            string torsoResult = _proxy.Build();
            if (!_proxy.IsBuilt)
            {
                // Torso 与 bilateral/per-leg 报告统一由聚合写入器维护；失败路径也走同一入口。
                WriteAllReports();
                _logger?.LogWarning("[ARL][TWO_BODY] build-failed | " + torsoResult);
                return torsoResult;
            }
            _logger?.LogWarning("[ARL][TWO_BODY_FROZEN_BASELINE] " + torsoResult);

            _fullyDynamicAnchorIsolationAttribution =
                new TwoBodyFullyDynamicAnchorIsolationAttribution(_profile, _audit);
            string isolationResult = _fullyDynamicAnchorIsolationAttribution.Build(_proxy);
            if (!_fullyDynamicAnchorIsolationAttribution.Built)
            {
                _logger?.LogError("[ARL][V0317_FULLY_DYNAMIC_ANCHOR_CAUSAL_AB] build-failed | " + isolationResult);
                RollbackInternal("v0317-fully-dynamic-anchor-causal-ab-build-failed");
                return torsoResult + "\n" + isolationResult + "\nARL build：v0.3.17 隔离双动态 Pelvis/Chest native CharacterJoint anchor causal A/B foundation 失败，已整体回滚。";
            }
            _logger?.LogWarning("[ARL][V0317_FULLY_DYNAMIC_ANCHOR_CAUSAL_AB] " + isolationResult);

            string legResult = "singleLegEnabled=False";
            if (_profile.SingleLegEnabled)
            {
                _legChain = new BilateralLegCoordinator(
                    _profile,
                    _legTarget,
                    _secondaryLegTarget,
                    _audit.TargetRoot,
                    _proxy,
                    _profile.BilateralLegEnabled);
                legResult = _legChain.Build();
                if (!_legChain.IsBuilt)
                {
                    _logger?.LogError("[ARL][BILATERAL_LEG] build-failed | " + legResult);
                    RollbackInternal("bilateral-leg-build-failed");
                    return torsoResult + "\n" + legResult + "\nARL build：腿部foundation失败，已整体回滚。";
                }
                _logger?.LogWarning("[ARL][BILATERAL_LEG] " + legResult);
            }

            WriteAllReports();
            return torsoResult + "\n" + isolationResult + "\n" + legResult;
        }

        public static string SetDrive(bool enabled)
        {
            if (_proxy == null)
                return "ARL drive：代理尚未创建。";

            // 关闭 torso 前先终止 source-only Knee 标定、腿部动态和 v0.3.17 隔离双动态接收器。
            if (!enabled && _legChain != null && _legChain.KneeAxisCalibrationCollecting)
                _legChain.SetKneeAxisCalibration(false);
            if (!enabled && _legChain != null && _legChain.DriveEnabled)
                _legChain.SetDrive(false);
            if (!enabled && _fullyDynamicAnchorIsolationAttribution != null)
                _fullyDynamicAnchorIsolationAttribution.SetDrive(false, _proxy);

            string torso = _proxy.SetDrive(enabled);
            string isolation = "fullyDynamicAnchorIsolation=not-built";
            if (_fullyDynamicAnchorIsolationAttribution != null && _fullyDynamicAnchorIsolationAttribution.Built)
            {
                if (!enabled || _proxy.DriveEnabled)
                    isolation = _fullyDynamicAnchorIsolationAttribution.SetDrive(enabled, _proxy);
                else
                    isolation = "fullyDynamicAnchorIsolation=not-started-because-production-drive-failed";
            }
            WriteAllReports();
            string result = torso + " | " + isolation;
            _logger?.LogWarning("[ARL][DRIVE] " + result);
            return result;
        }

        public static string SetLegDrive(bool enabled)
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL leg drive：bilateral leg foundation尚未创建。";
            if (enabled && (_proxy == null || !_proxy.IsBuilt || !_proxy.DriveEnabled))
                return "ARL leg drive：拒绝启动。请先执行 arl_drive(on)，让冻结 Pelvis Pose Bridge 成为活动父体。";

            string result = _legChain.SetDrive(enabled);
            WriteAllReports();
            _logger?.LogWarning("[ARL][LEG_DRIVE] " + result);
            return result;
        }

        public static string SetHipExperimentStack(bool enabled)
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL Hip experiment stack：bilateral leg foundation尚未创建。";
            string result = _legChain.SetHipExperimentStack(enabled);
            WriteAllReports();
            _logger?.LogWarning("[ARL][HIP_EXPERIMENT_STACK] " + result);
            return result;
        }

        public static string GetHipExperimentStackStatus()
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL Hip experiment stack | built=False";
            string result = _legChain.GetHipExperimentStackStatus();
            WriteAllReports();
            _logger?.LogWarning("[ARL][HIP_EXPERIMENT_STACK_STATUS] " + result);
            return result;
        }







        public static string GetSingleLegFreezeStatus()
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL v0.2.122 Single-Leg freeze readiness | built=False";
            string result = _legChain.GetSingleLegFreezeStatus();
            WriteAllReports();
            _logger?.LogWarning("[ARL][SINGLE_LEG_FREEZE_STATUS] " + result);
            return result;
        }

        public static string SetKneeAxisCalibration(bool enabled)
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL knee axis calibration：bilateral leg foundation尚未创建。";
            string result = _legChain.SetKneeAxisCalibration(enabled);
            WriteAllReports();
            return result;
        }

        public static string GetKneeAxisCalibrationStatus()
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL knee axis calibration | built=False";
            string result = _legChain.GetKneeAxisCalibrationStatus();
            _logger?.LogWarning("[ARL][KNEE_AXIS_CALIBRATION_STATUS] " + result);
            WriteAllReports();
            return result;
        }

        public static string ApplyCalibratedKneeAxis()
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL knee axis apply：bilateral leg foundation尚未创建。";
            string result = _legChain.ApplyCalibratedKneeAxis();
            WriteAllReports();
            return result;
        }

        public static string ResetKneeAxisToInitial()
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL knee axis reset：bilateral leg foundation尚未创建。";
            string result = _legChain.ResetKneeAxisToInitial();
            WriteAllReports();
            return result;
        }



        public static string GetLegStatus()
        {
            if (_legChain == null)
                return "ARL bilateral foundation | built=False";
            string result = _legChain.GetStatus();
            _logger?.LogWarning("[ARL][LEG_STATUS] " + result);
            return result;
        }

        public static string GetBilateralStatus()
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL v0.3.14 bilateral foundation | built=False";
            string result = _legChain.GetBilateralStatus();
            WriteAllReports();
            _logger?.LogWarning("[ARL][BILATERAL_STATUS] " + result);
            return result;
        }


        public static string GetKneeSafetyContextStatus()
        {
            if (_legChain == null || !_legChain.IsBuilt)
                return "ARL v0.3.14 Knee hard-safety context | built=False";
            string result = _legChain.GetKneeSafetyContextStatus();
            WriteAllReports();
            _logger?.LogWarning("[ARL][KNEE_SAFETY_CONTEXT_STATUS] " + result);
            return result;
        }

        public static string GetTwoBodyFullyDynamicAnchorIsolationStatus()
        {
            if (_fullyDynamicAnchorIsolationAttribution == null || !_fullyDynamicAnchorIsolationAttribution.Built)
                return "ARL v0.3.17 fully-dynamic Pelvis/Chest native anchor causal A/B | built=False";

            string result = _fullyDynamicAnchorIsolationAttribution.GetStatus(_proxy);
            WriteAllReports();
            // Version-specific causal A/B telemetry is intentionally log-only.
            // Keep the complete scorable summary in BepInEx output.log instead of creating another per-version TXT.
            _logger?.LogWarning("[ARL][V0317_FULLY_DYNAMIC_ANCHOR_CAUSAL_AB_STATUS] " + result);
            return result;
        }

        public static string SetGravity(bool enabled)
        {
            if (_proxy == null)
                return "ARL gravity：代理尚未创建。";
            string torso = _proxy.SetGravity(enabled);
            string leg = _legChain != null ? _legChain.SetGravity(enabled) : "leg=not-built";
            WriteAllReports();
            string result = torso + " | " + leg;
            _logger?.LogInfo("[ARL][GRAVITY] " + result);
            return result;
        }

        public static string SetColliders(bool enabled)
        {
            if (_proxy == null)
                return "ARL colliders：代理尚未创建。";
            string torso = _proxy.SetColliders(enabled);
            string leg = _legChain != null ? _legChain.SetColliders(enabled) : "leg=not-built";
            WriteAllReports();
            string result = torso + " | " + leg;
            _logger?.LogWarning("[ARL][COLLIDERS] " + result);
            return result;
        }

        public static string SetVisual(bool enabled)
        {
            if (_proxy == null)
                return "ARL visual：代理尚未创建。";
            string torso = _proxy.SetVisual(enabled);
            string leg = _legChain != null ? _legChain.SetVisual(enabled) : "leg=not-built";
            WriteAllReports();
            return torso + " | " + leg;
        }

        public static string ResetPose()
        {
            if (_proxy == null)
                return "ARL reset：代理尚未创建。";
            if (_legChain != null && _legChain.DriveEnabled)
                _legChain.SetDrive(false);
            string torso = _proxy.ResetPose();
            string isolation = _fullyDynamicAnchorIsolationAttribution != null
                ? _fullyDynamicAnchorIsolationAttribution.ResetPose()
                : "fullyDynamicAnchorIsolation=not-built";
            string leg = _legChain != null ? _legChain.ResetPose() : "leg=not-built";
            WriteAllReports();
            string result = torso + " | " + isolation + " | " + leg;
            _logger?.LogWarning("[ARL][RESET] " + result);
            return result;
        }

        public static string GetStatus()
        {
            string result;
            if (_proxy == null)
                result = "ARL proxy | built=False | scene=" + (_sceneName ?? "<none>") + "#" + _sceneHandle;
            else
                result = _proxy.Report.GetConsoleSummary() +
                         "\n" + (_fullyDynamicAnchorIsolationAttribution != null ? _fullyDynamicAnchorIsolationAttribution.GetStatus(_proxy) : "ARL v0.3.17 fully-dynamic Pelvis/Chest native anchor causal A/B | built=False") +
                         "\n" + (_legChain != null ? _legChain.GetKneeSafetyContextStatus() : "ARL Knee hard-safety context | built=False") +
                         "\n" + (_legChain != null ? _legChain.GetStatus() : "ARL bilateral foundation | built=False");
            _logger?.LogWarning("[ARL][STATUS] " + result);
            return result;
        }

        public static string SetTrace(bool enabled)
        {
            if (_proxy == null)
                return "ARL trace：代理尚未创建。";
            if (enabled && _legChain != null && _legChain.KneeAxisCalibrationCollecting)
                return "ARL trace：拒绝启动。Knee axis calibration 正在收集，请先 arl_knee_axis_calibrate(off)。";

            string torso = _proxy.SetTrace(enabled);
            string leg = _legChain != null ? _legChain.SetTrace(enabled) : "leg=not-built";
            string isolation = "fullyDynamicAnchorIsolation=not-built";
            if (_fullyDynamicAnchorIsolationAttribution != null && _fullyDynamicAnchorIsolationAttribution.Built)
            {
                if (enabled)
                {
                    _fullyDynamicAnchorIsolationAttribution.BeginTrace(_proxy);
                    isolation = _fullyDynamicAnchorIsolationAttribution.GetStatus(_proxy);
                }
                else
                {
                    isolation = _fullyDynamicAnchorIsolationAttribution.Finalize(_proxy);
                    _logger?.LogWarning("[ARL][V0317_FULLY_DYNAMIC_ANCHOR_CAUSAL_AB] " + isolation);
                }
            }
            WriteAllReports();
            string result = torso + " | " + leg + " | " + isolation;
            _logger?.LogInfo("[ARL][TRACE_CONTROL] " + result);
            return result;
        }

        public static string WriteProxyReportAndGetSummary()
        {
            if (_proxy == null)
                return "ARL proxy：尚无报告。";
            WriteAllReports();
            string result = _proxy.Report.GetConsoleSummary() + " | fullReport=" + ProxyReportPath;
            if (_legChain != null)
                result += "\n" + _legChain.GetStatus() +
                          " | primaryReport=" + SingleLegReportPath +
                          (_legChain.BilateralEnabled ? " | secondaryReport=" + SecondaryLegReportPath + " | bilateralReport=" + BilateralLegReportPath : string.Empty) +
                          (_legChain.KneeSafetyReport != null ? " | kneeSafetyContextReport=" + KneeSafetyContextReportPath : string.Empty);
            return result;
        }

        public static string Rollback(string reason)
        {
            return RollbackInternal(reason);
        }

        public static void NotifyProxyCollision(string bodyLabel, string phase, Collision collision)
        {
            if (_shutdown || _proxy == null || !_proxy.IsBuilt)
                return;
            try
            {
                _proxy.NotifyCollision(bodyLabel, phase, collision);
                if (phase == "ENTER")
                {
                    string other = _proxy.Report.LastContactOther ?? "<unknown>";
                    _logger?.LogInfo(
                        "[ARL][CONTACT] phase=ENTER | body=" + bodyLabel +
                        " | other=" + other +
                        " | enterCount=" + _proxy.Report.ContactEnterCount);
                }
            }
            catch (Exception e)
            {
                _logger?.LogWarning("[ARL][CONTACT] callback-failed | " + e.GetType().Name + " / " + e.Message);
            }
        }

        public static void Shutdown(string reason)
        {
            if (_shutdown)
                return;
            _shutdown = true;
            RollbackInternal("shutdown:" + reason);
            _logger?.LogInfo("[ARL] Shutdown complete | reason=" + reason);
        }

        private static void FailCloseFullyDynamicSandbox(string phase, Exception e)
        {
            _logger?.LogWarning(
                "[ARL][SANDBOX_ISOLATED] owner=V0316_FULLY_DYNAMIC_ANCHOR_AB | phase=" + phase +
                " | productionContinues=True | " + (e != null ? e.ToString() : "<null-exception>"));

            try
            {
                _fullyDynamicAnchorIsolationAttribution?.MarkExternalFault(phase, e);
            }
            catch (Exception closeError)
            {
                _logger?.LogWarning(
                    "[ARL][SANDBOX_ISOLATED] fail-close also failed | phase=" + phase +
                    " | " + closeError);
            }
        }

        private static string RollbackInternal(string reason)
        {
            if (_proxy == null && _legChain == null && _fullyDynamicAnchorIsolationAttribution == null)
                return "ARL rollback | cleared=False | reason=" + reason + " | detail=no-active-object";


            string legResult = null;
            if (_fullyDynamicAnchorIsolationAttribution != null)
            {
                try { _fullyDynamicAnchorIsolationAttribution.Destroy(); } catch { }
                _fullyDynamicAnchorIsolationAttribution = null;
            }
            if (_legChain != null)
            {
                try { legResult = _legChain.Rollback(reason); }
                catch (Exception e) { legResult = "ARL bilateral-leg rollback failed：" + e.GetType().Name + " / " + e.Message; }
                _legChain = null;
            }

            string torsoResult = "torso=not-built";
            if (_proxy != null)
            {
                try { torsoResult = _proxy.Rollback(reason); }
                catch (Exception e) { torsoResult = "ARL rollback failed：" + e.GetType().Name + " / " + e.Message; }
                _proxy = null;
            }
            _legTarget = null;
            _secondaryLegTarget = null;
            string result = torsoResult +
                            (legResult != null ? " | " + legResult : string.Empty);
            _logger?.LogInfo("[ARL] " + result);
            return result;
        }

        private static void WriteAllReports()
        {
            if (_proxy != null)
                WriteTextFile(ProxyReportPath, _proxy.Report.GetFullText());
            if (_legChain != null)
            {
                if (_legChain.PrimaryReport != null)
                    WriteTextFile(SingleLegReportPath, _legChain.PrimaryReport.GetFullText());
                if (_legChain.BilateralEnabled && _legChain.SecondaryReport != null)
                    WriteTextFile(SecondaryLegReportPath, _legChain.SecondaryReport.GetFullText());
                if (_legChain.BilateralEnabled && _legChain.BilateralReport != null)
                    WriteTextFile(BilateralLegReportPath, _legChain.BilateralReport.GetFullText());
                if (_legChain.KneeSafetyReport != null)
                    WriteTextFile(KneeSafetyContextReportPath, _legChain.KneeSafetyReport.GetFullText());
            }
        }

        private static string OppositeLegSide(string side)
        {
            return string.Equals(side, "RIGHT", StringComparison.OrdinalIgnoreCase) ? "Left" : "Right";
        }

        private static void AppendLegTargetAuditLine(BoneAuditReport audit, string role, SingleLegTargetReport target)
        {
            if (audit == null || target == null) return;
            audit.Lines.Add(
                "[ARL Leg Target] role=" + role +
                " | success=" + target.Success +
                " | side=" + target.RequestedSide +
                " | mode=" + target.ResolutionMode +
                " | candidateRoot=" + (target.CandidateRootPath ?? "<none>") +
                " | chainValidation=" + (target.ChainValidation ?? "<none>") +
                " | upper=" + (target.UpperLegPath ?? "<missing>") +
                " | lower=" + (target.LowerLegPath ?? "<missing>") +
                " | foot=" + (target.FootPath ?? "<missing>") +
                " | detail=" + (target.ResolutionDetail ?? "<none>") +
                " | error=" + (target.Error ?? "<none>"));
        }

        private static void WriteTextFile(string path, string content)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                File.WriteAllText(path, content ?? string.Empty);
            }
            catch (Exception e)
            {
                _logger?.LogWarning("[ARL] report-write-failed | path=" + path + " | " + e.Message);
            }
        }
    }
}
