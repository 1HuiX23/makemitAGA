using System;
using HarmonyLib;
using MakemitAGA.ActiveRagdollLab.Runtime;

namespace MakemitAGA.ActiveRagdollLab
{
    /// <summary>
    /// v0.3.x current console surface only. Historical experiment command aliases/retired-command compatibility
    /// are intentionally absent; archived ZIPs remain the source of truth for old command surfaces.
    /// </summary>
    public static class ActiveRagdollConsolePatch
    {
        [HarmonyPatch(typeof(ConsoleCommandsGame), "Command")]
        [HarmonyPrefix]
        public static bool InterceptCommand(string code)
        {
            string command = (code ?? string.Empty).Trim();
            if (!command.StartsWith("arl_", StringComparison.OrdinalIgnoreCase))
                return true;

            try
            {
                if (TryHandle(command))
                    return false;
            }
            catch (Exception e)
            {
                Plugin.Logger?.LogError("[ARL] Command failed: " + e);
                PrintGame("<color=red>ARL 命令失败：</color> " + e.GetType().Name + " / " + e.Message);
                return false;
            }

            PrintGame("<color=yellow>未知 ARL 命令。</color> 输入 arl_help 查看当前维护版命令。\n");
            return false;
        }

        private static bool TryHandle(string command)
        {
            if (IsBare(command, "arl_help"))
            {
                PrintHelp();
                return true;
            }
            if (IsBare(command, "arl_profile_template"))
            {
                PrintGame(ActiveRagdollLabRuntime.EnsureProfileTemplate());
                return true;
            }
            if (IsBare(command, "arl_profile_reload"))
            {
                PrintGame(ActiveRagdollLabRuntime.ReloadProfile());
                return true;
            }
            if (IsBare(command, "arl_profile_status"))
            {
                PrintGame(ActiveRagdollLabRuntime.GetProfileStatus());
                return true;
            }
            if (IsBare(command, "arl_audit"))
            {
                PrintGame(ActiveRagdollLabRuntime.Audit(null));
                return true;
            }
            if (TryParseCall(command, "arl_audit", out string[] auditArgs))
            {
                if (auditArgs.Length != 1 || string.IsNullOrWhiteSpace(auditArgs[0]))
                    PrintGame("用法：arl_audit 或 arl_audit(对象完整名称)");
                else
                    PrintGame(ActiveRagdollLabRuntime.Audit(auditArgs[0]));
                return true;
            }
            if (IsBare(command, "arl_audit_report"))
            {
                PrintGame(ActiveRagdollLabRuntime.WriteAuditReportAndGetSummary());
                return true;
            }
            if (IsBare(command, "arl_component_probe"))
            {
                PrintGame(ActiveRagdollLabRuntime.ProbeComponentCreation());
                return true;
            }
            if (IsBare(command, "arl_build"))
            {
                PrintGame(ActiveRagdollLabRuntime.Build(null));
                return true;
            }
            if (TryParseCall(command, "arl_build", out string[] buildArgs))
            {
                if (buildArgs.Length != 1 || string.IsNullOrWhiteSpace(buildArgs[0]))
                    PrintGame("用法：arl_build 或 arl_build(对象完整名称)");
                else
                    PrintGame(ActiveRagdollLabRuntime.Build(buildArgs[0]));
                return true;
            }

            if (TryParseOnOffCall(command, "arl_visual", out bool visual, out bool visualValid))
            {
                if (visualValid) PrintGame(ActiveRagdollLabRuntime.SetVisual(visual));
                return true;
            }
            if (TryParseOnOffCall(command, "arl_colliders", out bool colliders, out bool collidersValid))
            {
                if (collidersValid) PrintGame(ActiveRagdollLabRuntime.SetColliders(colliders));
                return true;
            }
            if (TryParseOnOffCall(command, "arl_gravity", out bool gravity, out bool gravityValid))
            {
                if (gravityValid) PrintGame(ActiveRagdollLabRuntime.SetGravity(gravity));
                return true;
            }
            if (TryParseOnOffCall(command, "arl_drive", out bool drive, out bool driveValid))
            {
                if (driveValid) PrintGame(ActiveRagdollLabRuntime.SetDrive(drive));
                return true;
            }

            if (TryParseOnOffCall(command, "arl_knee_axis_calibrate", out bool calibrate, out bool calibrateValid))
            {
                if (calibrateValid) PrintGame(ActiveRagdollLabRuntime.SetKneeAxisCalibration(calibrate));
                return true;
            }
            if (IsBare(command, "arl_knee_axis_status"))
            {
                PrintGame(ActiveRagdollLabRuntime.GetKneeAxisCalibrationStatus());
                return true;
            }
            if (IsBare(command, "arl_knee_axis_apply"))
            {
                PrintGame(ActiveRagdollLabRuntime.ApplyCalibratedKneeAxis());
                return true;
            }
            if (IsBare(command, "arl_knee_axis_reset"))
            {
                PrintGame(ActiveRagdollLabRuntime.ResetKneeAxisToInitial());
                return true;
            }

            if (TryParseOnOffCall(command, "arl_hip_stack", out bool stack, out bool stackValid))
            {
                if (stackValid) PrintGame(ActiveRagdollLabRuntime.SetHipExperimentStack(stack));
                return true;
            }
            if (IsBare(command, "arl_hip_stack_status"))
            {
                PrintGame(ActiveRagdollLabRuntime.GetHipExperimentStackStatus());
                return true;
            }


            if (IsBare(command, "arl_leg_freeze_status"))
            {
                PrintGame(ActiveRagdollLabRuntime.GetSingleLegFreezeStatus());
                return true;
            }

            if (IsBare(command, "arl_bilateral_status"))
            {
                PrintGame(ActiveRagdollLabRuntime.GetBilateralStatus());
                return true;
            }

            if (IsBare(command, "arl_twobody_dynamic_status"))
            {
                PrintGame(ActiveRagdollLabRuntime.GetTwoBodyFullyDynamicAnchorIsolationStatus());
                return true;
            }
            if (IsBare(command, "arl_knee_safety_status"))
            {
                PrintGame(ActiveRagdollLabRuntime.GetKneeSafetyContextStatus());
                return true;
            }


            if (TryParseOnOffCall(command, "arl_trace", out bool trace, out bool traceValid))
            {
                if (traceValid) PrintGame(ActiveRagdollLabRuntime.SetTrace(trace));
                return true;
            }
            if (TryParseOnOffCall(command, "arl_leg_drive", out bool legDrive, out bool legDriveValid))
            {
                if (legDriveValid) PrintGame(ActiveRagdollLabRuntime.SetLegDrive(legDrive));
                return true;
            }
            if (IsBare(command, "arl_leg_status"))
            {
                PrintGame(ActiveRagdollLabRuntime.GetLegStatus());
                return true;
            }
            if (IsBare(command, "arl_reset_pose"))
            {
                PrintGame(ActiveRagdollLabRuntime.ResetPose());
                return true;
            }
            if (IsBare(command, "arl_status"))
            {
                PrintGame(ActiveRagdollLabRuntime.GetStatus());
                return true;
            }
            if (IsBare(command, "arl_report"))
            {
                PrintGame(ActiveRagdollLabRuntime.WriteProxyReportAndGetSummary());
                return true;
            }
            if (IsBare(command, "arl_rollback"))
            {
                PrintGame(ActiveRagdollLabRuntime.Rollback("console"));
                return true;
            }

            return false;
        }

        private static bool IsBare(string command, string verb)
        {
            return command.Equals(verb, StringComparison.OrdinalIgnoreCase) ||
                   command.Equals(verb + "()", StringComparison.OrdinalIgnoreCase);
        }


        private static void PrintHelp()
        {
            PrintGame(
                "<color=#66E0FF><b>MakemitAGA ARL v0.3.17 — Fully-Dynamic Native Anchor Causal A/B</b></color>\n" +
                "<color=#c7f9cc>v0.3.16.5 closed the common Rigidbody/Transform state-domain defect and completed a scorable fully-dynamic receiver run; preprocessing ON/OFF had no material effect. v0.3.17 keeps preprocessing ON in both lanes and restores the original anchor question on the hardened Rigidbody-domain foundation: F0 uses the calibrated source/spine CharacterJoint anchor, F1 places the Chest-side native anchor at the explicit Chest COM and recomputes connectedAnchor for exact world coincidence.</color>\n\n" +
                "<b>Setup</b>\n" +
                "arl_profile_template / arl_profile_reload / arl_profile_status\n" +
                "arl_audit[(对象完整名称)] / arl_audit_report / arl_component_probe\n" +
                "arl_build[(对象完整名称)]\n" +
                "arl_visual(on/off) / arl_colliders(on/off) / arl_gravity(on/off) / arl_drive(on/off)\n\n" +
                "<b>Bilateral Knee PCA + frozen production stack</b>\n" +
                "arl_knee_axis_calibrate(on/off) / arl_knee_axis_status / arl_knee_axis_apply / arl_knee_axis_reset\n" +
                "arl_hip_stack(on/off) / arl_hip_stack_status\n\n" +
                "<b>Run / current diagnostics</b>\n" +
                "arl_trace(on/off) / arl_leg_drive(on/off) / arl_leg_status\n" +
                "arl_bilateral_status / arl_twobody_dynamic_status / arl_knee_safety_status / arl_leg_freeze_status\n" +
                "arl_reset_pose / arl_status / arl_report / arl_rollback\n\n" +
                "<color=#ffcf66>v0.3.17 changes no production controller authority, mass properties, Gravity/Colliders, PCA, bilateral clock, Single-Leg physics, or the 30mm Knee hard fail-close. The sandbox still runs two PASSIVE fully-dynamic solves before controller activation, has no colliders/gravity and no production feedback. Rigidbody/Transform 1mm / 0.1deg state-domain hard gates and Rigidbody-domain physical geometry from v0.3.16.5 remain mandatory.</color>");
        }

        private static bool TryParseOnOffCall(string command, string verb, out bool value, out bool valid)
        {
            value = false;
            valid = false;
            if (!TryParseCall(command, verb, out string[] args))
                return false;
            if (args.Length != 1 || !TryParseOnOff(args[0], out value))
            {
                PrintGame("用法：" + verb + "(on/off)");
                return true;
            }
            valid = true;
            return true;
        }

        private static bool TryParseOnOff(string text, out bool value)
        {
            value = false;
            string input = (text ?? string.Empty).Trim();
            if (input.Equals("on", StringComparison.OrdinalIgnoreCase) || input.Equals("true", StringComparison.OrdinalIgnoreCase) || input == "1")
            {
                value = true;
                return true;
            }
            if (input.Equals("off", StringComparison.OrdinalIgnoreCase) || input.Equals("false", StringComparison.OrdinalIgnoreCase) || input == "0")
            {
                value = false;
                return true;
            }
            return false;
        }

        private static bool TryParseCall(string command, string verb, out string[] args)
        {
            args = Array.Empty<string>();
            if (!command.StartsWith(verb, StringComparison.OrdinalIgnoreCase))
                return false;
            string tail = command.Substring(verb.Length).Trim();
            if (tail.Length < 2 || tail[0] != '(' || tail[tail.Length - 1] != ')')
                return false;
            string inner = tail.Substring(1, tail.Length - 2);
            if (string.IsNullOrWhiteSpace(inner))
                return true;
            args = inner.Split(',');
            for (int i = 0; i < args.Length; i++)
                args[i] = args[i].Trim();
            return true;
        }

        internal static void PrintLegExperimentInvalidAfterAbort(string reason)
        {
            string safeReason = string.IsNullOrWhiteSpace(reason) ? "<none>" : reason;
            PrintGame(
                "<color=#ff4d4f><b>【ARL 本轮 Single-Leg 实验已失效】</b></color>\n" +
                "<color=#ffd166>安全门已自动关闭 leg drive；此提示之后的数据不再计入本轮 Single-Leg 实验。</color>\n" +
                "<color=#9fe7ff>建议停止动作 → arl_trace(off) → arl_reset_pose → 重新 arl_leg_drive(on)。</color>\n" +
                "<color=#ffb0b0>原因：</color>" + safeReason);
        }

        private const int MaxGameConsoleCharacters = 6000;
        private const int SafePrefixCharacters = 5200;

        internal static void PrintGame(string text)
        {
            string value = text ?? string.Empty;
            if (value.Length > MaxGameConsoleCharacters)
            {
                Plugin.Logger?.LogWarning("[ARL][GameConsole] output-over-budget | chars=" + value.Length + " | budget=" + MaxGameConsoleCharacters);
                Plugin.Logger?.LogInfo("[ARL][GameConsole][FULL_OUTPUT]\n" + value);
                value = value.Substring(0, Math.Min(SafePrefixCharacters, value.Length)) +
                        "\n<color=yellow>游戏内输出已截断；完整内容见 BepInEx 日志或报告文件。</color>";
            }
            try { ConsoleMain.ConsolePrintGame(value); }
            catch { Plugin.Logger?.LogInfo("[ARL][GameConsole] " + value); }
        }
    }
}
