using System;
using System.Globalization;
using System.IO;
using BepInEx;
using BepInEx.Logging;
using UnityEngine;

namespace MakemitAGA.ActiveRagdollLab.Configuration
{
    internal sealed class ActiveRagdollLabProfile
    {
        public const string FileName = "MakemitAGA.ActiveRagdollLab.Profile.txt";

        public string TargetName = "MitaPerson Mita";
        public string PelvisBonePath = "Armature/Hips";
        public string SpineBonePath = "Armature/Hips/Spine";
        public string ChestBonePath = "Armature/Hips/Spine/Chest";

        public float PelvisMass = 8f;
        public float ChestMass = 12f;
        public Vector3 PelvisSizeScale = new Vector3(0.70f, 0.34f, 0.52f);
        public Vector3 ChestSizeScale = new Vector3(0.86f, 0.68f, 0.56f);
        public float MinBoxDimension = 0.10f;
        public float MaxBoxDimension = 0.55f;

        // v0.2.0：下面这一组 torso 参数属于 v0.1.16 已通过冻结验收的 Two-Body Foundation。
        // 新增单腿链不得以“腿部追踪不好”为理由回头调整这些参数；若出现 torso 回归，先按冻结验收独立定位。
        // drive=True 时 Pelvis 仍只在 FixedUpdate 通过 MovePosition/MoveRotation 进入 PhysX；v0.1.8 已证明
        // 不能再在 FixedUpdate 对 render-updated source pose 求导。目标线/角速度改回 LateUpdate 真正新样本求导、
        // 低通后 sample-and-hold 到 FixedUpdate；body relative angular velocity 继续用 settled physics pose delta。
        // v0.1.10 已验证有界 Pose Bridge；v0.1.11 不调它的参数，只让 Parent FF 默认改用 Pose Bridge 实际 command 运输速度。
        // v0.2.0 清理：v0.1.4 之后世界位置 PD 已退出主线；对应三个旧配置键不再进入运行时模型。
        // MaxLinearVelocity 仍被 Render->Physics Pose Bridge 与安全速度钳位使用，因此继续保留。
        public float MaxLinearVelocity = 6f;
        public float AngularSpring = 55f;
        public float AngularDamper = 12f;
        public float MaxAngularAcceleration = 40f;
        public float AngularDrag = 3f;
        public float MaxAngularVelocity = 18f;
        public float DriveDisableDistance = 0.80f;
        public float TargetVelocityBlend = 0.50f;
        public float TraceIntervalSeconds = 0.50f;
        // v0.2.0 log-volume controls. DIAGNOSTIC ONLY; never enter physics control.
        // Defaults are compact because v0.1.12-v0.1.14 already established the source-turn mechanism.
        public bool TraceVerboseSnapshots = false;
        public bool SourceTurnVerboseContextLogging = false;

        // v0.1.11 继续沿用运动阶段分类阈值。只用于诊断/TRACE 统计，不参与物理控制。
        public float MotionIdleSpeedThreshold = 0.15f;
        public float MotionSteadyMinSpeed = 0.50f;
        public float MotionLinearAccelerationThreshold = 3.00f;
        public float MotionTurnAngularVelocityThreshold = 1.20f;
        public float MotionTurnAngularAccelerationThreshold = 12.0f;
        public float MotionTransitionHoldSeconds = 0.30f;

        // v0.1.12 source-turn attribution thresholds. DIAGNOSTIC ONLY: these values never enter physics control.
        // The detector watches consecutive real LateUpdate samples before TargetVelocityBlend filtering.
        public float SourceTurnEventRotationDeltaDegrees = 20.0f;
        public float SourceTurnEventAngularSpeedThreshold = 4.0f;
        public float SourceTurnEventAngularAccelerationThreshold = 30.0f;
        public float SourceTurnContextPreSeconds = 0.50f;
        public float SourceTurnContextPostSeconds = 0.75f;

        // v0.1.10/v0.1.11 Render -> Physics Pose Bridge。
        // 这些参数只决定 kinematic Pelvis 在 FixedUpdate 中如何连续追踪最新 Render pose，
        // 不改变 PD / Parent FF / CharacterJoint 参数。
        public float PoseBridgeMaxExtrapolationSeconds = 0.10f;
        public float PoseBridgePositionCorrectionGain = 6.0f;
        public float PoseBridgeMaxPositionCorrectionSpeed = 0.75f;
        public float PoseBridgeRotationCorrectionGain = 6.0f;
        public float PoseBridgeMaxRotationCorrectionAngularSpeed = 3.0f;

        // v0.1.6 父体运动前馈：只匹配由 Pelvis 平移/转动带来的“刚体运输速度”，不使用世界位置误差。
        // Parent FF ownership is frozen ON in the current baseline; the historical runtime toggle has been removed from the current console surface.
        public bool ParentMotionFeedforward = true;
        public float ParentMotionFeedforwardGain = 12f;
        public float MaxParentMotionFeedforwardAcceleration = 20f;

        // true 时忽略下面的人体限位数值，统一使用约 ±170°/170°/170° 的诊断宽限位。
        // 这样旧 v0.1.5/v0.1.4 配置文件无需删除，也不会把隔离实验意外切回窄限位。
        public bool WideJointLimitIsolation = true;
        public float WideJointLimitDegrees = 170f;

        public float ChestLowTwistLimitDegrees = -35f;
        public float ChestHighTwistLimitDegrees = 35f;
        public float ChestSwing1LimitDegrees = 45f;
        public float ChestSwing2LimitDegrees = 35f;
        public float JointAnchorSafetyDistance = 0.15f;

        public bool DefaultColliders = false;
        public bool DefaultGravity = false;
        public float PreviewAlpha = 0.28f;

        // v0.2.0 Single-Leg Chain。Torso 参数已经冻结；以下只影响新加入的腿部模块。
        public bool SingleLegEnabled = true;
        // v0.3.0: when true, replicate the frozen Single-Leg production chain to the opposite side.
        // Existing singleLegSide remains the primary/legacy side; the opposite side is resolved automatically.
        public bool BilateralLegEnabled = true;
        public string SingleLegSide = "Left";
        // 可选显式路径。三个都为空时自动解析；三个都填写时优先使用显式路径。
        // AUTO 顺序：Humanoid -> MiSide canonical (Hips/Left leg/Left knee/Left ankle) -> Hips 子树结构 fallback。
        // 自动解析严格避开 IKLifeCharacter/RotateLegs、Collider*、Twist*、*Target 等辅助节点。
        public string SingleLegUpperBonePath = string.Empty;
        public string SingleLegLowerBonePath = string.Empty;
        public string SingleLegFootBonePath = string.Empty;
        public float UpperLegMass = 7.0f;
        public float LowerLegMass = 4.0f;
        public float LegSegmentThickness = 0.10f;
        public float LegHipAngularSpring = 55f;
        public float LegHipAngularDamper = 12f;
        public float LegHipMaxAngularAcceleration = 40f;
        // v0.2.29 phase-aware Hip recovery authority validation. Healthy motion keeps 40; only Source Turn
        // and a bounded Hip-recovery window temporarily raise the MaxA ceiling. Kp/Kd remain unchanged.
        public float LegHipSourceTurnMaxAngularAcceleration = 80f;
        public float LegHipRecoveryMaxAngularAcceleration = 80f;
        public float LegHipRecoveryExitErrorDegrees = 10f;
        public float LegHipRecoveryStableHoldSeconds = 0.15f;
        public float LegHipRecoveryMaxSeconds = 2.0f;
        // v0.2.36 continuous physical tracking health. Hysteresis re-arms PhysicalRecoveryPending after an
        // earlier recovery completed. Health re-entry does NOT raise MaxA; it suppresses A-FF/normal diagnostics.
        public float LegHipTrackingHealthEnterErrorDegrees = 15f;
        public float LegHipTrackingHealthEnterHoldSeconds = 0.10f;
        // v0.2.53: 30deg is health re-entry only. v0.2.52 temporarily reused it as a recovery governor cap; rejected.
        public float LegHipTrackingHealthImmediateErrorDegrees = 30f;
        // v0.2.30: Hip PD normally uses the real Pelvis frame exactly. Only Source Turn and the short frame catch-up
        // window use a bounded virtual parent frame so a kinematic parent discontinuity is not injected as an instantaneous Hip reference.
        public bool LegHipControlFrameInertialization = true;
        public float LegHipControlFrameSourceMaxAngularSpeed = 6f;
        public float LegHipControlFrameSourceMaxAngularAcceleration = 60f;
        public float LegHipControlFrameRecoveryMaxAngularSpeed = 8f;
        public float LegHipControlFrameRecoveryMaxAngularAcceleration = 80f;
        // v0.2.31: hard bound on real-vs-virtual parent orientation separation. The excess angle is
        // rebased without injecting a matching angular-velocity spike, preserving the v0.2.30 smoothing intent.
        public float LegHipControlFrameMaxLagDegrees = 25f;
        public float LegHipControlFrameRecoveryExitAngleDegrees = 1.5f;
        public float LegHipControlFrameRecoveryExitAngularSpeed = 0.5f;
        public float LegHipControlFrameRecoveryStableHoldSeconds = 0.10f;
        public float LegHipControlFrameRecoveryMaxSeconds = 1.5f;
        public float LegKneeAngularSpring = 45f;
        public float LegKneeAngularDamper = 9f;
        public float LegKneeMaxAngularAcceleration = 40f;
        // v0.2.25 production migration: the physical Knee CharacterJoint stays wide;
        // ARL software PD shapes only the two off-flexion DOFs. Defaults are copied from the v0.2.24 PASS.
        public float LegKneeSoftOffAxisAngularSpring = 30f;
        public float LegKneeSoftOffAxisAngularDamper = 8f;
        public float LegKneeSoftOffAxisMaxAngularAcceleration = 20f;
        // v0.2.27 phase-aware authority validation: healthy motion keeps baseline 20; only Source Turn and
        // bounded leg-recovery receive temporary higher authority. These are clamp ceilings, not constant output.
        public float LegKneeSoftOffAxisSourceTurnMaxAngularAcceleration = 40f;
        public float LegKneeSoftOffAxisRecoveryMaxAngularAcceleration = 40f;
        public float LegKneeSoftOffAxisRecoveryExitErrorDegrees = 5f;
        public float LegKneeSoftOffAxisRecoveryStableHoldSeconds = 0.15f;
        public float LegKneeSoftOffAxisRecoveryMaxSeconds = 2.0f;
        public float LegKneeSoftOffAxisTrackingHealthEnterErrorDegrees = 10f;
        public float LegKneeSoftOffAxisTrackingHealthEnterHoldSeconds = 0.10f;
        public float LegKneeSoftOffAxisTrackingHealthImmediateErrorDegrees = 25f;
        public float LegDriveDisableDistance = 0.65f;

        // v0.2.17 cleanup: v0.2.3 Parent FF、v0.2.6 Relative Pose Bridge、v0.2.7 Relative Angular Velocity Bridge
        // 已完成否定归因并从活动 Single-Leg 配置/代码删除。历史实现保留在对应版本 ZIP，不再污染正式 profile。

        // v0.2.38 production freeze：v0.2.37 real-inertia A/B confirmed that healthy-normal A-FF removes
        // the visible phase-lag swing while OFF restores it. Keep ON / gain=1 / bound=20 in production.
        // Source Turn / torso recovery / physical leg recovery / active Hip control-frame / stale samples remain suppressed.
        public bool LegAngularAccelerationFeedforward = true;
        public float LegAngularAccelerationFeedforwardGain = 1.0f;
        public float LegAngularAccelerationFeedforwardMaxAcceleration = 20.0f;
        public float LegAngularAccelerationFeedforwardMaxSourceSampleAgeSeconds = 0.10f;

        public string SourcePath;
        public bool LoadedFromFile;
        public string LoadMessage;

        public static string ConfigPath => Path.Combine(Paths.ConfigPath, FileName);

        public static string EnsureTemplate(ManualLogSource logger)
        {
            string path = ConfigPath;
            try
            {
                if (File.Exists(path))
                    return "ARL 配置已存在：" + path;

                Directory.CreateDirectory(Path.GetDirectoryName(path));
                File.WriteAllText(path, GetTemplateText());
                logger?.LogInfo("[ARL][PROFILE] template-created | path=" + path);
                return "已创建 ARL 配置模板：" + path;
            }
            catch (Exception e)
            {
                logger?.LogWarning("[ARL][PROFILE] template-create-failed | " + e);
                return "创建 ARL 配置失败：" + e.GetType().Name + " / " + e.Message;
            }
        }

        public static ActiveRagdollLabProfile Load(ManualLogSource logger)
        {
            ActiveRagdollLabProfile profile = new ActiveRagdollLabProfile
            {
                SourcePath = ConfigPath,
                LoadedFromFile = false,
                LoadMessage = "using-built-in-safe-defaults"
            };

            EnsureTemplate(logger);

            try
            {
                if (!File.Exists(ConfigPath))
                    return profile;

                string[] lines = File.ReadAllLines(ConfigPath);
                for (int i = 0; i < lines.Length; i++)
                {
                    string raw = lines[i] ?? string.Empty;
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#", StringComparison.Ordinal))
                        continue;

                    int equals = line.IndexOf('=');
                    if (equals <= 0)
                        continue;

                    string key = line.Substring(0, equals).Trim();
                    string value = line.Substring(equals + 1).Trim();
                    Apply(profile, key, value);
                }

                ValidateAndClamp(profile);
                profile.LoadedFromFile = true;
                profile.LoadMessage = "loaded";
                logger?.LogInfo(
                    "[ARL][PROFILE] reloaded | path=" + ConfigPath +
                    " | target=" + profile.TargetName +
                    " | pelvis=" + profile.PelvisBonePath +
                    " | spine=" + profile.SpineBonePath +
                    " | chest=" + profile.ChestBonePath +
                    " | driveBackend=RELATIVE_JOINT_PD_PLUS_PARENT_FEEDFORWARD" +
                    " | diagnostics=SOURCE_AWARE_FREEZE_VALIDATION+SOURCE_TURN_DISCONTINUITY_ATTRIBUTION" +
                    " | parentFeedforward=" + profile.ParentMotionFeedforward +
                    " | jointLimitMode=" + (profile.WideJointLimitIsolation ? "WIDE_ISOLATION" : "ANATOMICAL") +
                    " | singleLeg=" + profile.SingleLegEnabled + "/" + profile.SingleLegSide +
                " | bilateralLeg=" + profile.BilateralLegEnabled);
            }
            catch (Exception e)
            {
                profile.LoadMessage = "load-failed:" + e.GetType().Name + "/" + e.Message;
                logger?.LogWarning("[ARL][PROFILE] load-failed | " + e);
            }

            return profile;
        }

        public string GetStatusText()
        {
            return
                "ARL profile | loaded=" + LoadedFromFile +
                " | source=" + SourcePath +
                " | target=" + TargetName +
                " | pelvis=" + PelvisBonePath +
                " | spine=" + SpineBonePath +
                " | chest=" + ChestBonePath +
                " | masses=" + F(PelvisMass) + "/" + F(ChestMass) +
                " | pelvisScale=" + V(PelvisSizeScale) +
                " | chestScale=" + V(ChestSizeScale) +
                " | boxClamp=" + F(MinBoxDimension) + ".." + F(MaxBoxDimension) +
                " | driveBackend=RELATIVE_JOINT_PD_PLUS_PARENT_FEEDFORWARD" +
                " | angularVelocityMode=RENDER_SAMPLED_TARGET_RELATIVE_PLUS_FIXED_SETTLED_BODY_DELTA" +
                " | drivePhaseSync=FIXEDUPDATE_PARENT_PLUS_RENDER_SAMPLE_HOLD_VELOCITY_AND_POSE_BRIDGE_CONSISTENT_PARENT_FF" +
                " | poseBridgeMode=RENDER_POSE_VELOCITY_PREDICT_CORRECT" +
                " | parentFFReference=POSE_BRIDGE_COMMAND(frozen)" +
                " | parentFeedforward=" + ParentMotionFeedforward +
                " | parentFF=" + F(ParentMotionFeedforwardGain) + "/" + F(MaxParentMotionFeedforwardAcceleration) +
                " | poseBridge=" + F(PoseBridgeMaxExtrapolationSeconds) + "/" + F(PoseBridgePositionCorrectionGain) + "/" + F(PoseBridgeMaxPositionCorrectionSpeed) + "/" + F(PoseBridgeRotationCorrectionGain) + "/" + F(PoseBridgeMaxRotationCorrectionAngularSpeed) +
                " | jointLimitMode=" + (WideJointLimitIsolation ? "WIDE_ISOLATION" : "ANATOMICAL") +
                " | wideJointLimit=" + F(WideJointLimitDegrees) +
                " | angularPD=" + F(AngularSpring) + "/" + F(AngularDamper) + "/" + F(MaxAngularAcceleration) +
                " | maxLinearVelocity=" + F(MaxLinearVelocity) +
                " | maxAngularVelocity=" + F(MaxAngularVelocity) +
                " | driveDisableDistance=" + F(DriveDisableDistance) +
                " | targetVelocityBlend=" + F(TargetVelocityBlend) +
                " | traceInterval=" + F(TraceIntervalSeconds) +
                " | traceLogMode=" + (TraceVerboseSnapshots ? "VERBOSE" : "COMPACT") +
                " | sourceTurnContextLog=" + (SourceTurnVerboseContextLogging ? "VERBOSE" : "SUMMARY_ONLY") +
                " | motionThresholds=" + F(MotionIdleSpeedThreshold) + "/" + F(MotionSteadyMinSpeed) + "/" + F(MotionLinearAccelerationThreshold) + "/" + F(MotionTurnAngularVelocityThreshold) + "/" + F(MotionTurnAngularAccelerationThreshold) + "/hold=" + F(MotionTransitionHoldSeconds) +
                " | sourceTurnEventThresholds=rotDelta" + F(SourceTurnEventRotationDeltaDegrees) + "/rawW" + F(SourceTurnEventAngularSpeedThreshold) + "/rawA" + F(SourceTurnEventAngularAccelerationThreshold) + "/context=" + F(SourceTurnContextPreSeconds) + "+" + F(SourceTurnContextPostSeconds) +
                " | freezeValidation=TWO_BODY_FREEZE_POLICY_V0_1_16_DRIVE_FAIL_FAST_AND_HOLD_ROBUSTNESS" +
                " | chestLimits=" + F(ChestLowTwistLimitDegrees) + ".." + F(ChestHighTwistLimitDegrees) +
                "/" + F(ChestSwing1LimitDegrees) + "/" + F(ChestSwing2LimitDegrees) +
                " | jointAnchorSafety=" + F(JointAnchorSafetyDistance) +
                " | gravity=" + DefaultGravity +
                " | colliders=" + DefaultColliders +
                " | singleLeg=" + SingleLegEnabled + "/" + SingleLegSide +
                " | bilateralLeg=" + BilateralLegEnabled +
                " | legExplicitPaths=" + (string.IsNullOrWhiteSpace(SingleLegUpperBonePath) ? "AUTO" : "EXPLICIT") +
                " | legMass=" + F(UpperLegMass) + "/" + F(LowerLegMass) +
                " | legHipPD=" + F(LegHipAngularSpring) + "/" + F(LegHipAngularDamper) + "/baseMaxA=" + F(LegHipMaxAngularAcceleration) + "/sourceMaxA=" + F(LegHipSourceTurnMaxAngularAcceleration) + "/recoveryMaxA=" + F(LegHipRecoveryMaxAngularAcceleration) +
                "/recoveryExit=" + F(LegHipRecoveryExitErrorDegrees) + "deg/hold=" + F(LegHipRecoveryStableHoldSeconds) + "s/max=" + F(LegHipRecoveryMaxSeconds) + "s" +
                "/healthReentry=" + F(LegHipTrackingHealthEnterErrorDegrees) + "deg/" + F(LegHipTrackingHealthEnterHoldSeconds) + "s/immediate=" + F(LegHipTrackingHealthImmediateErrorDegrees) + "deg" +
                "/governorLead(source/recovery)=" + F(LegHipRecoveryExitErrorDegrees) + "/" + F(LegHipRecoveryExitErrorDegrees) + "deg" +
                " | hipControlFrame=" + (LegHipControlFrameInertialization ? "INERTIALIZED_SOURCE_TURN" : "RAW_PARENT_FRAME") +
                "/sourceW-A=" + F(LegHipControlFrameSourceMaxAngularSpeed) + "/" + F(LegHipControlFrameSourceMaxAngularAcceleration) +
                "/recoveryW-A=" + F(LegHipControlFrameRecoveryMaxAngularSpeed) + "/" + F(LegHipControlFrameRecoveryMaxAngularAcceleration) +
                "/maxLag=" + F(LegHipControlFrameMaxLagDegrees) + "deg" +
                " | legKneePD=" + F(LegKneeAngularSpring) + "/" + F(LegKneeAngularDamper) + "/" + F(LegKneeMaxAngularAcceleration) +
                " | legKneeSoftOffAxisPD=" + F(LegKneeSoftOffAxisAngularSpring) + "/" + F(LegKneeSoftOffAxisAngularDamper) + "/baseMaxA=" + F(LegKneeSoftOffAxisMaxAngularAcceleration) +
                "/sourceMaxA=" + F(LegKneeSoftOffAxisSourceTurnMaxAngularAcceleration) + "/recoveryMaxA=" + F(LegKneeSoftOffAxisRecoveryMaxAngularAcceleration) +
                "/recoveryExit=" + F(LegKneeSoftOffAxisRecoveryExitErrorDegrees) + "deg/hold=" + F(LegKneeSoftOffAxisRecoveryStableHoldSeconds) + "s/max=" + F(LegKneeSoftOffAxisRecoveryMaxSeconds) + "s" +
                "/healthReentry=" + F(LegKneeSoftOffAxisTrackingHealthEnterErrorDegrees) + "deg/" + F(LegKneeSoftOffAxisTrackingHealthEnterHoldSeconds) + "s/immediate=" + F(LegKneeSoftOffAxisTrackingHealthImmediateErrorDegrees) + "deg" +
                " | legKneeBackend=WIDE_CHARACTER_JOINT_PLUS_SOFTWARE_OFFAXIS_PD" +
                " | legAngularAccelerationFF=" + LegAngularAccelerationFeedforward + "/" + F(LegAngularAccelerationFeedforwardGain) + "/" + F(LegAngularAccelerationFeedforwardMaxAcceleration) + "/maxAge=" + F(LegAngularAccelerationFeedforwardMaxSourceSampleAgeSeconds) + "/normal=PRODUCTION_ON" +
                " | kneeAxisCalibration=DATA_DRIVEN_PCA_EXPLICIT_APPLY" +
                " | legStage=BILATERAL_FOUNDATION_FROM_FROZEN_SINGLE_LEG_V0300" +
                " | kneeTorqueTopology=CHILD_ONLY_PRODUCTION | kneeConstraintBackend=WIDE_CHARACTER_JOINT_PLUS_SOFTWARE_OFFAXIS_PD | legMassProperties=EXPLICIT_UNIFORM_BOX_VALIDATED | legDiagnostics=SINGLE_LEG_TRANSPORT_AND_FLEXION_AXIS_ATTRIBUTION+DATA_DRIVEN_KNEE_AXIS_CALIBRATION+ANGULAR_PHASE_TIMING_ATTRIBUTION_0_TO_10+ANGULAR_ACCELERATION_ACTUATION_FF_VALIDATED_BOUND20" +
                " | detail=" + LoadMessage;
        }

        private static void Apply(ActiveRagdollLabProfile p, string key, string value)
        {
            if (key.Equals("targetName", StringComparison.OrdinalIgnoreCase)) p.TargetName = value;
            else if (key.Equals("pelvisBonePath", StringComparison.OrdinalIgnoreCase)) p.PelvisBonePath = NormalizePath(value);
            else if (key.Equals("spineBonePath", StringComparison.OrdinalIgnoreCase)) p.SpineBonePath = NormalizePath(value);
            else if (key.Equals("chestBonePath", StringComparison.OrdinalIgnoreCase)) p.ChestBonePath = NormalizePath(value);
            else if (key.Equals("pelvisMass", StringComparison.OrdinalIgnoreCase)) p.PelvisMass = ParseFloat(value, p.PelvisMass);
            else if (key.Equals("chestMass", StringComparison.OrdinalIgnoreCase)) p.ChestMass = ParseFloat(value, p.ChestMass);
            else if (key.Equals("pelvisSizeScale", StringComparison.OrdinalIgnoreCase)) p.PelvisSizeScale = ParseVector3(value, p.PelvisSizeScale);
            else if (key.Equals("chestSizeScale", StringComparison.OrdinalIgnoreCase)) p.ChestSizeScale = ParseVector3(value, p.ChestSizeScale);
            else if (key.Equals("minBoxDimension", StringComparison.OrdinalIgnoreCase)) p.MinBoxDimension = ParseFloat(value, p.MinBoxDimension);
            else if (key.Equals("maxBoxDimension", StringComparison.OrdinalIgnoreCase)) p.MaxBoxDimension = ParseFloat(value, p.MaxBoxDimension);
            else if (key.Equals("maxLinearVelocity", StringComparison.OrdinalIgnoreCase)) p.MaxLinearVelocity = ParseFloat(value, p.MaxLinearVelocity);
            else if (key.Equals("angularSpring", StringComparison.OrdinalIgnoreCase)) p.AngularSpring = ParseFloat(value, p.AngularSpring);
            else if (key.Equals("angularDamper", StringComparison.OrdinalIgnoreCase)) p.AngularDamper = ParseFloat(value, p.AngularDamper);
            else if (key.Equals("maxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.MaxAngularAcceleration = ParseFloat(value, p.MaxAngularAcceleration);
            else if (key.Equals("angularDrag", StringComparison.OrdinalIgnoreCase)) p.AngularDrag = ParseFloat(value, p.AngularDrag);
            else if (key.Equals("maxAngularVelocity", StringComparison.OrdinalIgnoreCase)) p.MaxAngularVelocity = ParseFloat(value, p.MaxAngularVelocity);
            else if (key.Equals("driveDisableDistance", StringComparison.OrdinalIgnoreCase)) p.DriveDisableDistance = ParseFloat(value, p.DriveDisableDistance);
            else if (key.Equals("targetVelocityBlend", StringComparison.OrdinalIgnoreCase)) p.TargetVelocityBlend = ParseFloat(value, p.TargetVelocityBlend);
            else if (key.Equals("traceIntervalSeconds", StringComparison.OrdinalIgnoreCase)) p.TraceIntervalSeconds = ParseFloat(value, p.TraceIntervalSeconds);
            else if (key.Equals("traceVerboseSnapshots", StringComparison.OrdinalIgnoreCase)) p.TraceVerboseSnapshots = ParseBool(value, p.TraceVerboseSnapshots);
            else if (key.Equals("sourceTurnVerboseContextLogging", StringComparison.OrdinalIgnoreCase)) p.SourceTurnVerboseContextLogging = ParseBool(value, p.SourceTurnVerboseContextLogging);
            else if (key.Equals("motionIdleSpeedThreshold", StringComparison.OrdinalIgnoreCase)) p.MotionIdleSpeedThreshold = ParseFloat(value, p.MotionIdleSpeedThreshold);
            else if (key.Equals("motionSteadyMinSpeed", StringComparison.OrdinalIgnoreCase)) p.MotionSteadyMinSpeed = ParseFloat(value, p.MotionSteadyMinSpeed);
            else if (key.Equals("motionLinearAccelerationThreshold", StringComparison.OrdinalIgnoreCase)) p.MotionLinearAccelerationThreshold = ParseFloat(value, p.MotionLinearAccelerationThreshold);
            else if (key.Equals("motionTurnAngularVelocityThreshold", StringComparison.OrdinalIgnoreCase)) p.MotionTurnAngularVelocityThreshold = ParseFloat(value, p.MotionTurnAngularVelocityThreshold);
            else if (key.Equals("motionTurnAngularAccelerationThreshold", StringComparison.OrdinalIgnoreCase)) p.MotionTurnAngularAccelerationThreshold = ParseFloat(value, p.MotionTurnAngularAccelerationThreshold);
            else if (key.Equals("motionTransitionHoldSeconds", StringComparison.OrdinalIgnoreCase)) p.MotionTransitionHoldSeconds = ParseFloat(value, p.MotionTransitionHoldSeconds);
            else if (key.Equals("sourceTurnEventRotationDeltaDegrees", StringComparison.OrdinalIgnoreCase)) p.SourceTurnEventRotationDeltaDegrees = ParseFloat(value, p.SourceTurnEventRotationDeltaDegrees);
            else if (key.Equals("sourceTurnEventAngularSpeedThreshold", StringComparison.OrdinalIgnoreCase)) p.SourceTurnEventAngularSpeedThreshold = ParseFloat(value, p.SourceTurnEventAngularSpeedThreshold);
            else if (key.Equals("sourceTurnEventAngularAccelerationThreshold", StringComparison.OrdinalIgnoreCase)) p.SourceTurnEventAngularAccelerationThreshold = ParseFloat(value, p.SourceTurnEventAngularAccelerationThreshold);
            else if (key.Equals("sourceTurnContextPreSeconds", StringComparison.OrdinalIgnoreCase)) p.SourceTurnContextPreSeconds = ParseFloat(value, p.SourceTurnContextPreSeconds);
            else if (key.Equals("sourceTurnContextPostSeconds", StringComparison.OrdinalIgnoreCase)) p.SourceTurnContextPostSeconds = ParseFloat(value, p.SourceTurnContextPostSeconds);
            else if (key.Equals("parentMotionFeedforward", StringComparison.OrdinalIgnoreCase)) p.ParentMotionFeedforward = ParseBool(value, p.ParentMotionFeedforward);
            else if (key.Equals("parentMotionFeedforwardGain", StringComparison.OrdinalIgnoreCase)) p.ParentMotionFeedforwardGain = ParseFloat(value, p.ParentMotionFeedforwardGain);
            else if (key.Equals("maxParentMotionFeedforwardAcceleration", StringComparison.OrdinalIgnoreCase)) p.MaxParentMotionFeedforwardAcceleration = ParseFloat(value, p.MaxParentMotionFeedforwardAcceleration);
            else if (key.Equals("poseBridgeMaxExtrapolationSeconds", StringComparison.OrdinalIgnoreCase)) p.PoseBridgeMaxExtrapolationSeconds = ParseFloat(value, p.PoseBridgeMaxExtrapolationSeconds);
            else if (key.Equals("poseBridgePositionCorrectionGain", StringComparison.OrdinalIgnoreCase)) p.PoseBridgePositionCorrectionGain = ParseFloat(value, p.PoseBridgePositionCorrectionGain);
            else if (key.Equals("poseBridgeMaxPositionCorrectionSpeed", StringComparison.OrdinalIgnoreCase)) p.PoseBridgeMaxPositionCorrectionSpeed = ParseFloat(value, p.PoseBridgeMaxPositionCorrectionSpeed);
            else if (key.Equals("poseBridgeRotationCorrectionGain", StringComparison.OrdinalIgnoreCase)) p.PoseBridgeRotationCorrectionGain = ParseFloat(value, p.PoseBridgeRotationCorrectionGain);
            else if (key.Equals("poseBridgeMaxRotationCorrectionAngularSpeed", StringComparison.OrdinalIgnoreCase)) p.PoseBridgeMaxRotationCorrectionAngularSpeed = ParseFloat(value, p.PoseBridgeMaxRotationCorrectionAngularSpeed);
            else if (key.Equals("wideJointLimitIsolation", StringComparison.OrdinalIgnoreCase)) p.WideJointLimitIsolation = ParseBool(value, p.WideJointLimitIsolation);
            else if (key.Equals("wideJointLimitDegrees", StringComparison.OrdinalIgnoreCase)) p.WideJointLimitDegrees = ParseFloat(value, p.WideJointLimitDegrees);
            else if (key.Equals("chestLowTwistLimitDegrees", StringComparison.OrdinalIgnoreCase)) p.ChestLowTwistLimitDegrees = ParseFloat(value, p.ChestLowTwistLimitDegrees);
            else if (key.Equals("chestHighTwistLimitDegrees", StringComparison.OrdinalIgnoreCase)) p.ChestHighTwistLimitDegrees = ParseFloat(value, p.ChestHighTwistLimitDegrees);
            else if (key.Equals("chestSwing1LimitDegrees", StringComparison.OrdinalIgnoreCase)) p.ChestSwing1LimitDegrees = ParseFloat(value, p.ChestSwing1LimitDegrees);
            else if (key.Equals("chestSwing2LimitDegrees", StringComparison.OrdinalIgnoreCase)) p.ChestSwing2LimitDegrees = ParseFloat(value, p.ChestSwing2LimitDegrees);
            else if (key.Equals("jointAnchorSafetyDistance", StringComparison.OrdinalIgnoreCase)) p.JointAnchorSafetyDistance = ParseFloat(value, p.JointAnchorSafetyDistance);
            else if (key.Equals("singleLegEnabled", StringComparison.OrdinalIgnoreCase)) p.SingleLegEnabled = ParseBool(value, p.SingleLegEnabled);
            else if (key.Equals("bilateralLegEnabled", StringComparison.OrdinalIgnoreCase)) p.BilateralLegEnabled = ParseBool(value, p.BilateralLegEnabled);
            else if (key.Equals("singleLegSide", StringComparison.OrdinalIgnoreCase)) p.SingleLegSide = value;
            else if (key.Equals("singleLegUpperBonePath", StringComparison.OrdinalIgnoreCase)) p.SingleLegUpperBonePath = NormalizePath(value);
            else if (key.Equals("singleLegLowerBonePath", StringComparison.OrdinalIgnoreCase)) p.SingleLegLowerBonePath = NormalizePath(value);
            else if (key.Equals("singleLegFootBonePath", StringComparison.OrdinalIgnoreCase)) p.SingleLegFootBonePath = NormalizePath(value);
            else if (key.Equals("upperLegMass", StringComparison.OrdinalIgnoreCase)) p.UpperLegMass = ParseFloat(value, p.UpperLegMass);
            else if (key.Equals("lowerLegMass", StringComparison.OrdinalIgnoreCase)) p.LowerLegMass = ParseFloat(value, p.LowerLegMass);
            else if (key.Equals("legSegmentThickness", StringComparison.OrdinalIgnoreCase)) p.LegSegmentThickness = ParseFloat(value, p.LegSegmentThickness);
            else if (key.Equals("legHipAngularSpring", StringComparison.OrdinalIgnoreCase)) p.LegHipAngularSpring = ParseFloat(value, p.LegHipAngularSpring);
            else if (key.Equals("legHipAngularDamper", StringComparison.OrdinalIgnoreCase)) p.LegHipAngularDamper = ParseFloat(value, p.LegHipAngularDamper);
            else if (key.Equals("legHipMaxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegHipMaxAngularAcceleration = ParseFloat(value, p.LegHipMaxAngularAcceleration);
            else if (key.Equals("legHipSourceTurnMaxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegHipSourceTurnMaxAngularAcceleration = ParseFloat(value, p.LegHipSourceTurnMaxAngularAcceleration);
            else if (key.Equals("legHipRecoveryMaxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegHipRecoveryMaxAngularAcceleration = ParseFloat(value, p.LegHipRecoveryMaxAngularAcceleration);
            else if (key.Equals("legHipRecoveryExitErrorDegrees", StringComparison.OrdinalIgnoreCase)) p.LegHipRecoveryExitErrorDegrees = ParseFloat(value, p.LegHipRecoveryExitErrorDegrees);
            else if (key.Equals("legHipRecoveryStableHoldSeconds", StringComparison.OrdinalIgnoreCase)) p.LegHipRecoveryStableHoldSeconds = ParseFloat(value, p.LegHipRecoveryStableHoldSeconds);
            else if (key.Equals("legHipRecoveryMaxSeconds", StringComparison.OrdinalIgnoreCase)) p.LegHipRecoveryMaxSeconds = ParseFloat(value, p.LegHipRecoveryMaxSeconds);
            else if (key.Equals("legHipTrackingHealthEnterErrorDegrees", StringComparison.OrdinalIgnoreCase)) p.LegHipTrackingHealthEnterErrorDegrees = ParseFloat(value, p.LegHipTrackingHealthEnterErrorDegrees);
            else if (key.Equals("legHipTrackingHealthEnterHoldSeconds", StringComparison.OrdinalIgnoreCase)) p.LegHipTrackingHealthEnterHoldSeconds = ParseFloat(value, p.LegHipTrackingHealthEnterHoldSeconds);
            else if (key.Equals("legHipTrackingHealthImmediateErrorDegrees", StringComparison.OrdinalIgnoreCase)) p.LegHipTrackingHealthImmediateErrorDegrees = ParseFloat(value, p.LegHipTrackingHealthImmediateErrorDegrees);
            else if (key.Equals("legHipControlFrameInertialization", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameInertialization = ParseBool(value, p.LegHipControlFrameInertialization);
            else if (key.Equals("legHipControlFrameSourceMaxAngularSpeed", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameSourceMaxAngularSpeed = ParseFloat(value, p.LegHipControlFrameSourceMaxAngularSpeed);
            else if (key.Equals("legHipControlFrameSourceMaxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameSourceMaxAngularAcceleration = ParseFloat(value, p.LegHipControlFrameSourceMaxAngularAcceleration);
            else if (key.Equals("legHipControlFrameRecoveryMaxAngularSpeed", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameRecoveryMaxAngularSpeed = ParseFloat(value, p.LegHipControlFrameRecoveryMaxAngularSpeed);
            else if (key.Equals("legHipControlFrameRecoveryMaxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameRecoveryMaxAngularAcceleration = ParseFloat(value, p.LegHipControlFrameRecoveryMaxAngularAcceleration);
            else if (key.Equals("legHipControlFrameMaxLagDegrees", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameMaxLagDegrees = ParseFloat(value, p.LegHipControlFrameMaxLagDegrees);
            else if (key.Equals("legHipControlFrameRecoveryExitAngleDegrees", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameRecoveryExitAngleDegrees = ParseFloat(value, p.LegHipControlFrameRecoveryExitAngleDegrees);
            else if (key.Equals("legHipControlFrameRecoveryExitAngularSpeed", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameRecoveryExitAngularSpeed = ParseFloat(value, p.LegHipControlFrameRecoveryExitAngularSpeed);
            else if (key.Equals("legHipControlFrameRecoveryStableHoldSeconds", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameRecoveryStableHoldSeconds = ParseFloat(value, p.LegHipControlFrameRecoveryStableHoldSeconds);
            else if (key.Equals("legHipControlFrameRecoveryMaxSeconds", StringComparison.OrdinalIgnoreCase)) p.LegHipControlFrameRecoveryMaxSeconds = ParseFloat(value, p.LegHipControlFrameRecoveryMaxSeconds);
            else if (key.Equals("legKneeAngularSpring", StringComparison.OrdinalIgnoreCase)) p.LegKneeAngularSpring = ParseFloat(value, p.LegKneeAngularSpring);
            else if (key.Equals("legKneeAngularDamper", StringComparison.OrdinalIgnoreCase)) p.LegKneeAngularDamper = ParseFloat(value, p.LegKneeAngularDamper);
            else if (key.Equals("legKneeMaxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegKneeMaxAngularAcceleration = ParseFloat(value, p.LegKneeMaxAngularAcceleration);
            else if (key.Equals("legKneeSoftOffAxisAngularSpring", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisAngularSpring = ParseFloat(value, p.LegKneeSoftOffAxisAngularSpring);
            else if (key.Equals("legKneeSoftOffAxisAngularDamper", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisAngularDamper = ParseFloat(value, p.LegKneeSoftOffAxisAngularDamper);
            else if (key.Equals("legKneeSoftOffAxisMaxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisMaxAngularAcceleration = ParseFloat(value, p.LegKneeSoftOffAxisMaxAngularAcceleration);
            else if (key.Equals("legKneeSoftOffAxisSourceTurnMaxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisSourceTurnMaxAngularAcceleration = ParseFloat(value, p.LegKneeSoftOffAxisSourceTurnMaxAngularAcceleration);
            else if (key.Equals("legKneeSoftOffAxisRecoveryMaxAngularAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisRecoveryMaxAngularAcceleration = ParseFloat(value, p.LegKneeSoftOffAxisRecoveryMaxAngularAcceleration);
            else if (key.Equals("legKneeSoftOffAxisRecoveryExitErrorDegrees", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisRecoveryExitErrorDegrees = ParseFloat(value, p.LegKneeSoftOffAxisRecoveryExitErrorDegrees);
            else if (key.Equals("legKneeSoftOffAxisRecoveryStableHoldSeconds", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisRecoveryStableHoldSeconds = ParseFloat(value, p.LegKneeSoftOffAxisRecoveryStableHoldSeconds);
            else if (key.Equals("legKneeSoftOffAxisRecoveryMaxSeconds", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisRecoveryMaxSeconds = ParseFloat(value, p.LegKneeSoftOffAxisRecoveryMaxSeconds);
            else if (key.Equals("legKneeSoftOffAxisTrackingHealthEnterErrorDegrees", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisTrackingHealthEnterErrorDegrees = ParseFloat(value, p.LegKneeSoftOffAxisTrackingHealthEnterErrorDegrees);
            else if (key.Equals("legKneeSoftOffAxisTrackingHealthEnterHoldSeconds", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisTrackingHealthEnterHoldSeconds = ParseFloat(value, p.LegKneeSoftOffAxisTrackingHealthEnterHoldSeconds);
            else if (key.Equals("legKneeSoftOffAxisTrackingHealthImmediateErrorDegrees", StringComparison.OrdinalIgnoreCase)) p.LegKneeSoftOffAxisTrackingHealthImmediateErrorDegrees = ParseFloat(value, p.LegKneeSoftOffAxisTrackingHealthImmediateErrorDegrees);
            else if (key.Equals("legDriveDisableDistance", StringComparison.OrdinalIgnoreCase)) p.LegDriveDisableDistance = ParseFloat(value, p.LegDriveDisableDistance);
            else if (key.Equals("legAngularAccelerationFeedforward", StringComparison.OrdinalIgnoreCase)) p.LegAngularAccelerationFeedforward = ParseBool(value, p.LegAngularAccelerationFeedforward);
            else if (key.Equals("legAngularAccelerationFeedforwardGain", StringComparison.OrdinalIgnoreCase)) p.LegAngularAccelerationFeedforwardGain = ParseFloat(value, p.LegAngularAccelerationFeedforwardGain);
            else if (key.Equals("legAngularAccelerationFeedforwardMaxAcceleration", StringComparison.OrdinalIgnoreCase)) p.LegAngularAccelerationFeedforwardMaxAcceleration = ParseFloat(value, p.LegAngularAccelerationFeedforwardMaxAcceleration);
            else if (key.Equals("legAngularAccelerationFeedforwardMaxSourceSampleAgeSeconds", StringComparison.OrdinalIgnoreCase)) p.LegAngularAccelerationFeedforwardMaxSourceSampleAgeSeconds = ParseFloat(value, p.LegAngularAccelerationFeedforwardMaxSourceSampleAgeSeconds);
            else if (key.Equals("defaultColliders", StringComparison.OrdinalIgnoreCase)) p.DefaultColliders = ParseBool(value, p.DefaultColliders);
            else if (key.Equals("defaultGravity", StringComparison.OrdinalIgnoreCase)) p.DefaultGravity = ParseBool(value, p.DefaultGravity);
            else if (key.Equals("previewAlpha", StringComparison.OrdinalIgnoreCase)) p.PreviewAlpha = ParseFloat(value, p.PreviewAlpha);
            // 旧配置文件中的未知/已退役键会被安全忽略；sourceTurn* 等仍在使用的诊断键继续兼容。
            // Two-Body freeze gate 仍固定为 v0.1.16 已验证策略；wideJointLimitIsolation 缺失时默认 true。
        }

        private static void ValidateAndClamp(ActiveRagdollLabProfile p)
        {
            p.TargetName = string.IsNullOrWhiteSpace(p.TargetName) ? "MitaPerson Mita" : p.TargetName.Trim();
            p.PelvisBonePath = RequirePath(p.PelvisBonePath, "Armature/Hips");
            p.SpineBonePath = RequirePath(p.SpineBonePath, "Armature/Hips/Spine");
            p.ChestBonePath = RequirePath(p.ChestBonePath, "Armature/Hips/Spine/Chest");

            p.PelvisMass = ClampFinite(p.PelvisMass, 0.5f, 40f, 8f);
            p.ChestMass = ClampFinite(p.ChestMass, 0.5f, 40f, 12f);
            p.PelvisSizeScale = ClampVector(p.PelvisSizeScale, 0.10f, 2.0f, new Vector3(0.70f, 0.34f, 0.52f));
            p.ChestSizeScale = ClampVector(p.ChestSizeScale, 0.10f, 2.0f, new Vector3(0.86f, 0.68f, 0.56f));
            p.MinBoxDimension = ClampFinite(p.MinBoxDimension, 0.03f, 0.40f, 0.10f);
            p.MaxBoxDimension = ClampFinite(p.MaxBoxDimension, p.MinBoxDimension + 0.02f, 1.5f, 0.55f);

            p.MaxLinearVelocity = ClampFinite(p.MaxLinearVelocity, 0.5f, 30f, 6f);
            p.AngularSpring = ClampFinite(p.AngularSpring, 0f, 1000f, 55f);
            p.AngularDamper = ClampFinite(p.AngularDamper, 0f, 200f, 12f);
            p.MaxAngularAcceleration = ClampFinite(p.MaxAngularAcceleration, 1f, 300f, 40f);
            p.AngularDrag = ClampFinite(p.AngularDrag, 0f, 20f, 3f);
            p.MaxAngularVelocity = ClampFinite(p.MaxAngularVelocity, 1f, 100f, 18f);
            p.DriveDisableDistance = ClampFinite(p.DriveDisableDistance, 0.15f, 3f, 0.80f);
            p.TargetVelocityBlend = ClampFinite(p.TargetVelocityBlend, 0.05f, 1.0f, 0.50f);
            p.TraceIntervalSeconds = ClampFinite(p.TraceIntervalSeconds, 0.10f, 5.0f, 0.50f);
            p.MotionIdleSpeedThreshold = ClampFinite(p.MotionIdleSpeedThreshold, 0.01f, 1.0f, 0.15f);
            p.MotionSteadyMinSpeed = ClampFinite(p.MotionSteadyMinSpeed, p.MotionIdleSpeedThreshold + 0.05f, 3.0f, 0.50f);
            p.MotionLinearAccelerationThreshold = ClampFinite(p.MotionLinearAccelerationThreshold, 0.1f, 20f, 3.00f);
            p.MotionTurnAngularVelocityThreshold = ClampFinite(p.MotionTurnAngularVelocityThreshold, 0.05f, 10f, 1.20f);
            p.MotionTurnAngularAccelerationThreshold = ClampFinite(p.MotionTurnAngularAccelerationThreshold, 0.1f, 50f, 12.0f);
            p.MotionTransitionHoldSeconds = ClampFinite(p.MotionTransitionHoldSeconds, 0f, 2f, 0.30f);
            p.SourceTurnEventRotationDeltaDegrees = ClampFinite(p.SourceTurnEventRotationDeltaDegrees, 2f, 120f, 20.0f);
            p.SourceTurnEventAngularSpeedThreshold = ClampFinite(p.SourceTurnEventAngularSpeedThreshold, 0.5f, 30f, 4.0f);
            p.SourceTurnEventAngularAccelerationThreshold = ClampFinite(p.SourceTurnEventAngularAccelerationThreshold, 2f, 500f, 30.0f);
            p.SourceTurnContextPreSeconds = ClampFinite(p.SourceTurnContextPreSeconds, 0.10f, 2.0f, 0.50f);
            p.SourceTurnContextPostSeconds = ClampFinite(p.SourceTurnContextPostSeconds, 0.10f, 3.0f, 0.75f);
            p.ParentMotionFeedforwardGain = ClampFinite(p.ParentMotionFeedforwardGain, 0f, 80f, 12f);
            p.MaxParentMotionFeedforwardAcceleration = ClampFinite(p.MaxParentMotionFeedforwardAcceleration, 1f, 100f, 20f);
            p.PoseBridgeMaxExtrapolationSeconds = ClampFinite(p.PoseBridgeMaxExtrapolationSeconds, 0.01f, 0.30f, 0.10f);
            p.PoseBridgePositionCorrectionGain = ClampFinite(p.PoseBridgePositionCorrectionGain, 0f, 30f, 6.0f);
            p.PoseBridgeMaxPositionCorrectionSpeed = ClampFinite(p.PoseBridgeMaxPositionCorrectionSpeed, 0.05f, 5f, 0.75f);
            p.PoseBridgeRotationCorrectionGain = ClampFinite(p.PoseBridgeRotationCorrectionGain, 0f, 30f, 6.0f);
            p.PoseBridgeMaxRotationCorrectionAngularSpeed = ClampFinite(p.PoseBridgeMaxRotationCorrectionAngularSpeed, 0.1f, 20f, 3.0f);
            p.WideJointLimitDegrees = ClampFinite(p.WideJointLimitDegrees, 120f, 175f, 170f);
            p.ChestLowTwistLimitDegrees = ClampFinite(p.ChestLowTwistLimitDegrees, -175f, -1f, -35f);
            p.ChestHighTwistLimitDegrees = ClampFinite(p.ChestHighTwistLimitDegrees, 1f, 175f, 35f);
            p.ChestSwing1LimitDegrees = ClampFinite(p.ChestSwing1LimitDegrees, 1f, 175f, 45f);
            p.ChestSwing2LimitDegrees = ClampFinite(p.ChestSwing2LimitDegrees, 1f, 175f, 35f);
            p.JointAnchorSafetyDistance = ClampFinite(p.JointAnchorSafetyDistance, 0.03f, 0.50f, 0.15f);
            p.SingleLegSide = NormalizeLegSide(p.SingleLegSide);
            p.UpperLegMass = ClampFinite(p.UpperLegMass, 0.5f, 30f, 7f);
            p.LowerLegMass = ClampFinite(p.LowerLegMass, 0.25f, 20f, 4f);
            p.LegSegmentThickness = ClampFinite(p.LegSegmentThickness, 0.04f, 0.30f, 0.10f);
            p.LegHipAngularSpring = ClampFinite(p.LegHipAngularSpring, 0f, 500f, 55f);
            p.LegHipAngularDamper = ClampFinite(p.LegHipAngularDamper, 0f, 100f, 12f);
            p.LegHipMaxAngularAcceleration = ClampFinite(p.LegHipMaxAngularAcceleration, 1f, 200f, 40f);
            p.LegHipSourceTurnMaxAngularAcceleration = ClampFinite(p.LegHipSourceTurnMaxAngularAcceleration, p.LegHipMaxAngularAcceleration, 200f, 80f);
            p.LegHipRecoveryMaxAngularAcceleration = ClampFinite(p.LegHipRecoveryMaxAngularAcceleration, p.LegHipMaxAngularAcceleration, 200f, 80f);
            p.LegHipRecoveryExitErrorDegrees = ClampFinite(p.LegHipRecoveryExitErrorDegrees, 1f, 45f, 10f);
            p.LegHipRecoveryStableHoldSeconds = ClampFinite(p.LegHipRecoveryStableHoldSeconds, 0.02f, 1.0f, 0.15f);
            p.LegHipRecoveryMaxSeconds = ClampFinite(p.LegHipRecoveryMaxSeconds, 0.25f, 5.0f, 2.0f);
            p.LegHipTrackingHealthEnterErrorDegrees = ClampFinite(p.LegHipTrackingHealthEnterErrorDegrees, p.LegHipRecoveryExitErrorDegrees + 1f, 90f, 15f);
            p.LegHipTrackingHealthEnterHoldSeconds = ClampFinite(p.LegHipTrackingHealthEnterHoldSeconds, 0.02f, 0.50f, 0.10f);
            p.LegHipTrackingHealthImmediateErrorDegrees = ClampFinite(p.LegHipTrackingHealthImmediateErrorDegrees, p.LegHipTrackingHealthEnterErrorDegrees, 120f, 30f);
            p.LegHipControlFrameSourceMaxAngularSpeed = ClampFinite(p.LegHipControlFrameSourceMaxAngularSpeed, 0.5f, 18f, 6f);
            p.LegHipControlFrameSourceMaxAngularAcceleration = ClampFinite(p.LegHipControlFrameSourceMaxAngularAcceleration, 5f, 300f, 60f);
            p.LegHipControlFrameRecoveryMaxAngularSpeed = ClampFinite(p.LegHipControlFrameRecoveryMaxAngularSpeed, 0.5f, 18f, 8f);
            p.LegHipControlFrameRecoveryMaxAngularAcceleration = ClampFinite(p.LegHipControlFrameRecoveryMaxAngularAcceleration, 5f, 300f, 80f);
            p.LegHipControlFrameMaxLagDegrees = ClampFinite(p.LegHipControlFrameMaxLagDegrees, 5f, 179f, 25f);
            p.LegHipControlFrameRecoveryExitAngleDegrees = ClampFinite(p.LegHipControlFrameRecoveryExitAngleDegrees, 0.25f, 10f, 1.5f);
            p.LegHipControlFrameRecoveryExitAngularSpeed = ClampFinite(p.LegHipControlFrameRecoveryExitAngularSpeed, 0.05f, 3f, 0.5f);
            p.LegHipControlFrameRecoveryStableHoldSeconds = ClampFinite(p.LegHipControlFrameRecoveryStableHoldSeconds, 0.05f, 0.5f, 0.10f);
            p.LegHipControlFrameRecoveryMaxSeconds = ClampFinite(p.LegHipControlFrameRecoveryMaxSeconds, 0.25f, 3f, 1.5f);
            p.LegKneeAngularSpring = ClampFinite(p.LegKneeAngularSpring, 0f, 500f, 45f);
            p.LegKneeAngularDamper = ClampFinite(p.LegKneeAngularDamper, 0f, 100f, 9f);
            p.LegKneeMaxAngularAcceleration = ClampFinite(p.LegKneeMaxAngularAcceleration, 1f, 200f, 40f);
            p.LegKneeSoftOffAxisAngularSpring = ClampFinite(p.LegKneeSoftOffAxisAngularSpring, 0f, 500f, 30f);
            p.LegKneeSoftOffAxisAngularDamper = ClampFinite(p.LegKneeSoftOffAxisAngularDamper, 0f, 100f, 8f);
            p.LegKneeSoftOffAxisMaxAngularAcceleration = ClampFinite(p.LegKneeSoftOffAxisMaxAngularAcceleration, 1f, 100f, 20f);
            p.LegKneeSoftOffAxisSourceTurnMaxAngularAcceleration = ClampFinite(p.LegKneeSoftOffAxisSourceTurnMaxAngularAcceleration, p.LegKneeSoftOffAxisMaxAngularAcceleration, 120f, 40f);
            p.LegKneeSoftOffAxisRecoveryMaxAngularAcceleration = ClampFinite(p.LegKneeSoftOffAxisRecoveryMaxAngularAcceleration, p.LegKneeSoftOffAxisMaxAngularAcceleration, 120f, 40f);
            p.LegKneeSoftOffAxisRecoveryExitErrorDegrees = ClampFinite(p.LegKneeSoftOffAxisRecoveryExitErrorDegrees, 0.5f, 30f, 5f);
            p.LegKneeSoftOffAxisRecoveryStableHoldSeconds = ClampFinite(p.LegKneeSoftOffAxisRecoveryStableHoldSeconds, 0.02f, 1.0f, 0.15f);
            p.LegKneeSoftOffAxisRecoveryMaxSeconds = ClampFinite(p.LegKneeSoftOffAxisRecoveryMaxSeconds, 0.25f, 5.0f, 2.0f);
            p.LegKneeSoftOffAxisTrackingHealthEnterErrorDegrees = ClampFinite(p.LegKneeSoftOffAxisTrackingHealthEnterErrorDegrees, p.LegKneeSoftOffAxisRecoveryExitErrorDegrees + 0.5f, 60f, 10f);
            p.LegKneeSoftOffAxisTrackingHealthEnterHoldSeconds = ClampFinite(p.LegKneeSoftOffAxisTrackingHealthEnterHoldSeconds, 0.02f, 0.50f, 0.10f);
            p.LegKneeSoftOffAxisTrackingHealthImmediateErrorDegrees = ClampFinite(p.LegKneeSoftOffAxisTrackingHealthImmediateErrorDegrees, p.LegKneeSoftOffAxisTrackingHealthEnterErrorDegrees, 90f, 25f);
            p.LegDriveDisableDistance = ClampFinite(p.LegDriveDisableDistance, 0.15f, 2f, 0.65f);
            p.LegAngularAccelerationFeedforwardGain = ClampFinite(p.LegAngularAccelerationFeedforwardGain, 0f, 4f, 1f);
            p.LegAngularAccelerationFeedforwardMaxAcceleration = ClampFinite(p.LegAngularAccelerationFeedforwardMaxAcceleration, 0f, 40f, 20f);
            p.LegAngularAccelerationFeedforwardMaxSourceSampleAgeSeconds = ClampFinite(p.LegAngularAccelerationFeedforwardMaxSourceSampleAgeSeconds, 0.01f, 0.25f, 0.10f);
            p.PreviewAlpha = ClampFinite(p.PreviewAlpha, 0.05f, 0.80f, 0.28f);
        }

        private static string NormalizeLegSide(string value)
        {
            string side = (value ?? string.Empty).Trim();
            return side.Equals("right", StringComparison.OrdinalIgnoreCase) || side.Equals("r", StringComparison.OrdinalIgnoreCase)
                ? "Right"
                : "Left";
        }

        private static string NormalizePath(string value)
        {
            return (value ?? string.Empty).Trim().Trim('/').Replace('\\', '/');
        }

        private static string RequirePath(string value, string fallback)
        {
            string normalized = NormalizePath(value);
            return normalized.Length == 0 ? fallback : normalized;
        }

        private static float ParseFloat(string value, float fallback)
        {
            return float.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out float parsed)
                ? parsed
                : fallback;
        }

        private static bool ParseBool(string value, bool fallback)
        {
            if (bool.TryParse(value, out bool parsed))
                return parsed;
            if (value == "1" || value.Equals("on", StringComparison.OrdinalIgnoreCase))
                return true;
            if (value == "0" || value.Equals("off", StringComparison.OrdinalIgnoreCase))
                return false;
            return fallback;
        }

        private static Vector3 ParseVector3(string value, Vector3 fallback)
        {
            string[] parts = (value ?? string.Empty).Split(',');
            if (parts.Length != 3)
                return fallback;
            if (!float.TryParse(parts[0].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float x) ||
                !float.TryParse(parts[1].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float y) ||
                !float.TryParse(parts[2].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float z))
                return fallback;
            return new Vector3(x, y, z);
        }

        private static float ClampFinite(float value, float min, float max, float fallback)
        {
            if (float.IsNaN(value) || float.IsInfinity(value))
                value = fallback;
            return Mathf.Clamp(value, min, max);
        }

        private static Vector3 ClampVector(Vector3 value, float min, float max, Vector3 fallback)
        {
            if (!IsFinite(value))
                value = fallback;
            return new Vector3(
                Mathf.Clamp(value.x, min, max),
                Mathf.Clamp(value.y, min, max),
                Mathf.Clamp(value.z, min, max));
        }

        private static bool IsFinite(Vector3 value)
        {
            return !(float.IsNaN(value.x) || float.IsInfinity(value.x) ||
                     float.IsNaN(value.y) || float.IsInfinity(value.y) ||
                     float.IsNaN(value.z) || float.IsInfinity(value.z));
        }

        private static string F(float value) => value.ToString("G6", CultureInfo.InvariantCulture);
        private static string V(Vector3 value) => "(" + F(value.x) + "," + F(value.y) + "," + F(value.z) + ")";

        private static string GetTemplateText()
        {
            return
                "# MakemitAGA Active Ragdoll Lab 0.2.48 - Guard-Decoupled Strict Mechanical Parent Frame\r\n" +
                "# 保存后执行：arl_profile_reload\r\n" +
                "# CharacterJoint 继续负责机械锚点；WIDE_ISOLATION 默认保持 170 度，不重新引入人体窄限位。\r\n" +
                "# Dynamics 完全冻结自 v0.1.11：Relative Joint-Space PD + Chest COM ParentMotionFeedforward + Pose Bridge command reference。\r\n" +
                "# v0.2.17：v0.2.12-v0.2.16 归因已结束。Single-Leg Build 固定 validated Explicit Uniform Box COM/inertia；历史 A-F/运行中 inertia mutation 已从活动主线删除。\r\n" +
                "targetName=MitaPerson Mita\r\n" +
                "pelvisBonePath=Armature/Hips\r\n" +
                "spineBonePath=Armature/Hips/Spine\r\n" +
                "chestBonePath=Armature/Hips/Spine/Chest\r\n\r\n" +
                "pelvisMass=8\r\n" +
                "chestMass=12\r\n" +
                "pelvisSizeScale=0.70,0.34,0.52\r\n" +
                "chestSizeScale=0.86,0.68,0.56\r\n" +
                "minBoxDimension=0.10\r\n" +
                "maxBoxDimension=0.55\r\n\r\n" +
                "maxLinearVelocity=6\r\n" +
                "angularSpring=55\r\n" +
                "angularDamper=12\r\n" +
                "maxAngularAcceleration=40\r\n" +
                "angularDrag=3\r\n" +
                "maxAngularVelocity=18\r\n" +
                "driveDisableDistance=0.80\r\n" +
                "targetVelocityBlend=0.50\r\n" +
                "traceIntervalSeconds=0.50\r\n" +
                "# v0.2.22：隔离比较 PCA-Hinge / PCA-Character1DOF / Character-Wide，定位 Hinge backend 与 1-DOF 约束物理；不新增 profile 参数。\r\n" +
                "# v0.2.23：CharacterJoint limit engagement validation 证明 hard angular constraint 触发后 CharacterJoint 也会严重 cross-axis。\r\n" +
                "# v0.2.24：Wide CharacterJoint + CHILD_ONLY software off-axis PD foundation PASS。\r\n" +
                "# v0.2.26：归因确认 BODY_RECOVERY_SOFT_AUTHORITY_PRIMARY_CANDIDATE；source target off-axis 极小而 recovery MaxA=20 持续饱和。\r\n" +
                "# v0.2.29：Hip 40->80 清除了大多数 Source/Recovery clamp，但 whole-leg fling 峰值仅小幅下降，因此停止继续堆 MaxA。\r\n" +
                "# v0.2.30：Hip parent control-frame inertialization 让普通/中等转身肉眼明显改善，但极端事件出现 62.7 度 frame lag。\r\n" +
                "# v0.2.31：保留 6/60 -> 8/80；maxLag=25 度 bounded rebase 继续保留。\r\n" +
                "# v0.2.32：诊断确认 frame recovery 先于 physical Hip，且 Lower fling 由 Upper rotation lever 主导。\r\n" +
                "# v0.2.33：persistent world-space governor 因长期粘住/漂浮退役。\r\n" +
                "# v0.2.34：fixed-lifetime stacked-source offset 不再粘住，但 severe fling 与普通运动污染仍存在，因此实验路径在 v0.2.35 退出 production。\r\n" +
                "# v0.2.35：PhysicalRecoveryPending 与 80/40 boost timeout 分离；A-FF 在 Hip/Knee physical recovery pending 时始终 suppress。\r\n" +
                "# v0.2.36：PhysicalRecoveryPending 新增 continuous-health re-entry；Hip 15deg/0.10s 或 30deg immediate，Knee off-axis 10deg/0.10s 或 25deg immediate。Health re-entry 不增加 MaxA。\r\n# v0.2.37 A/B 已收口：healthy-normal A-FF ON 明显减少摆动；v0.2.38 删除临时 OFF arm，production 固定 ON/gain=1/bound=20。\r\n# v0.2.39：只读测 raw Pelvis / raw Upper-Hip / bounded-frame effective Upper reference 与 Hip P/D/MaxA feasibility；不改任何 controller。\r\n# v0.2.40：只读对齐 25deg lag guard 前后 effective target 的 pose-derived W/A 与 virtual 6/60→8/80；不改 guard/controller。\r\n# v0.2.41：重写 Hip control-frame IntegrateToward；strict delta-W MaxA、braking-aware arrival、删除 arrival snap/hard W clamp；25deg guard 保留。\r\n# v0.2.42：新增只读 Hip-relative Render sample-hold / composite world-reference clock attribution；production controller 完全不改。\r\n# v0.2.43：packet-interval bridge 实机确认能压低 raw packet step，但 visual FAIL，raw lag/release jump 明显；该 production 策略在 v0.2.44 退休。\r\n# v0.2.44：physical-state-aware Hip reference governor 跨 Source/physical recovery 连续保持；10deg 物理 lead envelope、50% 当前 Hip MaxA reference budget、1.5deg/0.5rad/s/0.10s 汇合后退出；Normal raw target 不变、无新增 profile 参数。\r\n# v0.2.45：只读 lag-1 Hip command→physical response attribution；不改 governor/PD/authority/Joint/profile 参数。\r\n# v0.2.46：Hip CharacterJoint mechanical parent 增加 REAL_PELVIS vs INERTIALIZED proxy A/B；默认 B。Hip anchor 平移路径保持原 raw Pelvis connectedAnchor，rotation 才跟 control frame；无新增 profile 参数。\r\n# v0.2.47：默认 INERTIALIZED 上启用 bounded mechanical-parent angular-acceleration transport FF；使用同拍 proxy commanded A，与 relative Hip correction 相加后仍由原 Hip 40/80/80 MaxA clamp；REAL raw Pelvis A 永不进入FF；无新增 profile 参数。\r\n# v0.2.48：reference 25deg lag guard 与 mechanical strict branch 解耦；proxy + transport 只消费 strict 6/60→8/80 W/A branch，guard rebase 不再进入 connectedBody；strict recovery 真正汇合后才回 raw；无新增 profile 参数。\r\n# v0.2.52：30deg post-Source recovery lead 实机证明可提高 P demand，但重新放大飘动/摆动；实验结论保留，production 策略拒绝。\r\n# v0.2.53：governor 恢复 v0.2.51 全阶段10deg production baseline；新增只读 lag-1 gyro/Knee downstream/Hip-or-other constrained-body attribution；Hip/Knee authority、Linear20、strict frame、lag guard、Joint 全部不改。\r\n# v0.2.54：production dynamics 不变；新增只读 Upper COM force closure → Hip force proxy → Hip anchor r×F → direct angular/solver residual；v0.2.53 observer 保留作对照。\r\n# v0.2.55：production dynamics 继续不变；新增只读 angular-momentum closure、Hip wide-limit margin、命令拍 lag-guard 上下文、raw/direct-after-first-order-angularDrag residual impulse；不新增 profile 参数。\r\n# v0.2.56：修复 strict control-frame→mechanical proxy command closure；active STRICT 每拍先对齐实际 settled proxy pose/W，再由原 ΔW MaxA integrator 生成唯一下一拍机械命令；不改 authority/governor/Linear20/Joint/profile 参数。\r\n# v0.2.57：冻结 v0.2.56 修复；新增只读 pre-Source composite/phase-entry 时间轴归因，记录 reference jump→mechanical/Upper response→SourceTurn 接管顺序；不改 production 参数。\r\n# v0.2.58：enablePreprocessing A/B 实机否定：OFF 仍 severe fling，production 保持 ON。\r\n# v0.2.59：新增只读 Hip Joint.currentForce/currentTorque native solver reaction witness；connectedBody frame 转 world，并与 v0.2.54/v0.2.55 closure 对齐；不改任何 production 参数。\r\n# v0.2.60：v0.2.59 实机确认 currentTorque 不能解释 direct residual；新增只读 current/previous currentForce × previous/current/midpoint Hip lever impulse closure；strict 数学 MaxA 继续 fail-fast，pose-derived proxy W/A 降为 audit-only。\r\n# v0.2.61：v0.2.60 实机首次确认 severe fling 可真正恢复至 healthy，且 severe 更偏向未恢复状态上的新 Source stacking；新增只读 Hip recovery bandwidth / inter-event gap / residual-Hip attribution，不改任何 production 参数。\r\n# v0.2.62：v0.2.61 实机确认 recovery bandwidth 强烈依赖状态；新增只读 fast-vs-slow governor compression / authority utilization / toward-away momentum 与 control-effort 归因，不新增 profile 参数。\r\n# v0.2.63：v0.2.62 实机在 Source event 1 前出现 CONTINUOUS_HEALTH normal-transition runaway 并触发 safety gate；control-effort observer 改为任何 physical recovery onset 开窗，新增 origin/context/runaway 归因与游戏内实验失效提示；production 参数不变。\r\n# v0.2.64：v0.2.63 实机确认 runaway 时 command 持续 toward、physical momentum 持续 away；新增默认 OFF 的 momentum-aware recovery braking causal B arm。B 仅追加现有 Hip D 同尺度轴向制动并复用 recoveryMaxA=80 ceiling；10deg governor/P/A-FF/Joint/profile 参数不变。\r\n# v0.2.65：v0.2.64 B 实机压住 one-way runaway/abort，但仍出现大幅单摆式过冲；新增只读 recovery-onset locked signed Hip phase-plane、zero-crossing/turning point、off-axis 与 stopping-angle/late-capture attribution；v0.2.64 braking A/B 和全部 production 参数不变。\r\n# v0.2.66：v0.2.65 实机确认 signed cross-target oscillation + late capture，同时 off-axis 很大且出现高残余 Recovery→Source stacking；新增只读 instantaneous error-axis radial/tangential relative-W、command 与 Upper-inertia energy proxy 归因；不改任何 production 参数。\r\n# v0.2.67：3D vector capture B 实机确认 tangential damping 与 Recovery→Source carry 有效，但 radial TOWARD stopping-angle gate 仅触发12拍，对应691拍 late-capture 风险，视觉仍来回飘；production 仍拒绝。\r\n# v0.2.68：保留 v0.2.67 vector/tangential/carry；新增 radial TOWARD shape causal A/B。A=原 stopping-angle gate，B=capture active 内 AWAY/TOWARD 对称 extra-D；Hip ceiling 仍80，无新增 profile 参数。\r\n" +
                "traceVerboseSnapshots=false\r\n" +
                "sourceTurnVerboseContextLogging=false\r\n" +
                "motionIdleSpeedThreshold=0.15\r\n" +
                "motionSteadyMinSpeed=0.50\r\n" +
                "motionLinearAccelerationThreshold=3.00\r\n" +
                "motionTurnAngularVelocityThreshold=1.20\r\n" +
                "motionTurnAngularAccelerationThreshold=12.0\r\n" +
                "motionTransitionHoldSeconds=0.30\r\n\r\n" +
                "# v0.1.12+ source turn attribution：以下阈值只触发日志/验收分窗，不参与控制。\r\n" +
                "sourceTurnEventRotationDeltaDegrees=20\r\n" +
                "sourceTurnEventAngularSpeedThreshold=4\r\n" +
                "sourceTurnEventAngularAccelerationThreshold=30\r\n" +
                "sourceTurnContextPreSeconds=0.50\r\n" +
                "sourceTurnContextPostSeconds=0.75\r\n\r\n" +
                "parentMotionFeedforward=true\r\n" +
                "parentMotionFeedforwardGain=12\r\n" +
                "maxParentMotionFeedforwardAcceleration=20\r\n\r\n" +
                "# v0.1.10+ torso Pose Bridge：只影响 kinematic Pelvis 的 FixedUpdate pose command；v0.2.17 继续冻结。\r\n" +
                "poseBridgeMaxExtrapolationSeconds=0.10\r\n" +
                "poseBridgePositionCorrectionGain=6.0\r\n" +
                "poseBridgeMaxPositionCorrectionSpeed=0.75\r\n" +
                "poseBridgeRotationCorrectionGain=6.0\r\n" +
                "poseBridgeMaxRotationCorrectionAngularSpeed=3.0\r\n\r\n" +
                "wideJointLimitIsolation=true\r\n" +
                "wideJointLimitDegrees=170\r\n" +
                "# 以下人体限位参数继续保留给后续恢复 ANATOMICAL 模式；WIDE_ISOLATION=true 时不会实际应用。\r\n" +
                "chestLowTwistLimitDegrees=-35\r\n" +
                "chestHighTwistLimitDegrees=35\r\n" +
                "chestSwing1LimitDegrees=45\r\n" +
                "chestSwing2LimitDegrees=35\r\n" +
                "jointAnchorSafetyDistance=0.15\r\n\r\n" +
                "# v0.2.17 Single-Leg：正式 Build 固定 validated Explicit Uniform Box COM/inertia；历史 A-F foundation arm 已删除。\r\n" +
                "singleLegEnabled=true\r\n" +
                "# v0.3.0: true=primary side + opposite side both use the frozen Single-Leg controller; false=legacy one-side mode.\r\n" +
                "bilateralLegEnabled=true\r\n" +
                "singleLegSide=Left\r\n" +
                "# 如 Humanoid/自动名称解析失败，再从 arl_audit_report 复制相对路径填写；默认留空。\r\n" +
                "singleLegUpperBonePath=\r\n" +
                "singleLegLowerBonePath=\r\n" +
                "singleLegFootBonePath=\r\n" +
                "upperLegMass=7.0\r\n" +
                "lowerLegMass=4.0\r\n" +
                "legSegmentThickness=0.10\r\n" +
                "legHipAngularSpring=55\r\n" +
                "legHipAngularDamper=12\r\n" +
                "legHipMaxAngularAcceleration=40\r\n" +
                "legHipSourceTurnMaxAngularAcceleration=80\r\n" +
                "legHipRecoveryMaxAngularAcceleration=80\r\n" +
                "legHipRecoveryExitErrorDegrees=10\r\n" +
                "legHipRecoveryStableHoldSeconds=0.15\r\n" +
                "legHipRecoveryMaxSeconds=2.0\r\n" +
                "legHipTrackingHealthEnterErrorDegrees=15\r\n" +
                "legHipTrackingHealthEnterHoldSeconds=0.10\r\n" +
                "legHipTrackingHealthImmediateErrorDegrees=30\r\n" +
                "legHipControlFrameInertialization=true\r\n" +
                "legHipControlFrameSourceMaxAngularSpeed=6\r\n" +
                "legHipControlFrameSourceMaxAngularAcceleration=60\r\n" +
                "legHipControlFrameRecoveryMaxAngularSpeed=8\r\n" +
                "legHipControlFrameRecoveryMaxAngularAcceleration=80\r\n" +
                "legHipControlFrameMaxLagDegrees=25\r\n" +
                "legHipControlFrameRecoveryExitAngleDegrees=1.5\r\n" +
                "legHipControlFrameRecoveryExitAngularSpeed=0.5\r\n" +
                "legHipControlFrameRecoveryStableHoldSeconds=0.10\r\n" +
                "legHipControlFrameRecoveryMaxSeconds=1.5\r\n" +
                "legKneeAngularSpring=45\r\n" +
                "legKneeAngularDamper=9\r\n" +
                "legKneeMaxAngularAcceleration=40\r\n" +
                "legKneeSoftOffAxisAngularSpring=30\r\n" +
                "legKneeSoftOffAxisAngularDamper=8\r\n" +
                "legKneeSoftOffAxisMaxAngularAcceleration=20\r\n" +
                "legKneeSoftOffAxisSourceTurnMaxAngularAcceleration=40\r\n" +
                "legKneeSoftOffAxisRecoveryMaxAngularAcceleration=40\r\n" +
                "legKneeSoftOffAxisRecoveryExitErrorDegrees=5\r\n" +
                "legKneeSoftOffAxisRecoveryStableHoldSeconds=0.15\r\n" +
                "legKneeSoftOffAxisRecoveryMaxSeconds=2.0\r\n" +
                "legKneeSoftOffAxisTrackingHealthEnterErrorDegrees=10\r\n" +
                "legKneeSoftOffAxisTrackingHealthEnterHoldSeconds=0.10\r\n" +
                "legKneeSoftOffAxisTrackingHealthImmediateErrorDegrees=25\r\n" +
                "legDriveDisableDistance=0.65\r\n" +
                "# v0.2.17 Angular Acceleration FF：保留 v0.2.8 已验证路径；profile 默认即为 ON；正式 real-inertia production baseline 固定 ON、gain=1、bound=20。\r\n" +
                "# contribution=targetRelativeAngularAcceleration*gain；gain 固定 1；独立 maxAcceleration 保留已验证 20；30 仅历史复核；最终 Hip 输出受 phase-aware 40/80 ceiling、Knee flexion 仍受 MaxA=40。\r\n" +
                "# SOURCE_TURN / torso recovery / Hip或Knee physical recovery pending / Hip control-frame active / sourceAge>maxSourceSampleAge 时强制 A-FF=0。\r\n" +
                "# v0.2.38：healthy-normal A-FF 已冻结为 production ON；不再提供 NORMAL_OFF attribution arm。\r\n" +
                "legAngularAccelerationFeedforward=true\r\n" +
                "legAngularAccelerationFeedforwardGain=1.0\r\n" +
                "legAngularAccelerationFeedforwardMaxAcceleration=20.0\r\n" +
                "legAngularAccelerationFeedforwardMaxSourceSampleAgeSeconds=0.10\r\n\r\n" +
                "# v0.2.2 Knee axis calibration 固定策略：NORMAL_STEADY、w>=0.25rad/s、samples>=250、principalEnergy>=0.80；不通过 profile 放宽。\r\n" +
                "# 标定只读 source；只有 arl_knee_axis_apply 才会在 leg drive=OFF 时修改 ARL 自有 Knee CharacterJoint flexion axis。\r\n\r\n" +
                "defaultColliders=false\r\n" +
                "defaultGravity=false\r\n" +
                "previewAlpha=0.28\r\n";
        }
    }
}
