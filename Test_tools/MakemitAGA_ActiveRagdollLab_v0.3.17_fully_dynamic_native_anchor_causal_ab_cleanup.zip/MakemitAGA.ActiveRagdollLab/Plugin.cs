using System;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Il2CppInterop.Runtime.Injection;
using MakemitAGA.ActiveRagdollLab.Physics;
using MakemitAGA.ActiveRagdollLab.Runtime;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MakemitAGA.ActiveRagdollLab
{
    [BepInPlugin(
        "com.alex.miside.activeragdolllab",
        "MakemitAGA Active Ragdoll Lab",
        "0.3.17")]
    public sealed class Plugin : BepInEx.Unity.IL2CPP.BasePlugin
    {
        internal static ManualLogSource Logger;
        private Harmony _harmony;
        private Action<Scene, LoadSceneMode> _sceneLoadedHandler;
        private bool _shutdown;

        public override void Load()
        {
            Logger = Log;
            Logger.LogInfo(
                "[ARL] Active Ragdoll Lab 0.3.17 loaded | v0.3.16.5 STRONG PASS: Rigidbody/Transform state-domain synchronization fixed the first-solve fully-dynamic explosion and produced a complete scorable receiver dataset; preprocessing ON/OFF showed no material difference" +
                " | v0.3.17 restores the unresolved native CharacterJoint anchor causal A/B on that hardened foundation: F0=calibrated source/spine anchor, F1=Chest-COM anchor, preprocessing=ON/ON; all physical geometry remains Rigidbody-domain and two passive dynamic solves still precede control" +
                " | both lanes use explicit box COM/inertia; Pelvis authority is recovered inertia+gyro P+D with no target-A FF, Hip-reaction injection or reaction cancellation; Chest P+D remains child-only in both lanes" +
                " | historical Single-Leg read-only attribution observers that no longer feed control/safety have been retired; production torso/legs, controller parameters, PCA, bilateral clock and 30mm Knee hard fail-close remain frozen" +
                " | use arl_twobody_dynamic_status, arl_knee_safety_status, arl_bilateral_status, arl_help.");

            try
            {
                ClassInjector.RegisterTypeInIl2Cpp<RagdollProxyContactTracker>();
                Logger.LogInfo(
                    "[ARL] Registered IL2CPP contact tracker; Collider identity only, no ContactPoint API.");
            }
            catch (Exception e)
            {
                Logger.LogWarning(
                    "[ARL] Contact tracker registration did not complete (type may already be registered): " +
                    e.GetType().Name + " / " + e.Message);
            }

            ActiveRagdollLabRuntime.Initialize(Logger);
            this.AddComponent<ActiveRagdollLabRunner>();

            _sceneLoadedHandler = OnSceneLoaded;
            SceneManager.sceneLoaded += _sceneLoadedHandler;

            _harmony = new Harmony("com.alex.miside.activeragdolllab");
            _harmony.PatchAll(typeof(ActiveRagdollConsolePatch));
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            ActiveRagdollLabRuntime.OnSceneChanged(scene.name, scene.handle);
        }

        public override bool Unload()
        {
            Shutdown("Plugin.Unload");
            return true;
        }

        internal void Shutdown(string reason)
        {
            if (_shutdown)
                return;
            _shutdown = true;

            try
            {
                if (_sceneLoadedHandler != null)
                    SceneManager.sceneLoaded -= _sceneLoadedHandler;
            }
            catch { }

            try { ActiveRagdollLabRuntime.Shutdown(reason); }
            catch (Exception e) { Logger?.LogWarning("[ARL] Shutdown failed: " + e); }
            try { _harmony?.UnpatchSelf(); }
            catch { }
        }
    }

    public sealed class ActiveRagdollLabRunner : MonoBehaviour
    {
        private void LateUpdate()
        {
            ActiveRagdollLabRuntime.SampleSourcePoseLateUpdate();
        }

        private void FixedUpdate()
        {
            ActiveRagdollLabRuntime.FixedUpdate();
        }

        private void OnApplicationQuit()
        {
            ActiveRagdollLabRuntime.Shutdown("ActiveRagdollLabRunner.OnApplicationQuit");
        }
    }
}
